TIM = TIM or class()
TIM.save_path = SavePath .. "TwitchConfig.json"
TIM.mod_path = 'mods\\TwitchIntegrationMod\\'
TIM.ModOptions = TIM.mod_path .. 'menu\\modoptions.txt'

Hooks:Add("LocalizationManagerPostInit", "LocalizationManagerPostInit_TIM", function(loc)
        for __, filename in pairs(file.GetFiles(TIM.mod_path .. "loc/")) do
                local str = filename:match('^(.*).json$')
                if str and Idstring(str) and Idstring(str):key() == SystemInfo:language():key() then
                        loc:load_localization_file(TIM.mod_path .. "loc/" .. filename)
                        break
                end
        end

        loc:load_localization_file(TIM.mod_path .. "loc/english.json", false)
end)

local function AddModOptions(menu_manager)
        if menu_manager == nil then
                return
        end

        MenuCallbackHandler.callback_twitch_button = function(self, item)
			TIM._menu:enable()
        end
		MenuHelper:LoadFromJsonFile(TIM.ModOptions, TIM)
end

Hooks:Add("MenuManagerInitialize", "Twitch_AddModOptions", AddModOptions)

function TIM:Init()

	TIM.policeCallOneTime = true
	
	TIM.InLobby = false
	TIM.ChatBadges ={}
	TIM.ChatEmotes={}
	TIM.mod_version = 13
	TIM.bot_version = 2
	TIM.LoadComplete=false
	TIM.BotPollActive=false
	TIM.Rewards={}
	TIM._effectsForms={}
	TIM.PollEffectsForms={}
	TIM.PollFunctions={}
	TIM.PollFunctionsActiveTime={}
	TIM._settings={}
	TIM.loc={}
	TIM.Updaters = {}
	TIM._settings.enableGlobalEvents=true
	TIM._settings.enableRewardChatMessage=true
	TIM._settings.TempPollsUpgradeIDs={}
	TIM._settings.Temp_ChatAI_IDs={}
	TIM._settings.gameMode=4 --POLL
	TIM._settings.PollsVariantsCount = 3
	TIM._settings.PollsStartDelay=30
	TIM._settings.PollsCooldown=30
	TIM._settings.PollsDuration=30
	TIM._settings.PollsBitsEnabled=false
	TIM._settings.PollsBitsPerVote=0
	TIM._settings.PollsCPEnabled=false
	TIM._settings.PollsCPPerVote=0
	TIM._settings.pollGameMode=1
	TIM._settings.TwitchRewards = {}
	TIM._settings.chosenPollsEffects={}
	TIM._settings.rewardCooldown=2
	TIM._settings.firstTimeStarted=true
	TIM._settings.Maximum_upgrade_level=5
	TIM._settings.Upgrade_price_step_per_level = 50
	TIM._settings.Default_upgrade_price=100
	TIM._settings.ChatAI={}
	TIM._settings.ChatAI.SpawnPrice = 100
	TIM._settings.ChatAI.DefaultUpgradePrice=100
	TIM._settings.ChatAI.RestoreHealthPrice=100
	TIM._settings.ChatAI.IncreaseDamagePrice=100
	TIM._settings.ChatAI.DropAmmoPrice=100
	TIM._settings.ChatAI.CharacterStatusPrice=1
	TIM._settings.ChatAI.SpawnColor="FFFFFF"
	TIM._settings.ChatAI.CharacterStatusColor="FFFFFF"
	TIM._settings.ChatAI.DefaultUpgradeColor="FFFFFF"
	TIM._settings.ChatAI.RestoreHealthColor="FFFFFF"
	TIM._settings.ChatAI.IncreaseDamageColor="FFFFFF"
	TIM._settings.ChatAI.DropAmmoColor="FFFFFF"
	TIM.errorText=""
	TIM._settings.loc="english" --russian english
	TIM.effectsFunctions={}
	TIM.Values = {}
	TIM.GlobalEvents=false
	TIM:CreateScopes()
	TIM.Chat_option = true
	TIM.validation = true
	local twitchbotDLLCheck = io.open('mods\\TwitchBotDLL\\TwitchBot.dll', "r")
	if twitchbotDLLCheck then
		twitchbotDLLCheck:close()
		local _, library = blt.load_native('mods\\TwitchBotDLL\\TwitchBot.dll')
		TIM.library = library
		if TIM.library.bot_vesrion then
			local bot_version = TIM.library.bot_vesrion()
			if TIM.bot_version == bot_version then
				TIM.BotChatActive=TIM.library.get_on_IRC()
				TIM.BotPointsActive=TIM.library.get_on_Pubsub()
				TIM.ModActive=TIM.library.getModActive()
				
				local file = io.open(TIM.save_path, "r")
				if file then
					for k, v in pairs(json.decode(file:read("*all")) or {}) do
						TIM._settings[k] = v
					end
					file:close()
				else
					file = io.open(TIM.save_path, "w")
					if file then
						file:write('{\"OAUTH\":\"\",\"startBotOnStart\":false, \"enableGlobalEvents\":true, \"firstTimeStarted\":true, \"Nickname\":\"\",\"loc\":\"english\", \"UserID\":\"\", \"TwitchRewards\":{}, \"enableChat\":true, \"enableChannelPoints\":true, \"version\":12, \"rewardCooldown\":1}')
						file:close()
					end
					TIM:load_settings()
				end
				dofile(TIM.mod_path..'menu\\TIMmenu.lua')
				dofile(TIM.mod_path..'Systems\\Polls.lua')
				dofile(TIM.mod_path..'Systems\\ChatAI.lua')
				dofile(TIM.mod_path..'Systems\\ChannelPoints.lua')
				TIM:Load_localisation()
				TIM:MainMenuInit()
				if TIM._settings.firstTimeStarted == false then
					TIM:ValidateOAUTH(TIM._settings.OAUTH)
					if TIM._settings.Nickname and TIM._settings.Nickname ~= "" and TIM.validation==true and TIM._settings.enableChat and TIM._settings.enableChannelPoints then
						TIM._settings.UserID = TIM.library.prepareAPI(TIM._settings.Nickname, TIM._settings.OAUTH, TIM._settings.enableChat, TIM._settings.enableChannelPoints) --, TIM._settings.UserID
					end
					if TIM._settings.startBotOnStart == true and TIM.ModActive==false and TIM.library.perm_disable_get() == false then
						TIM:ActivateMod()
					end
				end
				

				
				TIM:LoadGameModeSystem()
			else
				TIM:Bot_error()
			end
		else
			TIM:Bot_error()
		end
	else
		TIM:Bot_error()
	end
end

function TIM:Bot_error()
	dofile(TIM.mod_path..'menu\\TIMerrormenu.lua')
	TIM:Load_localisation()
	TIM:MainMenuInit()
end

function TIM:CreateScopes()
	TIM.scopesNeed={}
	TIM.scopesNeed["channel:manage:polls"]=true
	TIM.scopesNeed["channel:manage:redemptions"]=true
	TIM.scopesNeed["channel:read:polls"]=true
	TIM.scopesNeed["channel:read:redemptions"]=true
	TIM.scopesNeed["chat:edit"]=true
	TIM.scopesNeed["chat:read"]=true
	TIM.scopesNeed["chat_login"]=true
end

function TIM:Load_localisation()
	local file_loc = io.open(TIM.mod_path..'loc\\'..TIM._settings.loc..'.json', "r")
	if file_loc then
		for k, v in pairs(json.decode(file_loc:read("*all")) or {}) do
			TIM.loc[k] = v
		end
		file_loc:close()
	end
end

function TIM:ValidateOAUTH(OAUTH)
	TIM.validation = true
	local temp_table = {}
	local result = TIM.library.validate(OAUTH)
	local decoded = json.decode(result)
	if decoded and decoded.status then
		TIM:Set_error(tostring(decoded.message))
		TIM.validation = false
	elseif decoded and decoded.scopes then
		for k, value in pairs(decoded.scopes or {}) do
			temp_table[value]=true
		end
		for k, value in pairs(TIM.scopesNeed) do
			if temp_table[k] == nil then
				TIM.validation = false
				break
			end
		end
	else
		TIM:Set_error("Unknown error with validation of OAUTH Code")
		TIM.validation = false
	end
	return TIM.validation
end

function TIM:Set_error(message)
	TIM.errorText = message
end
function TIM:Set_error_and_show_window(message)
	TIM.errorText = message
	TIM._errorWindow:Enable()
end

function TIM:LoadGameModeSystem()
	TIM:LoadRewardForms()
	TIM:LoadPolls()
	if TIM.ModActive==true and TIM.validation==true then
		TIM:AddUpdater("CheckChatMessage", TIM.CheckChatMessage, false)
		if TIM._settings.gameMode==1 then 
			TIM:AddUpdater("CheckReward", TIM.CheckReward, false)
		elseif TIM._settings.gameMode==2 then --POLL
			TIM:deleteAllRewards()
			TIM:AddUpdater("CheckUpgradeReward", TIM.CheckUpgradeReward, false)
			TIM:AddUpdater("PollGetResult", TIM.PollGetResult, false)
		elseif TIM._settings.gameMode==3 then
			TIM:deleteAllRewards()
			TIM:AddUpdater("CheckChatAIReward", TIM.CheckChatAIReward, false)
		elseif TIM._settings.gameMode==4 then
			TIM:deleteAllRewards()
			
		end
	end
	TIM:save_settings()
end

function TIM:ChangeGameModeSystem()
	if TIM._settings.gameMode==1 then --CP
		
		TIM:deleteAllRewards()
		TIM:CreateAllCPRewards()
		TIM._settings.enableChannelPoints=true
		TIM._settings.enableGlobalEvents=false
	elseif TIM._settings.gameMode==2 then --POLL
		TIM:LoadPolls()
		TIM:DeleteAllCPRewards()
		TIM:deleteAllRewards()
		TIM._settings.enableGlobalEvents=true
		TIM._settings.enableChannelPoints=true
	elseif TIM._settings.gameMode==3 then
		TIM._settings.enableGlobalEvents=false
		TIM._settings.enableChannelPoints=true
		TIM:DeleteAllCPRewards()
		TIM:deleteAllRewards()
	elseif TIM._settings.gameMode==4 then
		TIM._settings.enableGlobalEvents=false
		TIM._settings.enableChannelPoints=false
		TIM:DeleteAllCPRewards()
		TIM:deleteAllRewards()
	end
end

function TIM:CheckModVersion()
	if TIM.mod_version ~= TIM._settings.version then 
		for rewardID, rewardValue in pairs(TIM._settings.TwitchRewards or {}) do
			TIM._settings.TwitchRewards[rewardID].enabled = TIM._settings.TwitchRewards[rewardID].enabled and TIM._settings.TwitchRewards[rewardID].enabled or true
			TIM._settings.TwitchRewards[rewardID].tactic = TIM._settings.TwitchRewards[rewardID].tactic and TIM._settings.TwitchRewards[rewardID].tactic or 3
			for effectID, effectValue in pairs(TIM._settings.TwitchRewards[rewardID].effects or {}) do
				for parametrID, parametrValue in pairs(TIM._effectsForms[effectID].TIM or {}) do
					if TIM._settings.TwitchRewards[rewardID].effects[effectID][parametrID] ==nil then
						TIM._settings.TwitchRewards[rewardID].effects[effectID][parametrID]={}
						if TIM._effectsForms[effectID].TIM[parametrID].Type=="ComboBox" then
							TIM._settings.TwitchRewards[rewardID].effects[effectID][parametrID].SelectedItem = TIM._effectsForms[effectID].TIM[parametrID].Items[1].name
						end
						TIM._settings.TwitchRewards[rewardID].effects[effectID][parametrID].Value = TIM._effectsForms[effectID].TIM[parametrID].defaultValue
						--somethingChanged = true
					end
				end
			end
		end
		TIM._settings.version = TIM.mod_version
		TIM:save_settings()		
	end
end

function TIM:ActivateMod()
	if TIM.validation==true then
		TIM.ModActive=true
		TIM.library.perm_disable_set(false)
		TIM:save_settings()
		TIM.library.start_bot(string.lower(TIM._settings.Nickname), TIM._settings.OAUTH, TIM._settings.enableChat, TIM._settings.enableChannelPoints, TIM._settings.UserID)
		TIM.library.download_badges()
		--TIM:Create_co()
		local rewStr=""
		
		TIM:AddUpdater("CheckChatMessage", TIM.CheckChatMessage, false)
		if TIM._settings.gameMode == 1 then
			
			TIM:AddUpdater("CheckReward", TIM.CheckReward, false)
			
			if Utils:IsInHeist() == true then
				TIM:CheckTactic()
			end
		elseif TIM._settings.gameMode == 2 then 
			TIM:LoadPolls()
			
			TIM:AddUpdater("CheckUpgradeReward", TIM.CheckUpgradeReward, false)
			TIM:AddUpdater("PollGetResult", TIM.PollGetResult, false)
			if Utils:IsInHeist() == true then
				TIM:StartDelayPolls()
			end
		elseif TIM._settings.gameMode == 3 then 
			
			TIM:AddUpdater("CheckChatAIReward", TIM.CheckChatAIReward, false)
			
			if Utils:IsInHeist() == true then
				TIM:CheckTacticChatAI()
			end
		elseif TIM._settings.gameMode == 4 then 

		end
		
		TIM.BotChatActive = TIM.library.get_on_IRC()
		TIM.BotPointsActive = TIM.library.get_on_Pubsub()
		return true
	else
		return false
	end
end

function TIM:DisableMod()
	TIM.ModActive=false
	TIM.library.perm_disable_set(true)
	TIM.library.stop_Bot()
	TIM.library.clearRewardIDs()
	TIM:RemoveAllUpdaters()
	local rewStr=""
	if TIM._settings.gameMode == 1 then
		for k, v in pairs(TIM._settings.TwitchRewards or {}) do
			if TIM._settings.TwitchRewards[k].enabled == true then
				rewStr=rewStr..k.."|"
			end
		end
		TIM.library.enableListRewards(rewStr, false)
	elseif TIM._settings.gameMode == 2 then 
		TIM:EndPoll()
	elseif TIM._settings.gameMode == 3 then 
		TIM:DisableChatAI()
	elseif TIM._settings.gameMode == 4 then 
		
	end
	
	TIM.BotChatActive=TIM.library.get_on_IRC()
	TIM.BotPointsActive=TIM.library.get_on_Pubsub()
end

function TIM:Game_setup()
	if managers.hud ~= nil then 
		TIM.hud = managers.hud:script(PlayerBase.PLAYER_INFO_HUD_FULLSCREEN_PD2)
		TIM.player = managers.player:local_player()
		TIM.M_groupAI = managers.groupai
		TIM.AIState = TIM.M_groupAI:state()
		TIM.GlobalEvents=false
	end
end

function TIM:Spawn_position(onPlayer, position, radius, rot_deg, rotation_t) 
	local player_pos = position and position or managers.player:local_player():position()
	local radi = radius and radius or 300
	local summ_c = radius and radius or 300
	local degg = rot_deg and rot_deg or 0
	local rotation = rotation_t and rotation_t or (managers.player:local_player() and managers.player:local_player():camera():rotation():yaw() or 0)
	if onPlayer == false and managers.player:local_player() then
		local Aim_Pos = Utils:GetPlayerAimPos(managers.player:local_player(), 10000)
		if tostring(Aim_Pos):find("Vector3") then
			local summ_x = player_pos.x  - Aim_Pos.x
			local summ_x_abs = math.abs(summ_x)
			local summ_y = player_pos.y - Aim_Pos.y
			local summ_y_abs = math.abs(summ_y)
			local sign_x = TIM:sign(summ_x)*-1	
			local sign_y = TIM:sign(summ_y)*-1
			summ_c = math.sqrt(summ_x^2 +summ_y^2)					
			summ_c = summ_c > radi and radi or summ_c-30
		end
		local b = summ_c * math.sin(rotation+90)
		local a = summ_c * math.cos(rotation+90)
		player_pos = player_pos + Vector3(a, b, 0)
	elseif onPlayer=="round" then	
		player_pos = TIM:Position_rotate(player_pos, rotation, degg, summ_c)
	end
	local player_rot = Rotation(rotation-180, 0, 0)
	return player_pos, player_rot--, unit_done
end

function TIM:Position_rotate(pos, rot, rotation_deg, radius)
	local b = radius * math.sin(rot+90+rotation_deg)
	local a = radius * math.cos(rot+90+rotation_deg)
	local pp = pos + Vector3(a, b, 0)
	return pp
end

function TIM:Spawn_unit(enemy, unit_name, pos, rot) 
	local unit_done = World:spawn_unit( unit_name, pos, rot, 0, 0) 
	if enemy == true then
		local team_id = tweak_data.levels:get_default_team_ID( unit_done:base():char_tweak().access == "gangster" and "gangster" or "combatant" )
		unit_done:movement():set_team( TIM.AIState:team_data( team_id ) )
	end
	return unit_done
end

function TIM:save_settings()
	local file = io.open(TIM.save_path, "w+")
	if file then
		file:write(json.encode(TIM._settings))
		file:close()
	end
end

function TIM:load_settings()
	local file = io.open(TIM.save_path, "r")
	if file then
		for k, v in pairs(json.decode(file:read("*all")) or {}) do
			TIM._settings[k] = v
		end
		file:close()
	end
end

function TIM:debug(...)

	local printR=""
	for i,v in ipairs{...} do
		printR = printR .. tostring(v) .. ", "
	end
	managers.mission._fading_debug_output:script().log(printR,  Color.white)
end

function TIM:Post(clss, func, after_orig)
	Hooks:PostHook(clss, func, "TIM_"..func, after_orig)
end

function TIM:Check_badges(classHUD, badges, line_panel,  x)
	local wh = classHUD.line_height-5
	if classHUD.tabW then
		wh=classHUD.tabW*2
	end
	local badges_list = badges:split(",")
	local ext = Idstring("texture")
	
	for i = 1, #badges_list, 1 do
		local badge = badges_list[i]:split("/")
		
		if TIM.ChatBadges[badge[1]] == nil or (TIM.ChatBadges[badge[1]] and TIM.ChatBadges[badge[1]][badge[2]] == nil) then
			FileManager:AddFileWithCheck(ext, Idstring("assets/mod_overrides/Twitch Integration Mod emotes/badges/"..badge[1].."/"..badge[2]), "assets/mod_overrides/Twitch Integration Mod emotes/badges/"..badge[1].."/"..badge[2]..".png")		
			TIM.ChatBadges[badge[1]]= TIM.ChatBadges[badge[1]] or {}
			TIM.ChatBadges[badge[1]][badge[2]]=true
		end
		
		local emote_bitmap = line_panel:bitmap({
			visible = true, name ="twitch_icon",
			texture = "assets/mod_overrides/Twitch Integration Mod emotes/badges/"..badge[1].."/"..badge[2],
			layer = 0, alpha=1, color = Color(1, 1, 1), w = wh, h = wh,
			blend_mode = "add", x = x, y =0
		})
		x = emote_bitmap:right()
		emote_bitmap:set_center_y(HUDChat.line_height/2)
		emote_bitmap=nil
	end
	
	return x, #badges_list
end

function TIM:Check_emotes(emotes)
	emotes = string.sub(emotes, 1, #emotes -1)
	local emotes_list = emotes:split("/")
	local ext = Idstring("texture")
	for i = 1, #emotes_list, 1 do
		local emote = emotes_list[i]
		
		if TIM.ChatEmotes[emote] == nil then
			local path ="assets/mod_overrides/Twitch Integration Mod emotes/"..emote
			FileManager:AddFileWithCheck(ext, Idstring(path), "assets/mod_overrides/Twitch Integration Mod emotes/"..emote..".png")			
			TIM.ChatEmotes[emote]= path
		end
	end
end

function TIM:StopAllEffects()

end

function TIM:deleteAllRewards()
	if TIM._settings.UserID and TIM._settings.UserID ~="" and TIM._settings.Nickname ~="" and TIM.validation==true  then
		TIM.library.deleteAllCustomRewards()
	end
end

function TIM:AddUpdater(id, func, enable_pause)
	BeardLib:AddUpdater(id, func, enable_pause)
	TIM.Updaters[#TIM.Updaters+1]=id
end

function TIM:RemoveUpdater(id)
	BeardLib:RemoveUpdater(id)
	for k, v in pairs(TIM.Updaters or {}) do
		if v == id then
			table.remove(TIM.Updaters, k)
			break
		end
	end
end

function TIM:RemoveAllUpdaters()
	for k, v in pairs(TIM.Updaters or {}) do
		BeardLib:RemoveUpdater(v)
	end
	TIM.Updaters={}
end

function TIM:Take_word_from_file()
	if TIM.GlobalEvents == false and managers.hud:script(PlayerBase.PLAYER_INFO_HUD_PD2).panel:child("point_of_no_return_panel"):visible()==false and TIM.BotPointsActive == true then		
		local rew_temp = TIM.library.get_reward()
		
		if rew_temp ~= "NULL" then
			TIM:Redeem_reward(rew_temp)
		end
	end
end

function TIM:fon_function()	
	local lin = TIM.hud.panel:bitmap({ name = "lin_bitmap", visible = false, layer = 0, color = Color(1, 1, 1), w = 1, h = 1, x =0, y =0 })
	return lin
end

function TIM:sign(x)
  return x>0 and 1 or x<0 and -1 or 0
end

function TIM:CheckChatMessage()
	if managers.network:session() then
		if TIM.LoadComplete==true or managers.network:session():local_peer():in_lobby()==true then
			local name, color, message, badges, emotes, isReward = TIM.library.get_message()
			if name ~= "NULL" then 
				if isReward==true and TIM._settings.enableRewardChatMessage == true then
					managers.chat:_receive_message_twitch(1, name, message, Color(color:sub(2)), badges, emotes, isReward)
				elseif isReward==false then
					managers.chat:_receive_message_twitch(1, name, message, Color(color:sub(2)), badges, emotes)
				end
			end
		end
	end
end

function TIM:Chat_co_create()
	TIM.chatCO = coroutine.create(function()
		while true do
			coroutine.yield()
			if managers.network:session() then
				if TIM.LoadComplete==true or managers.network:session():local_peer():in_lobby()==true then
					if TIM.BotChatActive == true or TIM.BotPointsActive==true then
						local name, color, message, badges, emotes, isReward = TIM.library.get_message()
						if name ~= "NULL" then 
							if isReward==true and TIM._settings.enableRewardChatMessage == true then
								managers.chat:_receive_message_twitch(1, name, message, Color(color:sub(2)), badges, emotes, isReward)
							elseif isReward==false then
								managers.chat:_receive_message_twitch(1, name, message, Color(color:sub(2)), badges, emotes)
							end
						end
					end
				end
			end
			
			local k =1
		end
	end)
end

function TIM:Chat_co_resume()
	if TIM.BotChatActive==true then
		if tostring(coroutine.status(TIM.chatCO))=="dead" then
			TIM:Chat_co_create()
		end
		if TIM.chatCO then
			coroutine.resume(TIM.chatCO)
		end
	end
end

function TIM:lua_test(str, int1)
	managers.mission._fading_debug_output:script().log(tostring(str).." - "..tostring(int1),  Color.green)	
	return 23
end

function TIM:CheckGameState()
	if managers.groupai:state():whisper_mode() == true then
		
	else
		TIM:RemoveUpdater("CheckGameState")
		if TIM._settings.gameMode==1 then 
			TIM:CheckTactic()
		elseif TIM._settings.gameMode==3 then
			TIM:CheckTacticChatAI()
		end
	end
end



