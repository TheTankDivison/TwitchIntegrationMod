TIM = TIM or class()
TIM.save_path = SavePath .. "TwitchConfig.json"
TIM.mod_path = 'mods\\TwitchIntegrationMod\\'

function TIM:Init()
	function TIM:Check()
	
	end
	TIM.policeCallOneTime = true
	
	TIM.InLobby = false
	TIM.ChatBadges ={}
	TIM.ChatEmotes={}
	TIM.mod_version = 12
	TIM.LoadComplete=false
	TIM.BotPollActive=false
	TIM.Rewards={}
	TIM._effectsForms={}
	TIM.PollEffectsForms={}
	TIM.PollFunctions={}
	TIM.PollFunctionsActiveTime={}
	TIM._settings={}
	TIM.loc={}
	TIM._settings.enableGlobalEvents=true
	TIM._settings.enableRewardChatMessage=true
	TIM._settings.TempPollsUpgradeIDs={}
	TIM._settings.Temp_ChatAI_IDs={}
	TIM._settings.gameMode=4 --POLL
	TIM._settings.PollsVariantsCount = 3
	TIM._settings.PollsStartDelay=30
	TIM._settings.PollsCooldown=30
	TIM._settings.PollsDuration=30
	TIM._settings.PollsBitsEnabled=false
	TIM._settings.PollsBitsPerVote=0
	TIM._settings.PollsCPEnabled=false
	TIM._settings.PollsCPPerVote=0
	TIM._settings.TwitchRewards = {}
	TIM._settings.chosenPollsEffects={}
	TIM._settings.rewardCooldown=2
	TIM._settings.firstTimeStarted=true
	TIM._settings.Maximum_upgrade_level=5
	TIM._settings.Upgrade_price_step_per_level = 50
	TIM._settings.Default_upgrade_price=100
	TIM._settings.ChatAI={}
	TIM._settings.ChatAI.SpawnPrice = 100
	TIM._settings.ChatAI.DefaultUpgradePrice=100
	TIM._settings.ChatAI.RestoreHealthPrice=100
	TIM._settings.ChatAI.IncreaseDamagePrice=100
	TIM._settings.ChatAI.DropAmmoPrice=100
	TIM._settings.ChatAI.CharacterStatusPrice=1
	TIM._settings.ChatAI.SpawnColor="FFFFFF"
	TIM._settings.ChatAI.CharacterStatusColor="FFFFFF"
	TIM._settings.ChatAI.DefaultUpgradeColor="FFFFFF"
	TIM._settings.ChatAI.RestoreHealthColor="FFFFFF"
	TIM._settings.ChatAI.IncreaseDamageColor="FFFFFF"
	TIM._settings.ChatAI.DropAmmoColor="FFFFFF"
	
	TIM._settings.loc="english" --russian english
	TIM.effectsFunctions={}
	TIM.Values = {}
	TIM.GlobalEvents=false
	
	TIM.Chat_option = true
	local _, library = blt.load_native('mods\\TwitchBotDLL\\TwitchBot.dll')
	TIM.library = library
	
	TIM.BotChatActive=TIM.library.get_on_IRC()
	TIM.BotPointsActive=TIM.library.get_on_Pubsub()
	TIM.ModActive=TIM.library.getModActive()
	local file = io.open(TIM.save_path, "r")
	if file then
		for k, v in pairs(json.decode(file:read("*all")) or {}) do
			TIM._settings[k] = v
		end
		file:close()
	else
		file = io.open(TIM.save_path, "w")
		if file then
			file:write('{\"OAUTH\":\"\",\"startBotOnStart\":false, \"enableGlobalEvents\":true, \"firstTimeStarted\":true, \"Nickname\":\"\",\"loc\":\"english\", \"UserID\":\"\", \"TwitchRewards\":{}, \"enableChat\":true, \"enableChannelPoints\":true, \"version\":12, \"rewardCooldown\":1}')
			file:close()
		end
		TIM:load_settings()
	end
	-------------------Loc-------------------
	local file_loc = io.open(TIM.mod_path..'loc\\'..TIM._settings.loc..'.json', "r")
	if file_loc then
		for k, v in pairs(json.decode(file_loc:read("*all")) or {}) do
			TIM.loc[k] = v
		end
		file_loc:close()
	end
	--TIM._settings.enableChannelPoints=true
	if TIM._settings.Nickname and TIM._settings.Nickname ~= "" and TIM._settings.OAUTH ~= "" and TIM._settings.enableChat and TIM._settings.enableChannelPoints then
		TIM._settings.UserID = TIM.library.prepareAPI(TIM._settings.Nickname, TIM._settings.OAUTH, TIM._settings.enableChat, TIM._settings.enableChannelPoints) --, TIM._settings.UserID
	end
	if TIM._settings.startBotOnStart == true and TIM.BotChatActive == false and TIM.BotPointsActive == false then
		TIM.library.start_bot(TIM._settings.Nickname, TIM._settings.OAUTH, TIM._settings.enableChat, TIM._settings.enableChannelPoints, TIM._settings.UserID)

		TIM.library.download_badges()
		--if TIM._settings.enableTacticMode==true then
			local rewStr=""
			for k, v in pairs(TIM._settings.TwitchRewards or {}) do
				rewStr=rewStr..k.."|"
			end
			TIM.library.enableListRewards(rewStr, false)
		--end
		TIM.BotChatActive = TIM.library.get_on_IRC()
		TIM.BotPointsActive=TIM.library.get_on_Pubsub()
	end
	
	dofile(TIM.mod_path..'menu\\TIMmenu.lua')
	dofile(TIM.mod_path..'Systems\\Polls.lua')
	dofile(TIM.mod_path..'Systems\\ChatAI.lua')
	dofile(TIM.mod_path..'Systems\\ChannelPoints.lua')
	
	TIM:LoadGameModeSystem()
	
	--TIM:CheckModVersion()
	TIM:MainMenuInit()
	TIM:Create_co()
end

function TIM:Create_co()
	
end

function TIM:LoadGameModeSystem()
	TIM:LoadRewardForms()
	TIM:LoadPolls()
	if TIM._settings.gameMode==1 then 
		
		function TIM:Create_co()
			TIM:Chat_co_create()
			TIM:Reward_co_create()
		end
		function TIM:Check()
			TIM:Chat_co_resume()
			TIM:Reward_co_resume()
		end
	elseif TIM._settings.gameMode==2 then --POLL
		TIM:deleteAllRewards()
		function TIM:Create_co()
			TIM:Chat_co_create()
			TIM:Upgrade_reward_co_create()
		end
		function TIM:Check()
			TIM:Chat_co_resume()
			TIM:Upgrade_reward_co_resume()
			TIM:PollGetResult()
		end
	elseif TIM._settings.gameMode==3 then
		TIM:deleteAllRewards()
		function TIM:Create_co()
			TIM:Chat_co_create()
			TIM:Upgrade_ChatAI_co_create()
		end
		function TIM:Check()
			TIM:Chat_co_resume()
			TIM:Upgrade_ChatAI_co_resume()
		end
	elseif TIM._settings.gameMode==4 then
		TIM:deleteAllRewards()
		function TIM:Create_co()
			TIM:Chat_co_create()
		end
		function TIM:Check()
			TIM:Chat_co_resume()
		end
	end
end

function TIM:ChangeGameModeSystem()
	if TIM._settings.gameMode==1 then --CP
		
		TIM:deleteAllRewards()
		TIM:CreateAllCPRewards()
		TIM._settings.enableChannelPoints=true
		TIM._settings.enableGlobalEvents=false
		function TIM:Create_co()
			TIM:Chat_co_create()
			TIM:Reward_co_create()
		end
		function TIM:Check()
			TIM:Chat_co_resume()
			TIM:Reward_co_resume()
		end
	elseif TIM._settings.gameMode==2 then --POLL
		TIM:LoadPolls()
		TIM:DeleteAllCPRewards()
		TIM:deleteAllRewards()
		TIM._settings.enableGlobalEvents=true
		TIM._settings.enableChannelPoints=true
		function TIM:Create_co()
			TIM:Chat_co_create()
			TIM:Upgrade_reward_co_create()
		end
		function TIM:Check()
			TIM:Chat_co_resume()
			TIM:Upgrade_reward_co_resume()
			TIM:PollGetResult()
		end
	elseif TIM._settings.gameMode==3 then
		TIM._settings.enableGlobalEvents=false
		TIM._settings.enableChannelPoints=true
		TIM:DeleteAllCPRewards()
		TIM:deleteAllRewards()
		function TIM:Create_co()
			TIM:Chat_co_create()
			TIM:Upgrade_ChatAI_co_create()
		end
		function TIM:Check()
			TIM:Chat_co_resume()
			TIM:Upgrade_ChatAI_co_resume()
		end
	elseif TIM._settings.gameMode==4 then
		TIM._settings.enableGlobalEvents=false
		TIM._settings.enableChannelPoints=false
		TIM:DeleteAllCPRewards()
		TIM:deleteAllRewards()
		function TIM:Create_co()
			TIM:Chat_co_create()
		end
		function TIM:Check()
			TIM:Chat_co_resume()
		end
	end
end

function TIM:CheckModVersion()
	if TIM.mod_version ~= TIM._settings.version then 
		for rewardID, rewardValue in pairs(TIM._settings.TwitchRewards or {}) do
			TIM._settings.TwitchRewards[rewardID].enabled = TIM._settings.TwitchRewards[rewardID].enabled and TIM._settings.TwitchRewards[rewardID].enabled or true
			TIM._settings.TwitchRewards[rewardID].tactic = TIM._settings.TwitchRewards[rewardID].tactic and TIM._settings.TwitchRewards[rewardID].tactic or 3
			for effectID, effectValue in pairs(TIM._settings.TwitchRewards[rewardID].effects or {}) do
				for parametrID, parametrValue in pairs(TIM._effectsForms[effectID].TIM or {}) do
					if TIM._settings.TwitchRewards[rewardID].effects[effectID][parametrID] ==nil then
						TIM._settings.TwitchRewards[rewardID].effects[effectID][parametrID]={}
						if TIM._effectsForms[effectID].TIM[parametrID].Type=="ComboBox" then
							TIM._settings.TwitchRewards[rewardID].effects[effectID][parametrID].SelectedItem = TIM._effectsForms[effectID].TIM[parametrID].Items[1].name
						end
						TIM._settings.TwitchRewards[rewardID].effects[effectID][parametrID].Value = TIM._effectsForms[effectID].TIM[parametrID].defaultValue
						--somethingChanged = true
					end
				end
			end
		end
		TIM._settings.version = TIM.mod_version
		TIM:save_settings()		
	end
end

function TIM:ActivateMod()
	TIM.ModActive=true
	TIM:save_settings()
	TIM.library.start_bot(string.lower(TIM._settings.Nickname), TIM._settings.OAUTH, TIM._settings.enableChat, TIM._settings.enableChannelPoints, TIM._settings.UserID)
	TIM.library.download_badges()
	TIM:Create_co()
	local rewStr=""
	
	if TIM._settings.gameMode == 1 then
		function TIM:Check()
			TIM:Chat_co_resume()
			TIM:Reward_co_resume()
		end
		if Utils:IsInHeist() == true then
			TIM:CheckTactic()
		end
	elseif TIM._settings.gameMode == 2 then 
		TIM:LoadPolls()
		function TIM:Check()
			TIM:Chat_co_resume()
			TIM:Upgrade_reward_co_resume()
			TIM:PollGetResult()
		end
		if Utils:IsInHeist() == true then
			TIM:StartDelayPolls()
		end
	elseif TIM._settings.gameMode == 3 then 
		function TIM:Check()
			TIM:Chat_co_resume()
			TIM:Upgrade_ChatAI_co_resume()
		end
		if Utils:IsInHeist() == true then
			TIM:CheckTacticChatAI()
		end
	elseif TIM._settings.gameMode == 4 then 
		function TIM:Check()
			TIM:Chat_co_resume()
		end
	end
	
	TIM.BotChatActive = TIM.library.get_on_IRC()
	TIM.BotPointsActive = TIM.library.get_on_Pubsub()
end

function TIM:DisableMod()
	TIM.ModActive=false
	TIM.library.stop_Bot()
	function TIM:Check()
	
	end
	local rewStr=""
	if TIM._settings.gameMode == 1 then
		for k, v in pairs(TIM._settings.TwitchRewards or {}) do
			if TIM._settings.TwitchRewards[k].enabled == true then
				rewStr=rewStr..k.."|"
			end
		end
		TIM.library.enableListRewards(rewStr, false)
	elseif TIM._settings.gameMode == 2 then 
		TIM:EndPoll()
	elseif TIM._settings.gameMode == 3 then 
		TIM:DisableChatAI()
	elseif TIM._settings.gameMode == 4 then 
		
	end
	
	TIM.BotChatActive=TIM.library.get_on_IRC()
	TIM.BotPointsActive=TIM.library.get_on_Pubsub()
end

function TIM:Game_setup()
	if managers.hud ~= nil then 
		TIM.hud = managers.hud:script(PlayerBase.PLAYER_INFO_HUD_FULLSCREEN_PD2)
		TIM.player = managers.player:local_player()
		TIM.M_groupAI = managers.groupai
		TIM.AIState = TIM.M_groupAI:state()
		TIM.GlobalEvents=false
	end
end

function TIM:Spawn_position(onPlayer, position, radius, rot_deg, rotation_t) 
	local player_pos = position and position or managers.player:local_player():position()
	local radi = radius and radius or 300
	local summ_c = radius and radius or 300
	local degg = rot_deg and rot_deg or 0
	local rotation = rotation_t and rotation_t or (managers.player:local_player() and managers.player:local_player():camera():rotation():yaw() or 0)
	if onPlayer == false and managers.player:local_player() then
		local Aim_Pos = Utils:GetPlayerAimPos(managers.player:local_player(), 10000)
		if tostring(Aim_Pos):find("Vector3") then
			local summ_x = player_pos.x  - Aim_Pos.x
			local summ_x_abs = math.abs(summ_x)
			local summ_y = player_pos.y - Aim_Pos.y
			local summ_y_abs = math.abs(summ_y)
			local sign_x = TIM:sign(summ_x)*-1	
			local sign_y = TIM:sign(summ_y)*-1
			summ_c = math.sqrt(summ_x^2 +summ_y^2)					
			summ_c = summ_c > radi and radi or summ_c-30
		end
		local b = summ_c * math.sin(rotation+90)
		local a = summ_c * math.cos(rotation+90)
		player_pos = player_pos + Vector3(a, b, 0)
	elseif onPlayer=="round" then	
		player_pos = TIM:Position_rotate(player_pos, rotation, degg, summ_c)
	end
	local player_rot = Rotation(rotation-180, 0, 0)
	return player_pos, player_rot--, unit_done
end

function TIM:Position_rotate(pos, rot, rotation_deg, radius)
	local b = radius * math.sin(rot+90+rotation_deg)
	local a = radius * math.cos(rot+90+rotation_deg)
	local pp = pos + Vector3(a, b, 0)
	return pp
end

function TIM:Spawn_unit(enemy, unit_name, pos, rot) 
	local unit_done = World:spawn_unit( unit_name, pos, rot, 0, 0) 
	if enemy == true then
		local team_id = tweak_data.levels:get_default_team_ID( unit_done:base():char_tweak().access == "gangster" and "gangster" or "combatant" )
		unit_done:movement():set_team( TIM.AIState:team_data( team_id ) )
	end
	return unit_done
end

function TIM:save_settings()
	local file = io.open(TIM.save_path, "w+")
	if file then
		file:write(json.encode(TIM._settings))
		file:close()
	end
end

function TIM:load_settings()
	local file = io.open(TIM.save_path, "r")
	if file then
		for k, v in pairs(json.decode(file:read("*all")) or {}) do
			TIM._settings[k] = v
		end
		file:close()
	end
end

function TIM:debug(...)

	local printR=""
	for i,v in ipairs{...} do
		printR = printR .. tostring(v) .. ", "
	end
	managers.mission._fading_debug_output:script().log(printR,  Color.white)
end

function TIM:Post(clss, func, after_orig)
	Hooks:PostHook(clss, func, "TIM_"..func, after_orig)
end

function TIM:Check_badges(classHUD, badges, line_panel,  x)
	local wh = classHUD.line_height-5
	if classHUD.tabW then
		wh=classHUD.tabW*2
	end
	local badges_list = badges:split(",")
	local ext = Idstring("texture")
	
	for i = 1, #badges_list, 1 do
		local badge = badges_list[i]:split("/")
		
		if TIM.ChatBadges[badge[1]] == nil or (TIM.ChatBadges[badge[1]] and TIM.ChatBadges[badge[1]][badge[2]] == nil) then
			FileManager:AddFileWithCheck(ext, Idstring("assets/mod_overrides/Twitch Integration Mod emotes/badges/"..badge[1].."/"..badge[2]), "assets/mod_overrides/Twitch Integration Mod emotes/badges/"..badge[1].."/"..badge[2]..".png")		
			TIM.ChatBadges[badge[1]]= TIM.ChatBadges[badge[1]] or {}
			TIM.ChatBadges[badge[1]][badge[2]]=true
		end
		
		local emote_bitmap = line_panel:bitmap({
			visible = true, name ="twitch_icon",
			texture = "assets/mod_overrides/Twitch Integration Mod emotes/badges/"..badge[1].."/"..badge[2],
			layer = 0, alpha=1, color = Color(1, 1, 1), w = wh, h = wh,
			blend_mode = "add", x = x, y =0
		})
		x = emote_bitmap:right()
		emote_bitmap:set_center_y(HUDChat.line_height/2)
		emote_bitmap=nil
	end
	
	return x, #badges_list
end

function TIM:Check_emotes(emotes)
	emotes = string.sub(emotes, 1, #emotes -1)
	local emotes_list = emotes:split("/")
	local ext = Idstring("texture")
	for i = 1, #emotes_list, 1 do
		local emote = emotes_list[i]
		
		if TIM.ChatEmotes[emote] == nil then
			local path ="assets/mod_overrides/Twitch Integration Mod emotes/"..emote
			FileManager:AddFileWithCheck(ext, Idstring(path), "assets/mod_overrides/Twitch Integration Mod emotes/"..emote..".png")			
			TIM.ChatEmotes[emote]= path
		end
	end
end

function TIM:StopAllEffects()

end

function TIM:deleteAllRewards()
	if TIM._settings.UserID and TIM._settings.UserID ~="" then
		TIM.library.deleteAllCustomRewards()
	end
end

function TIM:Take_word_from_file()
	if TIM.GlobalEvents == false and managers.hud:script(PlayerBase.PLAYER_INFO_HUD_PD2).panel:child("point_of_no_return_panel"):visible()==false and TIM.BotPointsActive == true then		
		local rew_temp = TIM.library.get_reward()
		
		if rew_temp ~= "NULL" then
			TIM:Redeem_reward(rew_temp)
		end
	end
end

function TIM:fon_function()	
	local lin = TIM.hud.panel:bitmap({ name = "lin_bitmap", visible = false, layer = 0, color = Color(1, 1, 1), w = 1, h = 1, x =0, y =0 })
	return lin
end

function TIM:sign(x)
  return x>0 and 1 or x<0 and -1 or 0
end

function TIM:Chat_co_create()
	TIM.chatCO = coroutine.create(function()
		while true do
			coroutine.yield()
			if managers.network:session() then
				if TIM.LoadComplete==true or managers.network:session():local_peer():in_lobby()==true then
					if TIM.BotChatActive == true or TIM.BotPointsActive==true then
						local name, color, message, badges, emotes, isReward = TIM.library.get_message()
						if name ~= "NULL" then 
							if isReward==true and TIM._settings.enableRewardChatMessage == true then
								managers.chat:_receive_message_twitch(1, name, message, Color(color:sub(2)), badges, emotes, isReward)
							elseif isReward==false then
								managers.chat:_receive_message_twitch(1, name, message, Color(color:sub(2)), badges, emotes)
							end
						end
					end
				end
			end
			
			local k =1
		end
	end)
end

function TIM:Chat_co_resume()
	if TIM.BotChatActive==true then
		if tostring(coroutine.status(TIM.chatCO))=="dead" then
			TIM:Chat_co_create()
		end
		if TIM.chatCO then
			coroutine.resume(TIM.chatCO)
		end
	end
end

function TIM:lua_test(str, int1)
	managers.mission._fading_debug_output:script().log(tostring(str).." - "..tostring(int1),  Color.green)	
	return 23
end

