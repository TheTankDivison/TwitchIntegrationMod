function TIM:LoadRewardForms()
	local rewards_files = SystemFS:list(TIM.mod_path .. 'Effects', true)
	for i = 1, #rewards_files, 1 do
		local folder_name = rewards_files[i]
		local dataJSON = io.open(TIM.mod_path .. 'Effects\\'..folder_name..'\\data.json', "r")
		if dataJSON then
			TIM._effectsForms[folder_name]={}
			for k, v in pairs(json.decode(dataJSON:read("*all")) or {}) do
				TIM._effectsForms[folder_name][k] = v
			end
			dataJSON:close()
			dofile(TIM.mod_path .. 'Effects\\'..folder_name..'\\'..folder_name..'.lua')
		end
	end
	
end

function TIM:CheckTactic()
	if TIM.ModActive == true and TIM.validation == true then
		if managers.groupai:state():whisper_mode() == true then
			TIM:EnableTacticReward(true, 1)
			TIM:EnableTacticReward(true, 3)
			TIM:EnableTacticReward(false, 2)
		else
			TIM:EnableTacticReward(true, 2)
			TIM:EnableTacticReward(true, 3)
			TIM:EnableTacticReward(false, 1)
		end
	end
end

function TIM:CreateAllCPRewards()
	if #TIM._settings.TwitchRewards>0 and TIM._settings.Nickname ~="" and TIM.validation == true then 
		local titles={}
		local prompts={}
		local costs={} 
		local enables={} 
		local colors={} 
		local is_max_per_stream_enabled={} 
		local max_per_stream={} 
		local is_max_per_user_per_stream={} 
		local max_per_user_per_stream={} 
		local is_global_cooldown_seconds={} 
		local global_cooldown_seconds={}
		for rewardIDtemp, v in pairs(TIM._settings.TwitchRewards or {}) do
			titles[#titles+1]= TIM._settings.TwitchRewards[rewardIDtemp].title or "Error"
			prompts[#prompts+1]= TIM._settings.TwitchRewards[rewardIDtemp].prompt or ""
			costs[#costs+1]= TIM._settings.TwitchRewards[rewardIDtemp].cost or 1
			enables[#enables+1] = "false"--TIM._settings.TwitchRewards[rewardIDtemp].enabled
			colors[#colors+1]= TIM._settings.TwitchRewards[rewardIDtemp].background_color or "#FFFFFF"
			is_max_per_stream_enabled[#is_max_per_stream_enabled+1]= tostring(TIM._settings.TwitchRewards[rewardIDtemp].is_max_per_stream or false)
			max_per_stream[#max_per_stream+1]= TIM._settings.TwitchRewards[rewardIDtemp].max_per_stream or 0
			is_max_per_user_per_stream[#is_max_per_user_per_stream+1]= tostring(TIM._settings.TwitchRewards[rewardIDtemp].is_max_per_user_per_stream or false)
			max_per_user_per_stream[#max_per_user_per_stream+1]= TIM._settings.TwitchRewards[rewardIDtemp].max_per_user_per_stream or 0
			is_global_cooldown_seconds[#is_global_cooldown_seconds+1]= tostring(TIM._settings.TwitchRewards[rewardIDtemp].is_global_cooldown_seconds or false)
			global_cooldown_seconds[#global_cooldown_seconds+1]= TIM._settings.TwitchRewards[rewardIDtemp].global_cooldown_seconds or 0		
		end
		titles=table.concat(titles,"|")
		prompts=table.concat(prompts,"|")
		costs=table.concat(costs,"|")
		enables=table.concat(enables,"|")
		colors=table.concat(colors,"|")
		is_max_per_stream_enabled=table.concat(is_max_per_stream_enabled,"|")
		max_per_stream=table.concat(max_per_stream,"|")
		is_max_per_user_per_stream=table.concat(is_max_per_user_per_stream,"|")
		max_per_user_per_stream=table.concat(max_per_user_per_stream,"|")
		is_global_cooldown_seconds=table.concat(is_global_cooldown_seconds,"|")
		global_cooldown_seconds=table.concat(global_cooldown_seconds,"|")
		
		TIM.library.createListRewards(titles, prompts, costs, enables, colors, is_max_per_stream_enabled, max_per_stream, is_max_per_user_per_stream, max_per_user_per_stream, is_global_cooldown_seconds, global_cooldown_seconds, false)
		TIM:AddUpdater("CheckCreateAllCPRewards", TIM.CheckCreateAllCPRewards, false)
		
	end
end

function TIM:CheckCreateAllCPRewards()
	local str = TIM.library.getRewardIDs()
	if str ~= nil and str ~= "" then
		TIM:clbkCreateAllCPRewards(str)
	end
end

function TIM:clbkCreateAllCPRewards(str)
	TIM:RemoveUpdater("CheckCreateAllCPRewards")
	str = str:split("|")
	for i = 1, #str do
		TIM._settings.TwitchRewards[str[i]] = TIM._settings.TwitchRewards[i]
		TIM._settings.TwitchRewards[i] = nil
	end
	
end

function TIM:EnableAllCPRewards()
	if TIM.validation == true then 
		local rewStr=""
		for k, v in pairs(TIM._settings.TwitchRewards or {}) do
			rewStr=rewStr..k.."|"
			TIM._settings.TwitchRewards[k].enabled=true
		end
		--TIM.library.enableListRewards(rewStr, false)
	end
end

function TIM:DisableAllCPRewards()
	if TIM.validation == true then 
		local rewStr=""
		for k, v in pairs(TIM._settings.TwitchRewards or {}) do
			rewStr=rewStr..k.."|"
			TIM._settings.TwitchRewards[k].enabled=false
		end
		TIM.library.enableListRewards(rewStr, false)
	end
end

function TIM:DeleteAllCPRewards()
	if TIM.validation == true then 
		local rewStr=""
		local tempTable = {}
		for k, v in pairs(TIM._settings.TwitchRewards or {}) do
			rewStr=rewStr..k.."|"
			tempTable[#tempTable+1]=TIM._settings.TwitchRewards[k]
		end
		rewStr = string.sub(rewStr, 1, string.len(rewStr)-1)
		TIM._settings.TwitchRewards=tempTable
		TIM.library.deleteListRewards(rewStr, false)
	end
end

function TIM:Redeem_reward(rewardID, rewardRED, status)
	if TIM.validation == true then 
		if Network:is_server() then
			if TIM._settings.TwitchRewards[rewardID] ~= nil then
				for k, v in pairs(TIM._settings.TwitchRewards[rewardID].effects or {}) do
					TIM.effectsFunctions[k](rewardID)
				end
				local b, s = TIM.library.updateRedemptionCustomRew(rewardID, rewardRED, status)
			end		
		end
	end
end

function TIM:EnableTacticReward(is_enabled, tactic_filter) --tactic_filter 1- stealth, 2- loud, 3- stealth & loud
	if TIM.validation == true then 
		local rewStr=""
		for k, v in pairs(TIM._settings.TwitchRewards or {}) do
			if TIM._settings.TwitchRewards[k].tactic == tactic_filter and TIM._settings.TwitchRewards[k].enabled == true then
				rewStr=rewStr..k.."|"
			end
		end
		if rewStr ~= "" then
			rewStr = string.sub(rewStr, 1, string.len(rewStr)-1)
			TIM.library.enableListRewards(rewStr, is_enabled)
		end
	end
end

function TIM:Reward_co_create()
	TIM.rewardCo = coroutine.create(function()
		while true do
			coroutine.yield()
			local k =1
			if Utils:IsInHeist() == true and Utils:IsInCustody() == false and TIM.GlobalEvents==false then 
				local rew_id, rew_redemption = TIM.library.get_reward()
					
				if rew_id ~= "NULL" then
					TIM:Redeem_reward(rew_id, rew_redemption, true)
					local wait_time = TIM._settings.rewardCooldown + Application:time()
					local t = Application:time()
					Application:time()
					while wait_time > t do
						local dt = coroutine.yield()
						t = Application:time()
					end
					--wait(TIM._settings.rewardCooldown)
					local k =1
				end
			end
			
		end
	end)
end

function TIM:CheckReward()
	if Utils:IsInHeist() == true and Utils:IsInCustody() == false and TIM.GlobalEvents==false then 
		local rew_id, rew_redemption = TIM.library.get_reward()
		if rew_id ~= "NULL" then
			TIM:Redeem_reward(rew_id, rew_redemption, true)
		end
	end
end

function TIM:Reward_co_resume()
	if TIM.BotPointsActive==true then
		if tostring(coroutine.status(TIM.rewardCo))=="dead" then
			TIM:Reward_co_create()
		end
		if TIM.rewardCo then
			coroutine.resume(TIM.rewardCo)
		end
	end
end

function TIM:CreateSafe(safe_name,  points, elements_names, elements_rarity, names_paths, stat_boosts_points, stat_boosts_names, after_function, enableMusic)
	--managers.mission._fading_debug_output:script().log(tostring(1),  Color.green)
	TIM.GlobalEvents=true
	local num_spawn = 1
	local num_boost = 1
	local rarity = {common = "safe_data/common_frame", uncommon = "safe_data/uncommon_frame", rare = "safe_data/rare_frame", epic = "safe_data/epic_frame", legendary = "safe_data/legendary_frame"}
	local sounds_effects_rarity = {common = "safe_data/common-1", uncommon = "safe_data/uncommon-1", rare = "safe_data/rare-1", epic = "safe_data/epic-1", legendary = "safe_data/legend-1"}
	local colors_rarity = {common = Color(0,0.32,0.63), uncommon = Color(0.55,0.18,0.49), rare = Color(1,0.01,0.42), epic = Color(0.74,0.13,0.08), legendary = Color(0.95,0.64,0)}
	local window_panel = TIM.hud.panel:panel({ name = "window_panel", visible = false, layer = 0, alpha=1, color = Color(1, 1, 1, 1), w = 500, h = 84, x =0, y =100 })
	window_panel:set_center_x(TIM.hud.panel:center_x())
	local window_bitmap = window_panel:bitmap({ name = "window_bitmap",	visible = true, texture = "safe_data/line", layer = 6, alpha=1, w = 500, h = 84, x =0, y =0 })
	local text_line = window_panel:text({ y = 0, name = "text_line", align = "left", blend_mode = "normal", alpha = 0, x = 3, layer = 7, text = "Opening "..safe_name, font = tweak_data.menu.pd2_small_font, font_size = 15, color = Color.black})
	----------------------------------------------------------
	
	local summ_all_points = 0
	for i=1, #points, 1 do
		summ_all_points = summ_all_points + points[i]
	end
	
	local summ_all_boosts = 0
	if stat_boosts_points then 
		for i=1, #stat_boosts_points, 1 do
			summ_all_boosts = summ_all_boosts + stat_boosts_points[i]
		end
	end
	--managers.mission._fading_debug_output:script().log(tostring(2),  Color.green)
	local function find_number(summ_all_weights, array)
		
		local rnd = math.random(summ_all_weights)
		for i=1, #array, 1 do
			if rnd < array[i] then 
				return i
			end
			rnd = rnd - array[i]
		end
		return #array
	end
	local tableCellsCount = math.random(40,50)
	local all_cells_pan = window_panel:panel({ name = "all_cells_pan",	visible = true, layer = 1, alpha=1, color = Color(1, 1, 1), w = 111*tableCellsCount, h = 68, x =0, y =0 })
	all_cells_pan:set_bottom(window_bitmap:bottom())
	local numbers = {}
	for i=0, tableCellsCount-1, 1 do
		local num = find_number(summ_all_points, points)
		local num_s=0
		if stat_boosts_points then 
			num_s = find_number(summ_all_boosts, stat_boosts_points)
		end
		local cell_pan = all_cells_pan:panel({ name = "cell_pan", visible = true, layer = 1, alpha=1, color = Color(1, 1, 1), w = 111, h = 68, x =111*i, y =0 })
		local cell = cell_pan:bitmap({ name = "cell", visible = true, texture = rarity[elements_rarity[num]], layer = 1, alpha=1, color = Color(1, 1, 1), w = 111, h = 68, x =0, y =0 })
		local cell_image = cell_pan:bitmap({ name = "cell_image", visible = true, texture = names_paths[num], layer = 2, alpha=1, color = Color(1, 1, 1), w = 111, h = 53, x =0, y =0 })
		if num_s > 1 then
			local cell_boost = cell_pan:bitmap({ name = "cell_boost", visible = true, texture = "safe_data/boosticon", layer = 3, alpha=1, color = Color(1, 1, 1), w = 17, h = 17, x =0, y =0 })
			cell_boost:set_bottom(cell:bottom())
			cell_boost:set_right(cell:right())
		end
		local text = cell_pan:text({ y = 0, name = "say1", align = "left", blend_mode = "normal", halign = "left", x = 3, layer = 3, text = elements_names[num], font = tweak_data.menu.pd2_small_font, font_size = 15, color = Color.white })
		text:set_top(cell_pan:bottom()-16)
		table.insert(numbers, {num, num_s, cell_pan})		
	end
	num_spawn=numbers[#numbers-3][1]
	num_boost=numbers[#numbers-3][2]
	local prise_pan = numbers[#numbers-3][3]--..tostring(#numbers-3))
	--managers.mission._fading_debug_output:script().log(tostring(prise_pan:texture()),  Color.green)
	--managers.mission._fading_debug_output:script().log(tostring(true),  Color.green)
	local way = (tableCellsCount-6)*111+ math.random(-54,54)+28
	local cent_x = window_bitmap:world_x()
	local cent_y1 = window_bitmap:world_center_y()
	
	local cent_y = window_panel:center_y()
	window_panel:set_w(0)
	local c1x = all_cells_pan:world_x()
	local c1y = all_cells_pan:world_y()
	window_bitmap:animate(function(o)
	
	window_panel:set_visible(true)
		over(0.5, function(p)
			window_panel:set_w(math.lerp(0, 500, p))
			window_panel:set_h(math.lerp(0, 84, p))
			window_panel:set_center_x(TIM.hud.panel:center_x())
			window_panel:set_center_y(cent_y)
			all_cells_pan:set_world_x(c1x)
			all_cells_pan:set_world_y(c1y)
			window_bitmap:set_world_center_y(cent_y1)
			window_bitmap:set_world_center_x(window_panel:center_x())
		end)
		window_bitmap:set_x(0)
		text_line:set_x(3)
		over(0.5,function(p)
			text_line:set_alpha(math.lerp(0,1,p))
		end)
		local timerand = math.random(800,900)
		local temp=way 
		
		local function over1(seconds, f,  fixed_dt)
			local t = 0
			while true do
				local dt = coroutine.yield()
				t = t + (fixed_dt and 0.03333333333333333 or dt)
			
				if seconds <= t then
					break
				end
					--
				f(t / seconds, t)
				if math.abs(-1*way-all_cells_pan:left())<0.1 then
					
					break
				end
			end
			f(1, seconds)
		end
		local previous = 1--math.abs(all_cells_pan:left())+28
		local position_all_cell = all_cells_pan:left()-28
		--managers.mission._fading_debug_output:script().log(tostring(all_cells_pan:left()),  Color.green)
	over1(timerand,  function(p)
		all_cells_pan:set_left(math.lerp(all_cells_pan:left(),-1*way, p))
			
			if math.abs(position_all_cell)/previous >=111 then
				--managers.mission._fading_debug_output:script().log(tostring(all_cells_pan:left()).."-"..tostring(previous).."="..tostring(math.abs(all_cells_pan:left()-previous)),  Color.green)
				previous=previous+1--math.abs(all_cells_pan:left())---(math.abs(all_cells_pan:left()-previous)-111)+1
				local p = managers.menu_component._main_panel
				local name = "sound tick_sound"  
				if alive(p:child(name)) then
					managers.menu_component._main_panel:remove(p:child(name))
				end
				local volume = managers.user:get_setting("sfx_volume")
				local percentage = (volume - tweak_data.menu.MIN_SFX_VOLUME) / (tweak_data.menu.MAX_SFX_VOLUME - tweak_data.menu.MIN_SFX_VOLUME)
				managers.menu_component._main_panel:video({
					name = name,
					video = "safe_data/tick_sound",
					visible = false,
					loop = false,
				}):set_volume_gain(percentage+0.40)
			end
			position_all_cell = all_cells_pan:left()-28
	end)
	local gif = {}
	for i = 1, 45, 1 do
		local image = TIM.hud.panel:bitmap({ name = "sssss", visible = false, texture = "safe_data/animation/Cadr "..tostring(i), layer = 6, alpha=1, color = colors_rarity[elements_rarity[num_spawn]], w = 245, h = 150, x =0, y =0 })
		image:set_world_right(prise_pan:world_right()+67)
		image:set_world_center_y(prise_pan:world_center_y())
		table.insert(gif, image)
	end
	--managers.mission._fading_debug_output:script().log(tostring(3),  Color.green)
	local jj ={}
	jj[1] =1
	local function over4(seconds, f,  fixed_dt)
			local t = 0
			while true do
				local dt = coroutine.yield()
				t = t + (fixed_dt and 0.03333333333333333 or dt)
			
				
					--
				f(t / seconds, t)
				if jj[1]==45 then
					
					break
				end
			end
			f(1, seconds)
		end
	
	
	over4(2, function(p)
		if jj[1] <45 then
			gif[jj[1]]:set_visible(true)
			jj[1]=jj[1]+1
			gif[jj[1]]:set_visible(true)
			gif[jj[1]-1]:parent():remove(gif[jj[1]-1]) 
			numbers[#numbers-6][3]:set_alpha(math.lerp(numbers[#numbers-6][3]:alpha(), 0 ,p))
			numbers[#numbers-5][3]:set_alpha(math.lerp(numbers[#numbers-5][3]:alpha(), 0 ,p))
			numbers[#numbers-4][3]:set_alpha(math.lerp(numbers[#numbers-4][3]:alpha(), 0 ,p))
			numbers[#numbers-2][3]:set_alpha(math.lerp(numbers[#numbers-2][3]:alpha(), 0 ,p))
			numbers[#numbers-1][3]:set_alpha(math.lerp(numbers[#numbers-1][3]:alpha(), 0 ,p))
			numbers[#numbers][3]:set_alpha(math.lerp(numbers[#numbers][3]:alpha(), 0 ,p))
			window_bitmap:set_alpha(math.lerp(window_bitmap:alpha(), 0 ,p))
			text_line:set_alpha(math.lerp(text_line:alpha(), 0 ,p))
		end
	end)
    
	c1x = all_cells_pan:world_x()
	if enableMusic and enableMusic == true then
		local sound=sounds_effects_rarity[elements_rarity[num_spawn]]
		local p = managers.menu_component._main_panel
		local name = "sound"..sound
		if alive(p:child(name)) then
			managers.menu_component._main_panel:remove(p:child(name))
		end
		local volume = managers.user:get_setting("sfx_volume")
		local percentage = (volume - tweak_data.menu.MIN_SFX_VOLUME) / (tweak_data.menu.MAX_SFX_VOLUME - tweak_data.menu.MIN_SFX_VOLUME)
		local vid = window_panel:video({
			name = name,
			video = sound,
			visible = false,
			loop = false,
		}):set_volume_gain(percentage+0.15)
	end
	if num_boost>1 then
		local st1=TIM.hud.panel:bitmap({ name = "sssss", visible = true, texture = "safe_data/statboost1", layer = 3, alpha=1, color = Color(1, 1, 1), w = 1, h = 1, x =0, y =200 })
		local st2=TIM.hud.panel:bitmap({ name = "sssss", visible = true, texture = "safe_data/statboost2", layer = 2, alpha=1, color = Color(1, 1, 1), w = 1, h = 1, x =0, y =200 })
		local st3=TIM.hud.panel:bitmap({ name = "sssss", visible = false, texture = "safe_data/statboost3", layer = 1, alpha=1, color = Color(1, 1, 1), w = 100, h = 100, x =0, y =200 })
		local st4=TIM.hud.panel:bitmap({ name = "sssss", visible = false, texture = "safe_data/statboost4", layer = 1, alpha=1, color = Color(1, 1, 1), w = 100, h = 100, x =0, y =200 })
		local st5=TIM.hud.panel:bitmap({ name = "sssss", visible = false, texture = "safe_data/statboost5", layer = 1, alpha=1, color = Color(1, 1, 1), w = 100, h = 100, x =0, y =200 })
		local text_b1=TIM.hud.panel:panel({ name = "sssss",	visible = true, texture = "safe_data/statboost5", layer = 0, alpha=1, color = Color(1, 1, 1), w = 500, h = 200, x =0, y =200 })
		local text_b2=TIM.hud.panel:panel({ name = "sssss",	 visible = true, texture = "safe_data/statboost5", layer = 0, alpha=1, color = Color(1, 1, 1), w = 500, h = 200, x =0, y =200 })
		st1:set_center_x(TIM.hud.panel:center_x())
		st2:set_center_x(TIM.hud.panel:center_x())
		st3:set_center_x(TIM.hud.panel:center_x())
		st4:set_center_x(TIM.hud.panel:center_x())
		st5:set_center_x(TIM.hud.panel:center_x())
		over(0.3, function(p)				
			
			st2:set_w(math.lerp(st2:w(), 100, p))
			st2:set_h(math.lerp(st2:h(), 100, p))
			st2:set_center_x(TIM.hud.panel:center_x())
			st2:set_center_y(250)
		end)
		over(0.3, function(p)
			
			st1:set_w(math.lerp(st1:w(), 100, p))		
			st1:set_h(math.lerp(st1:h(), 100, p))	
			st1:set_center_x(TIM.hud.panel:center_x())
			st1:set_center_y(250)				
		end)
		st3:set_center_y(0)		
		st4:set_center_y(500)	
		st5:set_center_y(500)				
		over(0.3, function(p)
			st3:set_center_x(TIM.hud.panel:center_x())
			st4:set_center_x(math.lerp(TIM.hud.panel:center_x()-100,TIM.hud.panel:center_x(),p))
			st5:set_center_x(math.lerp(TIM.hud.panel:center_x()+100,TIM.hud.panel:center_x(),p))
			st3:set_center_y(math.lerp(0,250,p))
			st4:set_center_y(math.lerp(500,250,p))
			st5:set_center_y(math.lerp(500,250,p))
			st3:set_alpha(math.lerp(0,1,p))
			st4:set_alpha(math.lerp(0,1,p))
			st5:set_alpha(math.lerp(0,1,p))
			st3:set_visible(true)
			st4:set_visible(true)
			st5:set_visible(true)
		end)
		text_b1:set_world_right(st1:world_left()+10)
		text_b2:set_world_left(st1:world_right()-10)
		local tt1 = text_b1:text({ y = 25, name = "say1", align = "right", blend_mode = "normal", alpha = 1, x = 210, layer = 4, text = "STAT BOOST", font = tweak_data.menu.pd2_large_font, font_size = 40, color = Color.white })
		local tt2 = text_b2:text({ y = 25, name = "say1", align = "left", blend_mode = "normal", alpha = 1, x = -210, layer = 4, text = stat_boosts_names[num_boost], font = tweak_data.menu.pd2_large_font, font_size = 40, color = Color.white })
		over(0.5, function(p)
			tt1:set_x(math.lerp(210,-10,p))
			tt2:set_x(math.lerp(-210,10,p))
		end)
		wait(1)
		over(0.3, function(p)
			st1:set_alpha(math.lerp(1,0,p))
			st2:set_alpha(math.lerp(1,0,p))
			st3:set_alpha(math.lerp(1,0,p))
			st4:set_alpha(math.lerp(1,0,p))
			st5:set_alpha(math.lerp(1,0,p))
			tt1:set_alpha(math.lerp(1,0,p))
			tt2:set_alpha(math.lerp(1,0,p))
		end)
		st1:parent():remove(st1)
		st2:parent():remove(st2)
		st3:parent():remove(st3)
		st4:parent():remove(st4)
		st5:parent():remove(st5)
		text_b1:parent():remove(text_b1)
		text_b2:parent():remove(text_b2)
	end		
	local effect_params = {
		sound_event = "hlp_poof_small",
		effect = sounds_effects_rarity[elements_rarity[num_spawn]],
		camera_shake_max_mul = 0,
		sound_muffle_effect = false,
		feedback_range = 5* 2
	}
	--managers.mission._fading_debug_output:script().log(tostring("adter begin"),  Color.green)
		after_function(num_spawn, num_boost, effect_params)
		over(1, function(p)
			gif[45]:set_alpha(math.lerp(1,0,p))
			all_cells_pan:set_alpha(math.lerp(1, 0 ,p))
		end)
		gif[45]:parent():remove(gif[45]) 
		if enableMusic and enableMusic == true then 
			local music_volume = managers.user:get_setting("music_volume")
			local music_volume_t = music_volume/5
			local sfx_volume = managers.user:get_setting("sfx_volume")
			local sfx_volume_t = sfx_volume/5
			over(1, function(p)
				music_volume =math.lerp(music_volume, music_volume_t,p)
				sfx_volume= math.lerp(sfx_volume, sfx_volume_t,p)
				managers.video:volume_changed(sfx_volume)
				managers.music:set_volume(music_volume/100)
				SoundDevice:set_rtpc("option_sfx_volume", sfx_volume) 
			end)
			wait(14)
			over(1, function(p) 
				music_volume =math.lerp(music_volume, managers.user:get_setting("music_volume"),p)
				sfx_volume= math.lerp(sfx_volume, managers.user:get_setting("sfx_volume"),p)
				managers.video:volume_changed(sfx_volume)
				managers.music:set_volume(music_volume/100)
				SoundDevice:set_rtpc("option_sfx_volume", sfx_volume) 
			end)
		end
		TIM.GlobalEvents=false
		TIM.hud.panel:remove(TIM.hud.panel:child("window_panel"))
		--managers.mission._fading_debug_output:script().log(tostring("dead"),  Color.green)
	end)
end


