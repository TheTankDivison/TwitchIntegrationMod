function TIM:createChatAIRewards()
	
	TIM.chatAIrewardsCreated=true
	function GroupAIStateBase:convert_hostage_to_criminal_TIM(unit, peer_unit)
		local player_unit = peer_unit or managers.player:player_unit()

		if not alive(player_unit) or not self._criminals[player_unit:key()] then
			return
		end

		if not alive(unit) then
			return
		end

		local u_key = unit:key()
		local u_data = self._police[u_key]

		if not u_data then
			return
		end

		local minions = self._criminals[player_unit:key()].minions or {}
		self._criminals[player_unit:key()].minions = minions



		local group = u_data.group
		u_data.group = nil

		if group then
			self:_remove_group_member(group, u_key, nil)
		end

		self:set_enemy_assigned(nil, u_key)

		u_data.is_converted = true

		unit:brain():convert_to_criminal(peer_unit)

		local clbk_key = "Converted" .. tostring(player_unit:key())
		u_data.minion_death_clbk_key = clbk_key
		u_data.minion_destroyed_clbk_key = clbk_key

		unit:character_damage():add_listener(clbk_key, {
			"death"
		}, callback(self, self, "clbk_minion_dies", player_unit:key()))
		unit:base():add_destroy_listener(clbk_key, callback(self, self, "clbk_minion_destroyed", player_unit:key()))

		if not unit:contour() then
			debug_pause_unit(unit, "[GroupAIStateBase:convert_hostage_to_criminal]: Unit doesn't have Contour Extension")
		end

		unit:contour():add("friendly", nil, nil, not peer_unit and tweak_data.contour.character.friendly_minion_color)

		u_data.so_access = unit:brain():SO_access()

		self:_set_converted_police(u_key, unit, player_unit)

		minions[u_key] = u_data

		unit:movement():set_team(self._teams.converted_enemy)

		local convert_enemies_health_multiplier_level = 0
		local passive_convert_enemies_health_multiplier_level = 0

		if alive(peer_unit) then
			convert_enemies_health_multiplier_level = peer_unit:base():upgrade_level("player", "convert_enemies_health_multiplier") or 0
			passive_convert_enemies_health_multiplier_level = peer_unit:base():upgrade_level("player", "passive_convert_enemies_health_multiplier") or 0
		else
			convert_enemies_health_multiplier_level = managers.player:upgrade_level("player", "convert_enemies_health_multiplier")
			passive_convert_enemies_health_multiplier_level = managers.player:upgrade_level("player", "passive_convert_enemies_health_multiplier")
		end

		local owner_peer_id = managers.network:session():peer_by_unit(player_unit):id()

		managers.network:session():send_to_peers_synched("mark_minion", unit, owner_peer_id, convert_enemies_health_multiplier_level, passive_convert_enemies_health_multiplier_level)

		if not peer_unit then
			managers.player:count_up_player_minions()
		end

		managers.modifiers:run_func("OnMinionAdded")
	end
	TIM._ListAI={}
	
	local titles={"Spawn your character", "Character status", "Upgrade character level", "Restore health", "Increase damage", "Drop ammo"}
	local prompts={"Spawns friendly AI with your nickname", "Check your character status, health and damage stats", "Upgrades your character", "Heals your character to 100%", "Increases damage of your character by 15%", "Drops ammo under your character"}
	local costs={TIM._settings.ChatAI.SpawnPrice, TIM._settings.ChatAI.CharacterStatusPrice, TIM._settings.ChatAI.DefaultUpgradePrice, TIM._settings.ChatAI.RestoreHealthPrice, TIM._settings.ChatAI.IncreaseDamagePrice, TIM._settings.ChatAI.DropAmmoPrice}
	local enables={"true", "true", "true", "true", "true", "true"}
	local colors={"#"..TIM._settings.ChatAI.SpawnColor, "#"..TIM._settings.ChatAI.CharacterStatusColor, "#"..TIM._settings.ChatAI.DefaultUpgradeColor, "#"..TIM._settings.ChatAI.RestoreHealthColor, "#"..TIM._settings.ChatAI.IncreaseDamageColor, "#"..TIM._settings.ChatAI.DropAmmoColor}
	local is_max_per_stream_enabled={"false", "false", "false", "false", "false", "false"}
	local max_per_stream={0,0,0,0,0,0}
	local is_max_per_user_per_stream={"false", "false", "false", "false", "false", "false"}
	local max_per_user_per_stream={0,0,0,0,0,0}
	local is_global_cooldown_seconds={"false", "false", "false", "false", "false", "false"}
	local global_cooldown_seconds={0,0,0,0,0,0}
	
	TIM.ChatAILevels={}
  --TIM.ChatAILevels[#TIM.ChatAILevels+1]={unit_name="units/payday2/characters/ene_security_1/ene_security_1", reduction=100} --security guard
	TIM.ChatAILevels[#TIM.ChatAILevels+1]={unit_name="units/payday2/characters/ene_cop_2/ene_cop_2", reduction=90} --cop
	TIM.ChatAILevels[#TIM.ChatAILevels+1]={unit_name="units/payday2/characters/ene_fbi_3/ene_fbi_3", reduction=80} --HRT
	TIM.ChatAILevels[#TIM.ChatAILevels+1]={unit_name="units/payday2/characters/ene_swat_1/ene_swat_1", reduction=70}
	TIM.ChatAILevels[#TIM.ChatAILevels+1]={unit_name="units/payday2/characters/ene_swat_heavy_1/ene_swat_heavy_1", reduction=65} --normal swat
	TIM.ChatAILevels[#TIM.ChatAILevels+1]={unit_name="units/payday2/characters/ene_sm_swat_1/ene_sm_swat_1", reduction=40} --light dw swat
	TIM.ChatAILevels[#TIM.ChatAILevels+1]={unit_name="units/payday2/characters/ene_city_heavy_g36/ene_city_heavy_g36", reduction=30} --heavy dw swat
  --TIM.ChatAILevels[#TIM.ChatAILevels+1]={unit_name="units/payday2/characters/ene_shield_2/ene_shield_2", reduction=100} --shield normal
	TIM.ChatAILevels[#TIM.ChatAILevels+1]={unit_name="units/payday2/characters/ene_shield_1/ene_shield_1", reduction=20} --shield dw 
	TIM.ChatAILevels[#TIM.ChatAILevels+1]={unit_name="units/pd2_dlc_vip/characters/ene_phalanx_1/ene_phalanx_1", reduction=0} --winters shield
	TIM.ChatAILevels[#TIM.ChatAILevels+1]={unit_name="units/payday2/characters/ene_bulldozer_1/ene_bulldozer_1", reduction=0} --green dozer
  --TIM.ChatAILevels[#TIM.ChatAILevels+1]={unit_name="units/payday2/characters/ene_bulldozer_2/ene_bulldozer_2", reduction=100} --black dozer
  --TIM.ChatAILevels[#TIM.ChatAILevels+1]={unit_name="units/payday2/characters/ene_bulldozer_3/ene_bulldozer_3", reduction=100} --skull dozer

	
	TIM.ChatAIFucntions = {}
	TIM.ChatAIFucntions[1] = function(rewardID, redemptionID, nickname) -- "Spawn your character"
		if TIM._ListAI[nickname] and tostring(TIM._ListAI[nickname].unit)~="[Unit NULL]" and TIM._ListAI[nickname].unit:character_damage() and not TIM._ListAI[nickname].unit:character_damage():dead() then
			TIM:UpdateRedemption(rewardID, redemptionID, false, "@"..nickname.." Your AI character is still alive. Channel points have been refunded.")
		elseif TIM._ListAI[nickname] and tostring(TIM._ListAI[nickname].unit)~="[Unit NULL]" and TIM._ListAI[nickname].unit:character_damage() and TIM._ListAI[nickname].unit:character_damage():dead() then
			managers.hud:_remove_name_label(TIM._ListAI[nickname].name_label_id)
			TIM:SpawnUnitChatAI(TIM.ChatAILevels[1].unit_name, nickname, TIM.ChatAILevels[1].reduction/100)
			TIM:UpdateRedemption(rewardID, redemptionID, true)
		else
			TIM:SpawnUnitChatAI(TIM.ChatAILevels[1].unit_name, nickname, TIM.ChatAILevels[1].reduction/100)
			TIM:UpdateRedemption(rewardID, redemptionID, true)
		end
	end
	TIM.ChatAIFucntions[2] = function(rewardID, redemptionID, nickname) -- "Character status"
		local status_message = "@"..nickname.." Status: "
		if TIM._ListAI[nickname] and tostring(TIM._ListAI[nickname].unit)~="[Unit NULL]" and TIM._ListAI[nickname].unit:character_damage() and not TIM._ListAI[nickname].unit:character_damage():dead() then
			status_message=status_message.."alive"
			status_message=status_message.." | LvL. "..tostring(TIM._ListAI[nickname].level)
			status_message=status_message.." | Health: "..tostring(TIM._ListAI[nickname].unit:character_damage():health_ratio()*100).."%"
			status_message=status_message.." | Damage boost: "..tostring(TIM._ListAI[nickname].unit:base():get_total_buff("base_damage")*100).."%"
		else
			status_message=status_message.."dead"
		end
		TIM.library.sendMessageToChat(status_message)
		TIM:UpdateRedemption(rewardID, redemptionID, true)
	end
	TIM.ChatAIFucntions[3] = function(rewardID, redemptionID,nickname) -- "Upgrade character level"
		if TIM._ListAI[nickname] and tostring(TIM._ListAI[nickname].unit)~="[Unit NULL]" and TIM._ListAI[nickname].unit:character_damage() and not TIM._ListAI[nickname].unit:character_damage():dead() then
			local unit = TIM._ListAI[nickname].unit
			local lvl = TIM._ListAI[nickname].level
			local health_percentage = unit:character_damage():health_ratio()
			if lvl < #TIM.ChatAILevels then
				unit:character_damage():damage_mission({ damage = unit:character_damage()._HEALTH_INIT + 1 })
				managers.hud:_remove_name_label(TIM._ListAI[nickname].name_label_id)
				TIM._ListAI[nickname]=nil
				TIM:SpawnUnitChatAI(TIM.ChatAILevels[lvl+1].unit_name, nickname, TIM.ChatAILevels[lvl+1].reduction/100)
				TIM._ListAI[nickname].level=lvl+1
				local health = TIM._ListAI[nickname].unit:character_damage():get_health()
				TIM._ListAI[nickname].unit:character_damage():set_health(health*health_percentage)
				TIM:UpdateRedemption(rewardID, redemptionID, true)
			else
				TIM:UpdateRedemption(rewardID, redemptionID, false, "@"..nickname.." Your AI character reached maximum level. Channel points have been refunded.")
			end
		else
			TIM:UpdateRedemption(rewardID, redemptionID, false, "@"..nickname.." Your AI character is dead. Channel points have been refunded.")
		end
	end
	TIM.ChatAIFucntions[4] = function(rewardID, redemptionID, nickname) -- "Restore health"
		if TIM._ListAI[nickname] and tostring(TIM._ListAI[nickname].unit)~="[Unit NULL]" and TIM._ListAI[nickname].unit:character_damage() and not TIM._ListAI[nickname].unit:character_damage():dead() then
			
			if TIM._ListAI[nickname].unit:movement() and TIM:HealUnitChatAI(TIM._ListAI[nickname].unit, true) then
				TIM._ListAI[nickname].unit:movement():action_request({
					body_part = 3,
					type = "healed",
					client_interrupt = false
				})
			end
			TIM:UpdateRedemption(rewardID, redemptionID, true)
		else
			TIM:UpdateRedemption(rewardID, redemptionID, false, "@"..nickname.." Your AI character is dead. Channel points have been refunded.")
		end
	end
	TIM.ChatAIFucntions[5] = function(rewardID, redemptionID, nickname) -- "Increase damage"
		if TIM._ListAI[nickname] and tostring(TIM._ListAI[nickname].unit)~="[Unit NULL]" and TIM._ListAI[nickname].unit:character_damage() and not TIM._ListAI[nickname].unit:character_damage():dead() then
			TIM._ListAI[nickname].unit:base():add_buff("base_damage", 15/100)
			TIM:UpdateRedemption(rewardID, redemptionID, true)
		else
			TIM:UpdateRedemption(rewardID, redemptionID, false, "@"..nickname.." Your AI character is dead. Channel points have been refunded.")
		end
	end
	TIM.ChatAIFucntions[6] = function(rewardID, redemptionID, nickname) -- "Drop ammo"
		if TIM._ListAI[nickname] and tostring(TIM._ListAI[nickname].unit)~="[Unit NULL]" and TIM._ListAI[nickname].unit:character_damage() and not TIM._ListAI[nickname].unit:character_damage():dead() then
			local unit = TIM._ListAI[nickname].unit
			World:spawn_unit(Idstring("units/pickups/ammo/ammo_pickup"), unit:position(), unit:rotation())
			TIM:UpdateRedemption(rewardID, redemptionID, true)
		else
			TIM:UpdateRedemption(rewardID, redemptionID, false, "@"..nickname.." Your AI character is dead. Channel points have been refunded.")
		end
	end
	
	local titles_s=table.concat(titles,"|")
	local prompts_s=table.concat(prompts,"|")
	local costs_s=table.concat(costs,"|")
	local enables_s=table.concat(enables,"|")
	local colors_s=table.concat(colors,"|")
	local is_max_per_stream_enabled_s=table.concat(is_max_per_stream_enabled,"|")
	local max_per_stream_s=table.concat(max_per_stream,"|")
	local is_max_per_user_per_stream_s=table.concat(is_max_per_user_per_stream,"|")
	local max_per_user_per_stream_s=table.concat(max_per_user_per_stream,"|")
	local is_global_cooldown_seconds_s=table.concat(is_global_cooldown_seconds,"|")
	local global_cooldown_seconds_s=table.concat(global_cooldown_seconds,"|")
	
	TIM.library.createListRewards(titles_s, prompts_s, costs_s, enables_s, colors_s, is_max_per_stream_enabled_s, max_per_stream_s, is_max_per_user_per_stream_s, max_per_user_per_stream_s, is_global_cooldown_seconds_s, global_cooldown_seconds_s, false)
	
	function TIM:Check2()
		local str = TIM.library.getRewardIDs()
		--TIM:debug(str)
		if str ~= nil and str ~= "" then
			
			TIM:clbkCreateAllChatAIRewards(str)
			
		end
	end
	
end

function TIM:UpdateRedemption(rewardID, redemptionID, status, message)
	if message then
		TIM.library.sendMessageToChat(message)
	end
	TIM.library.updateRedemptionCustomRew(rewardID, redemptionID, status)
end

function TIM:deleteChatAIRewards()
	local rewStr=""
	for k, v in pairs(TIM._settings.Temp_ChatAI_IDs or {}) do
		rewStr=rewStr..k.."|"
	end
	TIM._settings.Temp_ChatAI_IDs={}
	if rewStr~="" then
		rewStr = string.sub(rewStr, 1, string.len(rewStr)-1)
		TIM.library.deleteListRewards(rewStr)
	end
	
end 

function TIM:DisableChatAI()
	TIM._settings.Temp_ChatAI_IDs={}
	TIM:deleteAllRewards()
	if Utils:IsInHeist() == true then 
		for k, v in pairs(TIM._ListAI or {}) do
			if TIM._ListAI[k].unit and tostring(TIM._ListAI[k].unit)~="[Unit NULL]" then
				TIM._ListAI[k].unit:character_damage():damage_mission({ damage = TIM._ListAI[k].unit:character_damage()._HEALTH_INIT + 1 })
				managers.hud:_remove_name_label(TIM._ListAI[k].name_label_id)
			end
		end
	end
	TIM._ListAI={}
	TIM:save_settings()
end

function TIM:clbkCreateAllChatAIRewards(str)
	
	function TIM:Check2()
	
	end
	TIM._settings.Temp_ChatAI_IDs = {}
	str = str:split("|")
	for i = 1, #str do
		TIM._settings.Temp_ChatAI_IDs[str[i]] = i -- TIM.namesVariants[TIM.listOfNames[i]]
		
	end
	TIM.chatAIrewardsCreated=true
	TIM:save_settings()
end

function TIM:CheckTacticChatAI()
	if TIM.ModActive == true then
		if managers.groupai:state():whisper_mode() == true then
			
		else
			TIM:createChatAIRewards()
		end
	end
end

function TIM:SpawnUnitChatAI(unit_name, nickname, reduction)
	if TIM._ListAI[nickname] and tostring(TIM._ListAI[nickname].unit)~="[Unit NULL]" and TIM._ListAI[nickname].unit:character_damage() and not TIM._ListAI[nickname].unit:character_damage():dead() then
		return false
	else
		TIM._ListAI[nickname]={}
		local pp = managers.player:local_player()
		local unit = TIM:Spawn_unit(true, Idstring(unit_name), pp:position(), pp:rotation()) 

		managers.groupai:state():convert_hostage_to_criminal_TIM(unit)
		local name_label_id = managers.hud:_add_name_label({
			name = nickname,
			unit = unit
		})
		unit:character_damage():convert_to_criminal(1-reduction)
		TIM._ListAI[nickname].unit=unit
		TIM._ListAI[nickname].level=1
		TIM._ListAI[nickname].name_label_id = name_label_id
		return true
	end
end

function TIM:HealUnitChatAI(unit, override_cooldown)
	local cop_dmg = unit:character_damage()
	cop_dmg._health = cop_dmg._HEALTH_INIT
	cop_dmg._health_ratio = 1

	cop_dmg:_update_debug_ws()
	managers.network:session():send_to_peers("sync_medic_heal", unit)
	return true
end

function TIM:UpgradeUnitChatAI(nickname, upgradeType)
	if TIM._ListAI[nickname] and tostring(TIM._ListAI[nickname].unit)~="[Unit NULL]" and TIM._ListAI[nickname].unit:character_damage() and not TIM._ListAI[nickname].unit:character_damage():dead() then
		
		return true
	else
		return false
	end
end


function TIM:Redeem_ChatAI_reward(rewardID, red_id, nickname)
	if Network:is_server() then
		
		if TIM._settings.Temp_ChatAI_IDs[rewardID] ~= nil then
			local index = TIM._settings.Temp_ChatAI_IDs[rewardID]
			TIM.ChatAIFucntions[index](rewardID, red_id, nickname)
		end		
	end
end

function TIM:Upgrade_ChatAI_co_create()
	TIM.upgradeChatAICo = coroutine.create(function()
		while true do
			coroutine.yield()
			if Utils:IsInHeist() == true then 
				local rew_id, red_id, nickname = TIM.library.get_reward()
					
				if rew_id ~= "NULL" then
					TIM:Redeem_ChatAI_reward(rew_id, red_id, nickname)
				end
			end
			
		end
	end)
end

function TIM:Upgrade_ChatAI_co_resume()
	if TIM.BotPointsActive==true then
		if tostring(coroutine.status(TIM.upgradeChatAICo))=="dead" then
			TIM:Upgrade_ChatAI_co_create()
		end
		if TIM.upgradeChatAICo then
			coroutine.resume(TIM.upgradeChatAICo)
		end
	end
end
