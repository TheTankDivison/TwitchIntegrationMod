function TIM:BaseTimerEvent(nameOfFucn, funcBefore, funcAfter, startUpgrade, maximumUpgrade, paramBefore, paramAfter)
	local toAdd =(maximumUpgrade/TIM._settings.Maximum_upgrade_level) * (TIM.PollEffectsForms[nameOfFucn].Upgrade.Level-1)
	
	if TIM.PollFunctionsActiveTime[nameOfFucn] and TIM.PollFunctionsActiveTime[nameOfFucn]>0 then
		TIM.PollFunctionsActiveTime[nameOfFucn] = TIM.PollFunctionsActiveTime[nameOfFucn] + startUpgrade + toAdd
	else
		local lin1 = TIM:fon_function()
		lin1:animate(function(o)
			funcBefore(paramBefore)
			TIM.PollFunctionsActiveTime[nameOfFucn] = startUpgrade + toAdd--TIM._settings.PollsDuration + TIM._settings.PollsCooldown
			while TIM.PollFunctionsActiveTime[nameOfFucn] >0 do
				wait(1)
				TIM.PollFunctionsActiveTime[nameOfFucn]=TIM.PollFunctionsActiveTime[nameOfFucn]-1
			end
			while Utils:IsInCustody() == true do
				wait(1)
			end
			funcAfter(paramAfter)
			lin1:parent():remove(lin1)
		end)
	end
end

function TIM:StartDelayPolls()
	if TIM._settings.enableGlobalEvents==true and TIM.ModActive==true and Network:is_server()==true then
		TIM:deleteAllRewards()
		local lin1 = TIM:fon_function()
		TIM.tablePollsList = {}
		for k, v in pairs(TIM._settings.chosenPollsEffects or {}) do
			--TIM:debug(k, v)
			if v==true then 
				TIM.tablePollsList[#TIM.tablePollsList+1]=k
			end
		end
		lin1:animate(function(o)
			wait(TIM._settings.PollsStartDelay)
			while (Utils:IsInCustody() == true) do
				wait(1)
			end
			TIM:StartPoll()
		end)
	end
end

function TIM:deleteUpgradeRewards()
	TIM:deleteAllRewards()
	TIM._settings.TempPollsUpgradeIDs={}
end

function TIM:EndPoll()
	TIM.library.endPoll()
	TIM:deleteAllRewards()
	TIM._settings.TempPollsUpgradeIDs={}
	
	TIM:save_settings()
	function TIM:Check2()
	
	end
end

function TIM:LoadPolls()
	local poll_files = SystemFS:list(TIM.mod_path .. 'GlobalEvents', true)
	for i = 1, #poll_files, 1 do
		local folder_name = poll_files[i]
		local dataJSON = io.open(TIM.mod_path .. 'GlobalEvents\\'..folder_name..'\\data.json', "r")
		if dataJSON then
			TIM.PollEffectsForms[folder_name]={}
			for k, v in pairs(json.decode(dataJSON:read("*all")) or {}) do
				TIM.PollEffectsForms[folder_name][k] = v
			end
			TIM.PollEffectsForms[folder_name].Upgrade.Level=1
			dataJSON:close()
			dofile(TIM.mod_path .. 'GlobalEvents\\'..folder_name..'\\'..folder_name..'.lua')
		end
	end
end

function TIM:clbkCreateAllUpgradeRewards(str)
	function TIM:Check2()
	
	end
	TIM._settings.TempPollsUpgradeIDs = {}
	str = str:split("|")
	for i = 1, #str do
		TIM._settings.TempPollsUpgradeIDs[str[i]] = TIM.namesVariants[TIM.listOfNames[i]]
		
	end
	TIM:save_settings()
end


function TIM:UpgradeEvent(eventID, rewardID)
	local level =  TIM.PollEffectsForms[eventID].Upgrade.Level + 1
	--local rewardID = TIM.PollEffectsForms[eventID].Upgrade.rewardID
	local title = TIM.PollEffectsForms[eventID].Upgrade.Name .." LvL. "..level
	local prompt = TIM.PollEffectsForms[eventID].Upgrade.Description
	local cost = TIM._settings.Default_upgrade_price+ TIM._settings.Upgrade_price_step_per_level * (level-1)
	TIM.PollEffectsForms[eventID].Upgrade.Level = level 
	local change = TIM._settings.Maximum_upgrade_level - level
	if change ~= 0 then
		TIM.library.editRewFon(rewardID, title, prompt, cost, true, "#000000", true, change, false, 0, false, 0,true)	
	end
end

function TIM:StartPoll()
	
	if TIM._settings.enableGlobalEvents==true and TIM.ModActive==true and Network:is_server() then
		
		local lin1 = TIM:fon_function()
		lin1:animate(function(o)
			TIM.listOfNames ={}
			local tables = {}						
			local titles={}
			local prompts={}
			local costs={} 
			local enables={} 
			local colors={} 
			local is_max_per_stream_enabled={} 
			local max_per_stream={} 
			local is_max_per_user_per_stream={} 
			local max_per_user_per_stream={} 
			local is_global_cooldown_seconds={} 
			local global_cooldown_seconds={}
			for i=1, #TIM.tablePollsList, 1 do
				tables[#tables+1]=TIM.tablePollsList[i]
			end
			
			TIM.namesVariants={}
			local variants_count = #tables> TIM._settings.PollsVariantsCount and TIM._settings.PollsVariantsCount or #tables
			for i = 1, variants_count, 1 do
				local tableNum= math.random(#tables)
				local idName = tables[tableNum]
				local name = TIM.PollEffectsForms[idName].Name
				titles[#titles+1]= TIM.PollEffectsForms[idName].Upgrade.Name.." LvL. "..TIM.PollEffectsForms[idName].Upgrade.Level
				prompts[#prompts+1]=TIM.PollEffectsForms[idName].Upgrade.Description
				costs[#costs+1]=TIM._settings.Default_upgrade_price+((TIM.PollEffectsForms[idName].Upgrade.Level-1)*TIM._settings.Upgrade_price_step_per_level)
				if TIM.PollEffectsForms[idName].Upgrade.Level<=TIM._settings.Maximum_upgrade_level then
					enables[#enables+1]="true"
				else
					enables[#enables+1]="false"
				end
				colors[#colors+1]="#000000"
				is_max_per_stream_enabled[#is_max_per_stream_enabled+1]="true"
				max_per_stream[#max_per_stream+1]=TIM._settings.Maximum_upgrade_level-TIM.PollEffectsForms[idName].Upgrade.Level
				is_max_per_user_per_stream[#is_max_per_user_per_stream+1]="false"
				max_per_user_per_stream[#max_per_user_per_stream+1]=0
				is_global_cooldown_seconds[#is_global_cooldown_seconds+1]="false"
				global_cooldown_seconds[#global_cooldown_seconds+1]=0
				
				TIM.listOfNames[#TIM.listOfNames+1] = name
				TIM.namesVariants[name]=idName
				table.remove(tables, tableNum)
			end
			while (Utils:IsInCustody() == true) do
				wait(1)
			end

			local titles_s=table.concat(titles,"|")
			local prompts_s=table.concat(prompts,"|")
			local costs_s=table.concat(costs,"|")
			local enables_s=table.concat(enables,"|")
			local colors_s=table.concat(colors,"|")
			local is_max_per_stream_enabled_s=table.concat(is_max_per_stream_enabled,"|")
			local max_per_stream_s=table.concat(max_per_stream,"|")
			local is_max_per_user_per_stream_s=table.concat(is_max_per_user_per_stream,"|")
			local max_per_user_per_stream_s=table.concat(max_per_user_per_stream,"|")
			local is_global_cooldown_seconds_s=table.concat(is_global_cooldown_seconds,"|")
			local global_cooldown_seconds_s=table.concat(global_cooldown_seconds,"|")
			
			TIM.library.createListRewards(titles_s, prompts_s, costs_s, enables_s, colors_s, is_max_per_stream_enabled_s, max_per_stream_s, is_max_per_user_per_stream_s, max_per_user_per_stream_s, is_global_cooldown_seconds_s, global_cooldown_seconds_s, true)
			
			TIM.library.createPoll(TIM.loc.PollText, TIM._settings.PollsDuration, variants_count, TIM.listOfNames[1],TIM.listOfNames[2],TIM.listOfNames[3],TIM.listOfNames[4],TIM.listOfNames[5], TIM._settings.PollsBitsEnabled, TIM._settings.PollsBitsPerVote, TIM._settings.PollsCPEnabled, TIM._settings.PollsCPPerVote)
			
			function TIM:Check2()
				local str = TIM.library.getRewardIDs()
				if str ~= nil and str ~= "" then
					TIM:clbkCreateAllUpgradeRewards(str)
				end
			end
			local sec = 0
			while TIM.ModActive==true and sec <= TIM._settings.PollsDuration do
				wait(1)
				sec=sec+1
			end
			if TIM._settings.enableGlobalEvents==true and TIM.ModActive==true then
				while (Utils:IsInCustody() == true) do
					wait(1)
				end
				TIM.library.getPoll(id)
				TIM.BotPollActive=true
			end
			
		end)
	end
end

function TIM:PollGetResult()
	
	if TIM.BotPollActive==true then
		
		
		local err, answer = TIM.library.getPollResult()
		if err==true then
			TIM:debug("Poll error!", answer)
			TIM.BotPollActive=false
			local lin1 = TIM:fon_function()
			lin1:animate(function(o)
				local sec = 0
				while TIM.ModActive==true and sec <= TIM._settings.PollsCooldown do
					wait(1)
					sec=sec+1
				end
				
				if TIM._settings.enableGlobalEvents==true and TIM.ModActive==true then
					while (Utils:IsInCustody() == true) do
						wait(1)
					end
					TIM:StartPoll()
				end
			end)
		elseif answer ~="" then
			TIM.BotPollActive=false
			--TIM:debug("TIM:PollGetResult()")
			local answer2 = json.decode(answer)
			local choices = answer2.data[1].choices
			local winnerIDs={}
			winnerIDs[1]=1
			--TIM:debug(choices[1].title, choices[1].votes)
			for i=2, #choices, 1 do
				--TIM:debug(choices[i].title, choices[i].votes)
				if choices[i].votes >choices[winnerIDs[1]].votes then
					winnerIDs={}
					winnerIDs[1]=i
				elseif choices[i].votes==choices[winnerIDs[1]].votes then
					--table.insert(winnerIDs, i)
					winnerIDs[#winnerIDs+1]=i
				end
			
			end
			local winID=0
			if #winnerIDs>1 then
				winID = math.random(#winnerIDs)
			else
				winID = winnerIDs[1]
			end
			
			local id = TIM.namesVariants[choices[winID].title]
			managers.chat:_receive_message_twitch(1, "Global event", choices[winID].title.." LvL. "..TIM.PollEffectsForms[id].Upgrade.Level .."!", Color("828282"), "")
			
			TIM:deleteUpgradeRewards()
			TIM:save_settings()
			
			
			local lin1 = TIM:fon_function()
			lin1:animate(function(o)
				if Utils:IsInHeist() == true then 
					while (Utils:IsInCustody() == true) do
						wait(1)
					end
					TIM.PollFunctions[id]()
					local sec = 0
					while TIM.ModActive==true and sec <= TIM._settings.PollsCooldown+1 do
						wait(1)
						sec=sec+1
					end
					if TIM._settings.enableGlobalEvents==true and TIM.ModActive==true then
						TIM:StartPoll()
					end
				end
				lin1:parent():remove(lin1)
			end)
			
		end
	end
end

function TIM:Redeem_event_upgrade(rewardID)
	if Network:is_server() then
		if TIM._settings.TempPollsUpgradeIDs[rewardID] ~= nil then
			
			TIM:UpgradeEvent(TIM._settings.TempPollsUpgradeIDs[rewardID], rewardID)
			
		end		
	end
end

function TIM:Upgrade_reward_co_create()
	TIM.upgradeRewardCo = coroutine.create(function()
		while true do
			coroutine.yield()
			local k =1
			if Utils:IsInHeist() == true then 
				local rew_id = TIM.library.get_reward()
					
				if rew_id ~= "NULL" then
					TIM:Redeem_event_upgrade(rew_id)
				end
			end
			
		end
	end)
end

function TIM:Upgrade_reward_co_resume()
	if TIM.BotPointsActive==true then
		if tostring(coroutine.status(TIM.upgradeRewardCo))=="dead" then
			TIM:Upgrade_reward_co_create()
		end
		if TIM.upgradeRewardCo then
			coroutine.resume(TIM.upgradeRewardCo)
		end
	end
end