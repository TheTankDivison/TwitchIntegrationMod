
function TIM.effectsFunctions.textmessage(rewardID)
	
	managers.chat:send_message(ChatManager.GAME, managers.network.account:username(), TIM._settings.TwitchRewards[rewardID].effects.textmessage.message.Value)
end