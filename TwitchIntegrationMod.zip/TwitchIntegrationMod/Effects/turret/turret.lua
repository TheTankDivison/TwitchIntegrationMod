
function TIM.effectsFunctions.turret(rewardID)
	
	local spawnType = false
	if TIM._settings.TwitchRewards[rewardID].effects.turret.spawnType.SelectedItem == "onPlayer" then
		spawnType = true
	elseif TIM._settings.TwitchRewards[rewardID].effects.turret.spawnType.SelectedItem == "inFront" then
		spawnType = false
	else
	
	end
	local pos, rot = TIM:Spawn_position(spawnType) 
	local unit = World:spawn_unit(Idstring("units/payday2/vehicles/gen_vehicle_turret/gen_vehicle_turret"),Vector3(pos.x, pos.y, pos.z-12), rot)
	unit:movement()._hacked_stop_snd_event = nil
	unit:movement()._hacked_start_snd_event = nil
	
	
	local extension = unit["base"](unit)
	extension["activate_as_module"](extension, "combatant", "swat_van_turret_module")
end