function TIM.effectsFunctions.weaponsafe(rewardID)
	--TIM.countDozers = 1
	managers.player:local_player():sound():say("Play_ban_b02c",true,true)	
	-- assault_rifle smg pistol revolver   minigun     flamethrower bow crossbow
	
	if TIM.weaponSafeAll == nil then
		TIM.equipped_primary = managers.blackmarket:equipped_primary()
		TIM.equipped_secondary = managers.blackmarket:equipped_secondary()
	end
		TIM.weaponSafeAll = {}
		TIM.weaponSafeAll.points = {}
		TIM.weaponSafeAll.elements_rarity = {}
		TIM.weaponSafeAll.weapondata = {}
		TIM.weaponSafeAll.weaponicons = {}
		TIM.weaponSafeAll.weaponnames = {}
	--end
	local table_weapons = {}
	if TIM._settings.TwitchRewards[rewardID].effects.weaponsafe.inventory and TIM._settings.TwitchRewards[rewardID].effects.weaponsafe.inventory.Value == true then
		--managers.mission._fading_debug_output:script().log(tostring(true),  Color.green)
		if managers.blackmarket and Global.blackmarket_manager and type(Global.blackmarket_manager.crafted_items) == "table" then		
			--table_weapons = {}
			--for _selection_wanted, cat in pairs({"secondaries", "primaries"}) do
				for _, wep in pairs(Global.blackmarket_manager.crafted_items.primaries) do
					--wep.selection_wanted = _selection_wanted
					table_weapons[wep.weapon_id]= wep
				end
				for _, wep in pairs(Global.blackmarket_manager.crafted_items.secondaries) do
					--wep.selection_wanted = _selection_wanted
					table_weapons[wep.weapon_id]= wep
				end
			--end
		end
		--table_weapons = Global.blackmarket_manager.crafted_items
	else
		for id, wep in pairs(Global.blackmarket_manager.weapons) do
			--wep.selection_wanted = _selection_wanted
			table_weapons[id]= wep
		end
	end
		for k, v in pairs(table_weapons or {}) do
			if string.find(k, "crew") or string.find(k, "npc") or string.find(k, "sentry") or string.find(k, "secondary") or string.find(k, "contraband_m203") then
				
			else
				TIM.weaponSafeAll.weapondata[#TIM.weaponSafeAll.weapondata+1]=v
				--TIM.weapondata[#TIM.weapondata].id=k
				if tweak_data.weapon[k].texture_bundle_folder then
					TIM.weaponSafeAll.weaponicons[#TIM.weaponSafeAll.weaponicons+1] = "guis/dlcs/"..tweak_data.weapon[k].texture_bundle_folder.."/textures/pd2/blackmarket/icons/weapons/"..k
					
				else
					TIM.weaponSafeAll.weaponicons[#TIM.weaponSafeAll.weaponicons+1] = "guis/textures/pd2/blackmarket/icons/weapons/"..k
				end
				if tweak_data.weapon[k].categories[1] == "grenade_launcher" then
					TIM.weaponSafeAll.points[#TIM.weaponSafeAll.points+1]=40
					TIM.weaponSafeAll.elements_rarity[#TIM.weaponSafeAll.elements_rarity+1]="legendary"
				elseif tweak_data.weapon[k].categories[1] == "snp" or tweak_data.weapon[k].categories[1] == "lmg" then
					TIM.weaponSafeAll.points[#TIM.weaponSafeAll.points+1]=80
					TIM.weaponSafeAll.elements_rarity[#TIM.weaponSafeAll.elements_rarity+1]="epic"
				elseif tweak_data.weapon[k].categories[1] == "akimbo" or tweak_data.weapon[k].categories[1] == "shotgun" then
					TIM.weaponSafeAll.points[#TIM.weaponSafeAll.points+1]=120
					TIM.weaponSafeAll.elements_rarity[#TIM.weaponSafeAll.elements_rarity+1]="rare"
				elseif tweak_data.weapon[k].categories[1] == "flamethrower" or tweak_data.weapon[k].categories[1] == "bow" or tweak_data.weapon[k].categories[1] == "crossbow" then
					TIM.weaponSafeAll.points[#TIM.weaponSafeAll.points+1]=200
					TIM.weaponSafeAll.elements_rarity[#TIM.weaponSafeAll.elements_rarity+1]="common"
				else
					TIM.weaponSafeAll.points[#TIM.weaponSafeAll.points+1]=160
					TIM.weaponSafeAll.elements_rarity[#TIM.weaponSafeAll.elements_rarity+1]="uncommon"
				end
				local str = managers.localization:text(tweak_data.weapon[k].name_id)
				if string.find(str, "Pistol Crossbow")==nil then
					str = string.sub(str, 1, (string.find(str, "Sniper") or string.find(str, "Assault") or string.find(str, "Revolver") or string.find(str, "Grenade") or string.find(str, "Rocket") or string.find(str, "Submachine") or string.find(str, "Shotgun") or string.find(str, "Rifle") or string.find(str, "Light Machine") or string.find(str, "Pistol") or #str+1)-1)
				end
				TIM.weaponSafeAll.weaponnames[#TIM.weaponSafeAll.weaponnames+1]= str
			end
		end
	
	
	local names = TIM.weaponSafeAll.weaponnames -- {"Green Dozer", "Black Dozer", "Skull Dozer", "Medic Dozer", "Minigun Dozer", "Headless Dozer"}
	local paths = TIM.weaponSafeAll.weaponicons   --={"dozer_safe/Green Dozer","dozer_safe/Black Dozer","dozer_safe/Skull Dozer","dozer_safe/Medic Dozer","dozer_safe/Minigun Dozer","dozer_safe/Headless Dozer"}
	
	
	--local elements_rarity = {"common", "common","uncommon","rare","epic","legendary"}
	local after_function = function(num_spawn, num_boost,effect_params)
		if managers.player:current_state()=="civilian" or managers.player:current_state()=="mask_off" then
			managers.player:set_player_state("standard")
		end
		--managers.mission._fading_debug_output:script().log(tostring("fff")..tostring(num_spawn),  Color.green)
		
		
		local lin = TIM:fon_function()
		lin:animate(function(o)
			--managers.viewport:first_active_viewport():set_environment(toChange,2)
			--wait(2)
			while managers.player:current_state()~="standard" or managers.player:current_state()~="carry" do
				wait(2)
			end
			local pos, rot = TIM:Spawn_position(true) 
		
		--managers.player:player_unit():movement()._current_state:ChangeWeaponNow({wep_data =TIM.weaponSafeAll.weapondata[num_spawn], bool =true})
		
		-- = TIM.weaponSafeAll.weapondata[num_spawn]
		--managers.mission._fading_debug_output:script().log(tostring(TIM.weaponSafeAll.weapondata[num_spawn].selection_index).." = "..tostring(TIM.weaponSafeAll.weapondata[num_spawn].selection_wanted),  Color.green)
		if TIM.weaponSafeAll.weapondata[num_spawn].selection_index == 2 or TIM.weaponSafeAll.weapondata[num_spawn].selection_wanted==2 then 
			TIM.equipped_primary  = TIM.weaponSafeAll.weapondata[num_spawn]
			--toChangePrimary = TIM.weaponSafeAll.weapondata[num_spawn]
		else 
			TIM.equipped_secondary = TIM.weaponSafeAll.weapondata[num_spawn]
			--toChangeSecondary = TIM.weaponSafeAll.weapondata[num_spawn]
		end
		local toChangePrimary = TIM.equipped_primary
		local toChangeSecondary = TIM.equipped_secondary --managers.mission._fading_debug_output:script().log(tostring("aaaa"),  Color.green)
			managers.player:player_unit():movement()._current_state:ChangeWeaponNow({wep_data =TIM.weaponSafeAll.weapondata[num_spawn], bool =true})
			managers.explosion:play_sound_and_effects(
				pos,
				Rotation(0, 0,0),
				1,
				effect_params
			)
			local timeNow  = TIM._settings.TwitchRewards[rewardID].effects.weaponsafe.Timer.Value + Application:time()
			local t = Application:time()
			local bool = true
			while timeNow > t do
				--managers.viewport:first_active_viewport():set_environment(toChange)
				local dt = coroutine.yield()
				t = Application:time()
				if toChangePrimary ~= TIM.equipped_primary or toChangeSecondary ~= TIM.equipped_secondary  then 
					bool = false
					
					break
				end
			end
			--managers.mission._fading_debug_output:script().log(tostring(bool),  Color.green)
			if bool==true then
				--TIM.Rewards.changed_timeofday=nil
				while managers.player:current_state()~="standard" or managers.player:current_state()~="carry" do
					wait(2)
					--managers.player:set_player_state("standard")
				end
				--managers.mission._fading_debug_output:script().log(tostring(toChange.selection_index),  Color.green)
				if TIM.equipped_primary ~= managers.blackmarket:equipped_primary() then
					TIM.equipped_primary = managers.blackmarket:equipped_primary()
					managers.player:player_unit():movement()._current_state:ChangeWeaponNow({wep_data =managers.blackmarket:equipped_primary(), bool =true})
				end
				wait(2)
				while managers.player:current_state()~="standard" or managers.player:current_state()~="carry" do
					wait(2)
					--managers.player:set_player_state("standard")
				end
					if TIM.equipped_secondary ~= managers.blackmarket:equipped_secondary() then
						TIM.equipped_secondary = managers.blackmarket:equipped_secondary()
						managers.player:player_unit():movement()._current_state:ChangeWeaponNow({wep_data =managers.blackmarket:equipped_secondary(), bool =true})
					end
				
				
				
				--managers.viewport:first_active_viewport():set_environment(TIM.Rewards.default_timeofday,2)
				--TIM.Rewards.default_timeofday=nil
			end
		end)
	end
	TIM:CreateSafe("Weapon safe", TIM.weaponSafeAll.points, names, TIM.weaponSafeAll.elements_rarity, paths, nil, nil, after_function)
end