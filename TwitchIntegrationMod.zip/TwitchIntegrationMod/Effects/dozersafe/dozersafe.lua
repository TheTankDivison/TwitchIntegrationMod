function TIM.effectsFunctions.dozersafe(rewardID)
	TIM.countDozers = 1
	TIM.dozerSafePosition = managers.player:local_player():position()
	managers.player:local_player():sound():say("Play_ban_s02_a",true,true)	
	local dozers_points = {110,110,100,50,10,5}
	local dozers = {"Green Dozer", "Black Dozer", "Skull Dozer", "Medic Dozer", "Minigun Dozer", "Headless Dozer"}
	local dozers_names = {"units/payday2/characters/ene_bulldozer_1/ene_bulldozer_1", "units/payday2/characters/ene_bulldozer_2/ene_bulldozer_2", "units/payday2/characters/ene_bulldozer_3/ene_bulldozer_3", "units/pd2_dlc_drm/characters/ene_bulldozer_medic/ene_bulldozer_medic", "units/pd2_dlc_drm/characters/ene_bulldozer_minigun/ene_bulldozer_minigun", "units/pd2_dlc_help/characters/ene_zeal_bulldozer_halloween/ene_zeal_bulldozer_halloween"}
	local stat_boosts_points= {300, 50, 50, 50, 25, 25,50}
	local dozers_paths={"dozer_safe/Green Dozer","dozer_safe/Black Dozer","dozer_safe/Skull Dozer","dozer_safe/Medic Dozer","dozer_safe/Minigun Dozer","dozer_safe/Headless Dozer"}
	local health = TIM._settings.TwitchRewards[rewardID].effects.dozersafe.HealthBoost.Value
	local damage = TIM._settings.TwitchRewards[rewardID].effects.dozersafe.DamageBoost.Value
	local acc = TIM._settings.TwitchRewards[rewardID].effects.dozersafe.AccuracyBoost.Value
	local imm = TIM._settings.TwitchRewards[rewardID].effects.dozersafe.ImmortalBoost.Value
	local count = TIM._settings.TwitchRewards[rewardID].effects.dozersafe.CountBoost.Value
	local shield_unit = TIM._settings.TwitchRewards[rewardID].effects.dozersafe.ShieldBoost.SelectedItem
	local stat_boosts = {"none", "+"..tostring(health).."% HEALTH", "+"..tostring(damage).."% DAMAGE", "ACCURACY x"..tostring(acc), tostring(imm).." SECONDS IMMORTAL", "COUNT x"..tostring(count), "SHIELD BOOST"}
	local stat_boost_functions = {}
	stat_boost_functions[1]=function()
	end
	stat_boost_functions[2]=function(unit)
		unit:character_damage():set_health(unit:character_damage():get_health()*(1+health/100))
	end
	stat_boost_functions[3]=function(unit)
		unit:base():add_buff("base_damage", damage/100)
	end
	stat_boost_functions[4]=function(unit)
		unit:character_damage():set_accuracy_multiplier(acc)
	end
	stat_boost_functions[5]=function(unit)
		local lin = TIM.fon_function()
		lin:animate(function(o)
			unit:character_damage():set_invulnerable(true)
			managers.network:session():send_to_peers_synched("set_unit_invulnerable",unit, true)
			wait(imm)
			unit:character_damage():set_invulnerable(false)
			managers.network:session():send_to_peers_synched("set_unit_invulnerable",unit, false)
		end)	
	end
	stat_boost_functions[6]=function(unit)
		--TIM.countDozers=2
	end
	stat_boost_functions[7]=function(unit)
		
		
		--local unit_done = TIM:Spawn_unit(true, unit_name, pos, rot)
		local shield= World:spawn_unit(Idstring(shield_unit), unit:position(), unit:rotation())
		
		--local align_obj = self._unit:get_object(align_name)
		--self._shield_unit = World:spawn_unit(Idstring(self._shield_unit_name), align_obj:position(), align_obj:rotation())

		unit:link(Idstring("a_weapon_left_front"), shield, shield:orientation_object():name())
	end
	local elements_rarity = {"common", "common","uncommon","rare","epic","legendary"}
	local after_function = function (num_spawn, num_boost, effect_params)
		if num_boost == 6 then
			TIM.countDozers=count
		end
		local player_pos = managers.player:local_player() and managers.player:local_player():position() or TIM.dozerSafePosition
		local pos, rot = TIM:Spawn_position(false, player_pos) 
		local safe = World:spawn_unit(Idstring("units/payday2/equipment/gen_interactable_sec_safe_2x1_titan/gen_interactable_sec_safe_2x1_titan"),pos+Vector3(0,0,1050), Rotation(rot:yaw()+90,0,0))
		local from_pos = safe:position()
		local to_pos = from_pos+Vector3(0,0,-1050)
		local fon = TIM.fon_function()
		local sounds_effects_rarity = {common = "safe_data/common-1", uncommon = "safe_data/uncommon-1", rare = "safe_data/rare-1", epic = "safe_data/epic-1", legendary = "safe_data/legend-1"}
		local effect_params1 = {
			sound_event = "grenade_explode",
			camera_shake_max_mul = 0,
			sound_muffle_effect = false,
			feedback_range = 5* 2
		}
		fon:animate(function(o)
			over(0.3, function(p)
				safe:set_position(math.lerp(from_pos, to_pos, p))
			end)
			managers.explosion:play_sound_and_effects(
				pos,
				Rotation(0, 0,0),
				1,
				effect_params1
			)
			wait(0.9)
			safe:damage():run_sequence_simple("anim_explosion_out")
			
			local unit_name = Idstring(dozers_names[num_spawn])	
			
			--managers.mission._fading_debug_output:script().log(tostring(TIM.countDozers),  Color.green)
			local act = { type = "act", body_part = 1, variant = "e_sp_uno_jump_in", align_sync = true }
			--managers.mission._fading_debug_output:script().log(tostring(1),  Color.green)
			for i=1, TIM._settings.TwitchRewards[rewardID].effects.dozersafe.Count.Value * TIM.countDozers, 1 do
				--managers.mission._fading_debug_output:script().log(tostring(2),  Color.green)
				local unit_pos, unit_rot = TIM:Spawn_position(false, pos, 300, nil, rot:yaw()) 
				local unit_done = TIM:Spawn_unit(true, unit_name, unit_pos, rot)  --TIM:Spawn_unit(unit_name, true)
				unit_done:brain():action_request(act)
				managers.explosion:play_sound_and_effects(
					pos,
					Rotation(0, 0,0),
					1,
					effect_params
				)
				wait(1.2)
				if num_boost ~= 5 then
					local lin = TIM:fon_function()
					lin:animate(function(o)
						unit_done:character_damage():set_invulnerable(true)
						managers.network:session():send_to_peers_synched("set_unit_invulnerable",unit_done, true)
						wait(TIM._settings.TwitchRewards[rewardID].effects.dozersafe.immortal.Value+1)
						unit_done:character_damage():set_invulnerable(false)
						managers.network:session():send_to_peers_synched("set_unit_invulnerable",unit_done, false)
						lin:parent():remove(lin)
					end)
				end
				stat_boost_functions[num_boost](unit_done)
			end
			TIM.countDozers=nil
			wait(10)
			safe:set_slot(0)
			managers.explosion:play_sound_and_effects(
				pos,
				Rotation(0, 0,0),
				1,
				effect_params1
			)
		end)	
			
		
	end
	
	TIM:CreateSafe("Dozer safe",dozers_points, dozers, elements_rarity, dozers_paths, stat_boosts_points, stat_boosts, after_function, TIM._settings.TwitchRewards[rewardID].effects.dozersafe.enableMusic and TIM._settings.TwitchRewards[rewardID].effects.dozersafe.enableMusic.Value or false)
end