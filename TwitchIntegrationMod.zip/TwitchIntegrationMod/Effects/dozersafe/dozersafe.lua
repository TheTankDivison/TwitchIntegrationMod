function TIM.effectsFunctions.dozersafe(rewardID)
	TIM.countDozers = 1
	managers.player:local_player():sound():say("Play_ban_s02_a",true,true)	
	local dozers_points = {110,110,100,50,10,5}
	local dozers = {"Green Dozer", "Black Dozer", "Skull Dozer", "Medic Dozer", "Minigun Dozer", "Headless Dozer"}
	local dozers_names = {"units/payday2/characters/ene_bulldozer_1/ene_bulldozer_1", "units/payday2/characters/ene_bulldozer_2/ene_bulldozer_2", "units/payday2/characters/ene_bulldozer_3/ene_bulldozer_3", "units/pd2_dlc_drm/characters/ene_bulldozer_medic/ene_bulldozer_medic", "units/pd2_dlc_drm/characters/ene_bulldozer_minigun/ene_bulldozer_minigun", "units/pd2_dlc_help/characters/ene_zeal_bulldozer_halloween/ene_zeal_bulldozer_halloween"}
	local stat_boosts_points= {300, 50, 50, 50, 25, 25,50}
	local dozers_paths={"dozer_safe/Green Dozer","dozer_safe/Black Dozer","dozer_safe/Skull Dozer","dozer_safe/Medic Dozer","dozer_safe/Minigun Dozer","dozer_safe/Headless Dozer"}
	local health = TIM._settings.TwitchRewards[rewardID].effects.dozersafe.HealthBoost.Value
	local damage = TIM._settings.TwitchRewards[rewardID].effects.dozersafe.DamageBoost.Value
	local acc = TIM._settings.TwitchRewards[rewardID].effects.dozersafe.AccuracyBoost.Value
	local imm = TIM._settings.TwitchRewards[rewardID].effects.dozersafe.ImmortalBoost.Value
	local count = TIM._settings.TwitchRewards[rewardID].effects.dozersafe.CountBoost.Value
	local shield_unit = TIM._settings.TwitchRewards[rewardID].effects.dozersafe.ShieldBoost.SelectedItem
	local stat_boosts = {"none", "+"..tostring(health).."% HEALTH", "+"..tostring(damage).."% DAMAGE", "ACCURACY x"..tostring(acc), tostring(imm).." SECONDS IMMORTAL", "COUNT x"..tostring(count), "SHIELD BOOST"}
	local stat_boost_functions = {}
	stat_boost_functions[1]=function()
	end
	stat_boost_functions[2]=function(unit)
		unit:character_damage():set_health(unit:character_damage():get_health()*(1+health/100))
	end
	stat_boost_functions[3]=function(unit)
		unit:base():add_buff("base_damage", damage/100)
	end
	stat_boost_functions[4]=function(unit)
		unit:character_damage():set_accuracy_multiplier(acc)
	end
	stat_boost_functions[5]=function(unit)
		local lin = TIM.fon_function()
		lin:animate(function(o)
			unit:character_damage():set_immortal(true)
			unit:character_damage():set_invulnerable(true)
			wait(imm)
			unit:character_damage():set_immortal(false)
			unit:character_damage():set_invulnerable(false)
		end)	
	end
	stat_boost_functions[6]=function(unit)
		--TIM.countDozers=2
	end
	stat_boost_functions[7]=function(unit)
		
		
		--local unit_done = TIM:Spawn_unit(true, unit_name, pos, rot)
		local shield= World:spawn_unit(Idstring(shield_unit), unit:position(), unit:rotation())
		
		--local align_obj = self._unit:get_object(align_name)
		--self._shield_unit = World:spawn_unit(Idstring(self._shield_unit_name), align_obj:position(), align_obj:rotation())

		unit:link(Idstring("a_weapon_left_front"), shield, shield:orientation_object():name())
	end
	local elements_rarity = {"common", "common","uncommon","rare","epic","legendary"}
	local after_function = function (num_spawn, num_boost,effect_params)
	
		if num_spawn>=5 then
			managers.player:local_player():sound():say("v21",true,true)
		end
		if num_boost == 6 then
			TIM.countDozers=count
		end
			local unit_name = Idstring(dozers_names[num_spawn])	
			local pos, rot = TIM:Spawn_position(false) 
			--managers.mission._fading_debug_output:script().log(tostring(TIM.countDozers),  Color.green)
		for i=1, TIM._settings.TwitchRewards[rewardID].effects.dozersafe.Count.Value*TIM.countDozers, 1 do
			local unit_done =TIM:Spawn_unit(true, unit_name, pos, rot)  --TIM:Spawn_unit(unit_name, true)
		
			if num_boost ~= 5 then
				local lin = TIM:fon_function()
				lin:animate(function(o)
					unit_done:character_damage():set_invulnerable(true)
					unit_done:character_damage():set_immortal(true)
					wait(TIM._settings.TwitchRewards[rewardID].effects.dozersafe.immortal.Value)
					unit_done:character_damage():set_invulnerable(false)
					unit_done:character_damage():set_immortal(false)
					lin:parent():remove(lin)
				end)
			end
			stat_boost_functions[num_boost](unit_done)
		end
		managers.explosion:play_sound_and_effects(
			pos,
			Rotation(0, 0,0),
			1,
			effect_params
		)
		TIM.countDozers=nil
	end
	TIM:CreateSafe("Dozer safe",dozers_points, dozers, elements_rarity, dozers_paths, stat_boosts_points, stat_boosts, after_function)
end