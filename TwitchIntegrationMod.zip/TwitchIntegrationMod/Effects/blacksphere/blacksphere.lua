--[[
Name:Ammo
Divider:Description: A reward that spawn ammo boxes for you and your crew
Activate:true
Count:1
options_end
]]
function TIM.effectsFunctions.blacksphere(rewardID)
	if TIM.Rewards[rewardID]== nil then
		TIM.Rewards[rewardID]={}
	end
	if TIM.Rewards[rewardID].blacksphereNow ==nil then
		TIM.Active_timer_blacksphere = true
		local col = 0
		local size = 100000
		local lin = TIM:fon_function()
		lin:animate(function(o)
			TIM.Rewards[rewardID].blacksphereNow = TIM._settings.TwitchRewards[rewardID].effects.blacksphere.Timers_max.Value
			over(3, function(p)
				if managers.player:local_player() then
					local dr = Draw:brush(Color(math.lerp(col,1,p),0,0,0))
					col = math.lerp(col,1,p)
					dr:set_color(Color(col,0,0,0))
					size = math.lerp(size, TIM._settings.TwitchRewards[rewardID].effects.blacksphere.size.Value*100, p)
					dr:sphere(managers.player:local_player():position(), size, 4)
				end
			end)
			
			Hooks:PostHook(PlayerDamage, "update", "BlackVisionTwitch",
				function(self)
					if managers.player:local_player() then
						local dr = Draw:brush(Color(1,0,0,0))
						dr:set_color(Color(1,0,0,0))
						dr:sphere(managers.player:local_player():position(), TIM._settings.TwitchRewards[rewardID].effects.blacksphere.size.Value*100, 4)
					end
				end
			)
	
			while TIM.Rewards[rewardID].blacksphereNow>0 do
				TIM.Rewards[rewardID].blacksphereNow = TIM.Rewards[rewardID].blacksphereNow - 1
				wait(1)
				
			end
			TIM.Rewards[rewardID].blacksphereNow =nil
			Hooks:RemovePostHook("BlackVisionTwitch")
			col=1
			over(3, function(p)
				local dr = Draw:brush(Color(math.lerp(col,1,p),0,0,0))
				col = math.lerp(col,0,p)
				dr:set_color(Color(col,0,0,0))
				dr:sphere(managers.player:local_player():position(), TIM._settings.TwitchRewards[rewardID].effects.blacksphere.size.Value*100, 4)
			end)
			lin:parent():remove(lin)
		end)						
	else
		TIM.Rewards[rewardID].blacksphereNow = TIM.Rewards[rewardID].blacksphereNow + TIM._settings.TwitchRewards[rewardID].effects.blacksphere.Timers_max.Value
	end	
end