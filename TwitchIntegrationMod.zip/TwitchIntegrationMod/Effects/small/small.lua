--[[
Name:Ammo
Divider:Description: A reward that spawn ammo boxes for you and your crew
Activate:true
Count:1
options_end
]]
function TIM.effectsFunctions.small(rewardID)
	if TIM.Rewards[rewardID]== nil then
		TIM.Rewards[rewardID]={}
	end
	local standard = Vector3(0, 0, 145)
	local mask_off = Vector3(0, 0, 160)
	local crouched = Vector3(0, 0, 75)
	local movement = tweak_data.player.movement_state.standard.movement
	
	
	if TIM.Rewards[rewardID].smallNow ==nil then
		TIM.Active_timer_small = true
		local size = TIM._settings.TwitchRewards[rewardID].effects.small.size.Value
		movement.speed.STANDARD_MAX		 = movement.speed.STANDARD_MAX*(size/145)
		movement.speed.RUNNING_MAX		 = movement.speed.RUNNING_MAX*(size/145)
		movement.speed.CROUCHING_MAX	 = movement.speed.CROUCHING_MAX*(size/145)
		movement.speed.STEELSIGHT_MAX	 = movement.speed.STEELSIGHT_MAX*(size/145)
		movement.speed.INAIR_MAX		 = movement.speed.INAIR_MAX*(size/145)
		movement.speed.CLIMBING_MAX		 = movement.speed.CLIMBING_MAX*(size/145)
		movement.jump_velocity.z		 = movement.jump_velocity.z*(size/145)*3
		movement.jump_velocity.xy.run	 = movement.speed.RUNNING_MAX  * 1  
		movement.jump_velocity.xy.walk	 = movement.speed.STANDARD_MAX * 1.2 
		local force = -982*(size/145)*3
		managers.player:player_unit():mover():set_gravity(Vector3(0, 0, force))
		
		local lin = TIM:fon_function()
		lin:animate(function(o)
			TIM.Rewards[rewardID].smallNow = TIM._settings.TwitchRewards[rewardID].effects.small.Timers_max.Value
			
			
			
			local sound = "sounds/down"
			local texture_name = "guis/textures/icons/arrow"
			
			local p = managers.menu_component._main_panel
			local name = "sound"..sound
			if alive(p:child(name)) then
				managers.menu_component._main_panel:remove(p:child(name))
			end
			local volume = managers.user:get_setting("sfx_volume")
			local percentage = (volume - tweak_data.menu.MIN_SFX_VOLUME) / (tweak_data.menu.MAX_SFX_VOLUME - tweak_data.menu.MIN_SFX_VOLUME)
			managers.menu_component._main_panel:video({
				name = name,
				video = sound,
				visible = false,
				loop = false,
			}):set_volume_gain(percentage+0.10)
		
			over(0.5, function(p)
				tweak_data.player.stances.default.standard.head.translation = math.lerp(tweak_data.player.stances.default.standard.head.translation,Vector3(0,0,size*1.1),p)
				tweak_data.player.stances.default.mask_off.head.translation = math.lerp(tweak_data.player.stances.default.mask_off.head.translation,Vector3(0,0,size),p)
				tweak_data.player.stances.default.crouched.head.translation = math.lerp(tweak_data.player.stances.default.crouched.head.translation,Vector3(0,0,size/1.93333),p)
				managers.player:player_unit():movement():current_state():_stance_entered()
			end)
			
			
	
			while TIM.Rewards[rewardID].smallNow>0 do
				TIM.Rewards[rewardID].smallNow = TIM.Rewards[rewardID].smallNow - 1
				wait(1)
				
			end
			TIM.Rewards[rewardID].smallNow =nil
			sound = "sounds/up"
			texture_name = "guis/textures/icons/arrow"
			
			p = managers.menu_component._main_panel
			name = "sound"..sound
			if alive(p:child(name)) then
				managers.menu_component._main_panel:remove(p:child(name))
			end
			--local volume = managers.user:get_setting("sfx_volume")
			--local percentage = (volume - tweak_data.menu.MIN_SFX_VOLUME) / (tweak_data.menu.MAX_SFX_VOLUME - tweak_data.menu.MIN_SFX_VOLUME)
			managers.menu_component._main_panel:video({
				name = name,
				video = sound,
				visible = false,
				loop = false,
			}):set_volume_gain(percentage+0.10)
		
			movement.speed.STANDARD_MAX		 = movement.speed.STANDARD_MAX		/(size/145)	
			movement.speed.RUNNING_MAX		 = movement.speed.RUNNING_MAX		/(size/145)	
			movement.speed.CROUCHING_MAX	 = movement.speed.CROUCHING_MAX		/(size/145)
			movement.speed.STEELSIGHT_MAX	 = movement.speed.STEELSIGHT_MAX	/(size/145)
			movement.speed.INAIR_MAX		 = movement.speed.INAIR_MAX			/(size/145)
			movement.speed.CLIMBING_MAX		 = movement.speed.CLIMBING_MAX		/(size/145)	
			movement.jump_velocity.z		 = movement.jump_velocity.z			/(size/145*3)
			movement.jump_velocity.xy.run	 = movement.jump_velocity.xy.run	/(size/145)
			movement.jump_velocity.xy.walk	 = movement.jump_velocity.xy.walk	/(size/145)
			managers.player:player_unit():mover():set_gravity(Vector3(0, 0, -982))
			over(0.5, function(p)
				tweak_data.player.stances.default.standard.head.translation = math.lerp(tweak_data.player.stances.default.standard.head.translation, standard,p)
				tweak_data.player.stances.default.mask_off.head.translation = math.lerp(tweak_data.player.stances.default.mask_off.head.translation, mask_off,p)
				tweak_data.player.stances.default.crouched.head.translation = math.lerp(tweak_data.player.stances.default.crouched.head.translation, crouched,p)
				if managers.player:local_player() then
					managers.player:player_unit():movement():current_state():_stance_entered()
				end
			end)
			lin:parent():remove(lin)
		end)						
	else
		TIM.Rewards[rewardID].smallNow = TIM.Rewards[rewardID].smallNow + TIM._settings.TwitchRewards[rewardID].effects.small.Timers_max.Value
	end	
end