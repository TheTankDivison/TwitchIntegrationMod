function TIM.effectsFunctions.killpixel(rewardID)
	if TIM.pixelTable == nil or TIM.pixelSize ~= TIM._settings.TwitchRewards[rewardID].effects.killpixel.size.Value then
		TIM.pixelTable = {}
		if TIM.pixels ~= nil then
			for i=1, #TIM.pixels, 1 do
				TIM.pixels[i]:parent():remove(TIM.pixels[i])
			end
		end
		TIM.pixels={}
		--TIM.pixelCountX = 0
		--TIM.pixelCountY = {}
		
		TIM.pixelSize = TIM._settings.TwitchRewards[rewardID].effects.killpixel.size.Value
		for i=0, 1280, TIM.pixelSize do
			TIM.pixelTable[i]={}
			--TIM.pixelCountX=TIM.pixelCountX+1
			for j=0, 720, TIM.pixelSize do
				TIM.pixelTable[i][j] = true
				--TIM.pixelCountY=TIM.pixelCountY+1
			end
		end
	end
	--if TIM.pixelSize ~= TIM._settings.TwitchRewards[rewardID].effects.killpixel.size.Value then
		--for i=1, #TIM.pixels, 1 do
		--	TIM.pixels[i]:parent():remove(TIM.pixels[i])
		--end
	--end
	--local size = TIM._settings.TwitchRewards[rewardID].effects.killpixel.size.Value
	if TIM._settings.TwitchRewards[rewardID].effects.killpixel.kill then
		--managers.mission._fading_debug_output:script().log(tostring(true),  Color.green)
		local count = TIM._settings.TwitchRewards[rewardID].effects.killpixel.Count.Value
		if #TIM.pixels < TIM._settings.TwitchRewards[rewardID].effects.killpixel.Count.Value then
			count = #TIM.pixels
		end
		--managers.mission._fading_debug_output:script().log(tostring(count),  Color.green)
		for i=1, count, 1 do
			local n = math.random(#TIM.pixels)
			--managers.mission._fading_debug_output:script().log(tostring(n),  Color.green)
			local x = TIM.pixels[n]:x()
			local y = TIM.pixels[n]:y()
			TIM.pixels[n]:parent():remove(TIM.pixels[n])
			table.remove(TIM.pixels, n)
			table.insert(TIM.pixelTable[x], y, true)
		end
	else
		--managers.mission._fading_debug_output:script().log(tostring(1),  Color.green)
		local table_t = {}
		--local count_x=0
		--local count_y=0
		local total_count = 0
		for x, value720 in pairs(TIM.pixelTable or {}) do
			local count_x = #table_t +1
			table_t[count_x]={}
			for y, value in pairs(value720 or {}) do
				if x==0 and y==0 then
					--managers.mission._fading_debug_output:script().log(tostring(TIM.pixelTable[x][y]),  Color.green)
				end
				if TIM.pixelTable[x][y]==true then
					total_count=total_count+1
					local count_y = #table_t[count_x] +1
					--managers.mission._fading_debug_output:script().log(tostring(TIM.pixelTable[x][y]),  Color.green)
					table_t[count_x][count_y] = {x, y}
				end
			end
			if #table_t[count_x]==0 then
				table_t[count_x]=nil
			end
		end
		--managers.mission._fading_debug_output:script().log(tostring(total_count).." a",  Color.green)
		for i=1, TIM._settings.TwitchRewards[rewardID].effects.killpixel.Count.Value, 1 do
			--local x_pos = math.random(0,(1280)/TIM.pixelSize)*TIM.pixelSize
			--local y_pos = math.random(0,(720)/TIM.pixelSize)*TIM.pixelSize
			local i_gen = math.random(#table_t)
			--managers.mission._fading_debug_output:script().log(tostring(#table_t[i_gen]).." b",  Color.green)
			while #table_t ~= 0 and #table_t[i_gen] == 0 do
				table.remove(table_t, i_gen)
				i_gen = math.random(#table_t)
				--managers.mission._fading_debug_output:script().log(tostring(#table_t[i_gen]).." c",  Color.green)
			end
			if #table_t == 0 then
				break
			end
			--managers.mission._fading_debug_output:script().log(tostring(#table_t).."-"..tostring(#table_t[i_gen]),  Color.green)
			local j_gen = math.random(#table_t[i_gen])
			local x_pos = table_t[i_gen][j_gen][1]
			local y_pos = table_t[i_gen][j_gen][2]
			table.remove(table_t[i_gen], j_gen)
			--local t = table.remove(TIM.pixelTable[x_pos], y_pos)
			TIM.pixelTable[x_pos][y_pos]=false
			--managers.mission._fading_debug_output:script().log(tostring(TIM.pixelTable[x_pos][y_pos]).." "..tostring(x_pos).."x"..tostring(y_pos),  Color.green)			--TIM.pixelCount = TIM.pixelCount + 1

			TIM.pixels[#TIM.pixels+1] = TIM.hud.panel:bitmap({ name = "sssss", visible = true, layer = 10000, alpha=1, color = Color(0, 0, 0), w = TIM.pixelSize, h = TIM.pixelSize, blend_mode = "normal", x = x_pos, y = y_pos})
		end
	end
end
