
function TIM:MainMenuInit()
	if TIM._settings.firstTimeStarted == true then
		TIM.newbieMenu = MenuUI:new({
			offset = 6,
			layer = 1000,
			toggle_key = TIM.Options:GetValue("TWToggleKey"),
			toggle_clbk = callback(self, self, "ShowNewbieMainMenu"),
			create_items = callback(self, self, "CreateNewbieMainMenu"),
			use_default_close_key = true,
			background_blur=true			
		})	
		TIM.newbieSteps={
			step1 = function()
				TIM._holder:ClearItems()
				TIM._holder:Divider({ name = "Text", text_align = "center", position={0,25}, text = TIM.loc.step1_Text1, size=25 })
				TIM._holder:Image({
					name = "MyImage",
					texture = "guis/textures/icons/twitch_login",
					icon_w = 200,
					icon_h = 200,
					position={-200,125},
					--texture_rect={168,100}
				})
				TIM._holder:Divider({ name = "Text", text_align = "center", position={-200,95}, text = TIM.loc.step1_Text2, size=25 })
				TIM._holder:Image({
					name = "MyImage",
					texture = "guis/textures/icons/twitch_login2",
					icon_w = 200,
					icon_h = 200,
					position={200,125},
					--texture_rect={168,100}
				})
				TIM._holder:Divider({ name = "Text", text_align = "center", position={200,95}, text = TIM.loc.step1_Text3, size=25 })
				local warning = TIM._holder:Divider({ name = "Text", text_align = "center", position={0,375}, text = TIM.loc.step1_Text4, size=18, visible=false, foreground=Color('9C0412') })
				local texbox = TIM._holder:TextBox({ name = "login",  text = TIM.loc.Twitch_login, w=300, value = TIM._settings.Nickname, focus_mode=true, position = {440,350} })
				TIM._holder:Button({ name = "Butt", text = TIM.loc.step1_button, text_align = "center", w=200, position = {540,410}, size=30,
					on_callback = function(item)
						if texbox:Value()=="" then
							warning:SetVisible(true)
						else
							TIM._settings.Nickname = texbox:Value()
							TIM:save_settings()
							TIM.newbieSteps.step2()
						end
					end })
			end,
			step2 = function()
				TIM._holder:ClearItems()
				TIM._holder:Divider({ name = "Text", text_align = "center", position={0,25}, text = TIM.loc.step2_Text1, size=25 })
				TIM._holder:Image({
					name = "MyImage",
					texture = "guis/textures/icons/oauth",
					icon_w = 200,
					icon_h = 200,
					position={-300,150},
					--texture_rect={168,100}
				})
				TIM._holder:Divider({ name = "Text", text_align = "center", position={-50,60}, text = TIM.loc.step2_Text2, size=25 })
				TIM._holder:Button({ name = "Butt3", text = TIM.loc.step2_button2, text_align = "center", w=70, position = {750,60}, size=25, foreground=Color('13840F'),
				on_callback = function(item)
					Steam:overlay_activate("url", "https://twitchtokengenerator.com/quick/SY63Iu80ei")
				end })
				TIM._holder:Divider({ name = "Text", text_align = "center", position={-300,115}, text = TIM.loc.step2_Text3, size=25 })
				TIM._holder:Image({
					name = "MyImage",
					texture = "guis/textures/icons/oauth2",
					icon_w = 600,
					icon_h = 600,
					position={200,150},
					--texture_rect={168,100}
				})
				TIM._holder:Divider({ name = "Text", text_align = "center", position={200,115}, text = TIM.loc.step2_Text4, size=25 })
				local warning = TIM._holder:Divider({ name = "Text", text_align = "center", position={0,490}, text = TIM.loc.step2_Text5, size=25, visible=false, foreground=Color('9C0412') })
				
				local warning1 = TIM._holder:Divider({ name = "Text", text_align = "center", position={0,375}, text = TIM.loc.OAUTH_Warning_text, size=25, visible=false, foreground=Color('9C0412') })
				local texbox = TIM._holder:TextBox({ name = "login",  text = TIM.loc.OAUTH_code, w=400, value = TIM._settings.OAUTH, focus_mode=true, position = {440,400}, visible=false })
				local warning3 =TIM._holder:Button({ name = "Butt4", text = TIM.loc.OK, text_align = "center", w=80, visible=false, position = {600,400}, size=30,
				on_callback = function(item)
					warning1:SetVisible(false)
					texbox:SetVisible(true)
					item:SetVisible(false)
					--warning2:SetVisible(false)
				end })
				local warning2 =TIM._holder:Button({ name = "Butt5", text = TIM.loc.step2_button3, text_align = "center", w=280, position = {500,375}, size=30,
				on_callback = function(item)
					warning1:SetVisible(true)
					warning3:SetVisible(true)
					item:SetVisible(false)
				end })
				
				TIM._holder:Button({ name = "Butt", text = TIM.loc.step1_button, text_align = "center", w=200, position = {640,450}, size=30,
					on_callback = function(item)
						if texbox:Value()=="" then
							warning:SetVisible(true)
						else
							TIM._settings.OAUTH = texbox:Value()
							TIM:save_settings()
							TIM.newbieSteps.step3()
						end
					end })
				TIM._holder:Button({ name = "Butt1", text = TIM.loc.step2_button, text_align = "center", w=200, position = {440,450}, size=30,
				on_callback = function(item)
					TIM.newbieSteps.step1()
					
				end })
			end,
			step3 = function()
				TIM._holder:ClearItems()
				TIM._settings.firstTimeStarted=false
				TIM:save_settings()
				TIM._holder:Divider({ name = "Welcome", text_align = "center", position = {0,150}, text = TIM.loc.step3_Text1, size=25 })
				TIM._holder:Divider({ name = "Welcome", text_align = "center", position = {0,175}, text = TIM.loc.step3_Text2, size=25 })
				TIM._holder:Button({ name = "GetStarted", text = TIM.loc.step1_button, text_align = "center", w=200, position = {540,360}, size=30,
					on_callback = function(item)
						TIM.newbieMenu:Destroy()
						if TIM._settings.Nickname and TIM._settings.Nickname ~= "" and TIM._settings.OAUTH ~= "" and TIM._settings.enableChat and TIM._settings.enableChannelPoints then
							TIM._settings.UserID = TIM.library.prepareAPI(TIM._settings.Nickname, TIM._settings.OAUTH, TIM._settings.enableChat, TIM._settings.enableChannelPoints) --, TIM._settings.UserID
						end
						MenuUI:new({
							offset = 6,
							layer = 1000,
							toggle_key = TIM.Options:GetValue("TWToggleKey"),
							toggle_clbk = callback(self, self, "ShowMainMenu"),
							create_items = callback(self, self, "CreateMainMenu"),
							background_blur=true,
							use_default_close_key = true     
						})	
					end })
			end,
		}
		
	else
		MenuUI:new({
			offset = 6,
			layer = 1000,
			toggle_key = TIM.Options:GetValue("TWToggleKey"),
			toggle_clbk = callback(self, self, "ShowMainMenu"),
			create_items = callback(self, self, "CreateMainMenu"),
			use_default_close_key = true,
			background_blur=true		
		})	
	end
	MenuUI:new({
		name = "ListOfEffects",
		background_blur=true,
		layer = 1150,
		create_items = callback(self, self, "CreateListOfEffects"),
	})
	MenuUI:new({
		name = "ExtraSettings",
		background_blur=true,
		layer = 1150,
		create_items = callback(self, self, "CreateExtraSettings"),
	})
	
end

function TIM:CreateNewbieMainMenu(menu)
	TIM._menu = menu
	local accent = Color(1, 1, 1)
	TIM._holder = TIM._menu:DivGroup({
        name = "Twitch Integration Mod",
        --w = 400,
        auto_height = false,
        size = 20,
		--position="Top",
        background_visible = true,
        border_bottom = true,
        border_center_as_title = true,
        border_position_below_title = true,
        private = {text_align = "center"},
        border_lock_height = true,
        accent_color = accent,
        border_width = 200,
        background_color = Color('3d005e'),
		background_alpha = 0.7,
		align_method = "grid"
    })
	
	TIM._holder:Divider({ name = "Welcome", text_align = "center", position="Center", text = TIM.loc.Welcome, size=25 })
	TIM._holder:Button({ name = "GetStarted", text = TIM.loc.Lets_get_started, text_align = "center", w=200, position = {540,360}, size=30,
		on_callback = function(item)
			TIM.newbieSteps.step1()
		end })

end

function TIM:ShowNewbieMainMenu(menu, opened)
	if opened then
		--local pann = TIM._holder:GetItem("2ndMenu")
		if managers.player:player_unit() then
			game_state_machine:current_state():set_controller_enabled(false)
		end
		--pann:GetItem("startBotOnStart"):SetValue(TIM._settings.startBotOnStart)
		--pann:GetItem("twitch_nickname"):SetValue(TIM._settings.Nickname)
		--TIM._holder:GetItem("ActivateChat"):SetValue(TIM._settings.enableChat)
		--TIM._holder:GetItem("Rewards"):SetValue(TIM._settings.enableChannelPoints)
		
    else
		game_state_machine:current_state():set_controller_enabled(true)
        TIM._menu:disable()
    end
end

function TIM:CreateMainMenu(menu) --главное боковое меню
    TIM._menu = menu
    local accent = Color(1, 1, 1)
    TIM._holder = TIM._menu:DivGroup({
        name = "Twitch Integration Mod",
        w = 400,
        auto_height = false,
        size = 20,
		--position="Top",
        background_visible = true,
        border_bottom = true,
        border_center_as_title = true,
        border_position_below_title = true,
        private = {text_align = "center"},
        border_lock_height = true,
        accent_color = accent,
        border_width = 200,
        background_color = Color('3d005e'),
		background_alpha = 0.7,
		align_method = "grid"
    })
	
	TIM._dialog = TIM._menu:Menu({
        name = "dialog",
        position = "Center",
        align_items = "grid",
        w = 320,
        visible = false,
        auto_height = true,
        auto_foreground = true,
        always_highlighting = true,
        reach_ignore_focus = true,
        scrollbar = false,
        max_height = 700,
        size = 20,
        offset = 8,
        accent_color = BeardLib.Options:GetValue("MenuColor"),
        background_color = Color('3d005e'),
		background_alpha = 0.7,
		align_method = "grid"
    })
	
	TIM._dialog:Divider({ name = "Divider", text_align = "center", text = TIM.loc.Warning })
	TIM._dialog:Divider({ name = "Divider", text = TIM.loc.OAUTH_Warning_text })
	TIM._dialog:Button({ name = "Yes", text = TIM.loc.Yes, text_align = "center", w=150,
		on_callback = function(item)
			TIM._dialog:SetVisible(false)
			TIM._dialog_OAUTH:SetVisible(true)
		end })
	TIM._dialog:Button({ name = "NO", text = TIM.loc.No, text_align = "center", w=150,
		on_callback = function(item)
			TIM._dialog:SetVisible(false)
		end })
	
	TIM._dialog_OAUTH = TIM._menu:Menu({
        name = "dialog_OAUTH",
        position = "Center",
        align_items = "grid",
        w = 400,
        visible = false,
        auto_height = true,
        auto_foreground = true,
        always_highlighting = true,
        reach_ignore_focus = true,
        scrollbar = false,
        max_height = 700,
        size = 20,
        offset = 8,
        accent_color = BeardLib.Options:GetValue("MenuColor"),
        background_color = Color('3d005e'),
		background_alpha = 0.7,
		align_method = "grid"
    })
	
	TIM._dialog_OAUTH:Divider({ name = "Divider", text_align = "center", text = TIM.loc.OAUTH_code })
	TIM._dialog_OAUTH:TextBox({ name = "dialog_OAUTH_text",  text = TIM.loc.Your_OAUTH_code, w=400, value = TIM._settings.OAUTH, focus_mode=true })
	TIM._dialog_OAUTH:Button({ name = "Yes", text = TIM.loc.Enter, text_align = "center", w=190,
		on_callback = function(item)
			TIM._settings.OAUTH = TIM._dialog_OAUTH:GetItem("dialog_OAUTH_text"):Value()
			TIM._settings.UserID = TIM.library.prepareAPI(TIM._settings.Nickname, TIM._settings.OAUTH, TIM._settings.enableChat, TIM._settings.enableChannelPoints)
			TIM._dialog_OAUTH:SetVisible(false)
		end })
	TIM._dialog_OAUTH:Button({ name = "NO", text = TIM.loc.Cancel, text_align = "center", w=190,
		on_callback = function(item)
			TIM._dialog_OAUTH:SetVisible(false)
		end })
		
		TIM:MainMenuContainer()
	
end

function TIM:MainMenuContainer()
	TIM._holder:ClearItems()
	TIM._holder:Button({ name = "launchBotButton", text = TIM.loc.LAUNCH_BOT, text_align = "center", w=124, border_visible=false, background_color=Color('4c2065'), foreground=Color.red, size = 28, position={140,40}, help=TIM.loc.startBotHelp,
		on_callback = function(item)
			if (TIM._settings.enableChat==true or TIM._settings.enableChannelPoints==true or TIM._settings.enableGlobalEvents==true) and TIM._settings.Nickname ~= "" then
				TIM.BotChatActive=TIM.library.get_on_IRC()
				TIM.BotPointsActive=TIM.library.get_on_Pubsub()
				if TIM.ModActive==true then					
					TIM._holder:GetItem("launchBotButton"):SetText(TIM.loc.LAUNCH_BOT)
					TIM._holder:GetItem("launchBotButton"):SetParam("foreground", Color.red)
					TIM:DisableMod()					
				else
					TIM._holder:GetItem("launchBotButton"):SetText(TIM.loc.STOP_BOT)
					TIM._holder:GetItem("launchBotButton"):SetParam("foreground", Color.green)
					TIM:ActivateMod()
				end
			end
		end
	})
	--TIM._holder:Image({ name = "MyImageButton", texture = "guis/textures/icons/settings", w=18, h=18, position={118,145} })
	TIM._holder:Button({ name = "settings", text = TIM.loc.Settings, text_align = "center", w=175, border_visible=false, background_color=Color('4c2065'), foreground=Color.white, size = 28, position={115,140}, help=TIM.loc.modSettingsHelp,
		on_callback = function(item)
			TIM:ModSettingsContainer()
		end})
	if TIM._settings.gameMode == 2 then
		TIM._holder:Button({ name = "globalEvents", text = TIM.loc.globalEvents, text_align = "center", w=175, border_visible=false, background_color=Color('4c2065'), foreground=Color.white, size = 28, position={115,200}, help=TIM.loc.globalEventsHelp,
			on_callback = function(item)
				TIM:GlobalEventsContainer()
			end})
	elseif TIM._settings.gameMode == 1 then
		TIM._holder:Button({ name = "cpSettings", text = TIM.loc.channelPoints, text_align = "center", w=270, border_visible=false, background_color=Color('4c2065'), foreground=Color.white, size = 28, position={65,200}, help=TIM.loc.channelPointsHelp,
			on_callback = function(item)
				TIM:ChannelPointsRewardsContainer()
			end})
	elseif TIM._settings.gameMode == 3 then
		TIM._holder:Button({ name = "ChatAISettings", text = TIM.loc.CHATAI, text_align = "center", w=175, border_visible=false, background_color=Color('4c2065'), foreground=Color.white, size = 28, position={115,200}, help=TIM.loc.channelPointsHelp,
			on_callback = function(item)
				TIM:ChatAIRewardsContainer()
			end})
	end
	if TIM.ModActive==true then
		TIM._holder:GetItem("launchBotButton"):SetText(TIM.loc.STOP_BOT)
		TIM._holder:GetItem("launchBotButton"):SetParam("foreground", Color.green)
	end
end

function TIM:ModSettingsContainer()
	TIM._holder:ClearItems()
	TIM._holder:Divider({ name = "Divider", text_align = "center", size=25, position={0,15} ,foreground=Color('b6b6b6'), text = TIM.loc.Settings })
	TIM._holder:ImageButton({
        name = "MyImageButton",
		w= 40,
		h=40,
        texture = "guis/textures/icons/arrow",
        on_callback = function(item)
			TIM:save_settings()
            TIM:MainMenuContainer()
        end
    })
	--local pann = TIM._holder:DivGroup({ name = "2ndMenu", text = TIM.loc.Settings, w=300, align_method = "grid" })
	TIM._holder:TextBox({ name = "twitch_nickname",  text = TIM.loc.Twitch_login, value = TIM._settings.Nickname, focus_mode = true, position={0,100}, size=25,
		on_callback = function(item)
			TIM._settings.Nickname = item:Value()
		end })
	TIM._holder:Button({ name = "MyButton", text = TIM.loc.SET_OAUTH_KEY, text_align = "center", position={0,150}, size=25,
		on_callback = function(item)
			TIM._dialog:SetVisible(true)
		end })
	
	TIM._holder:Toggle({ name = "startBotOnStart", text = TIM.loc.Launch_bot_on_game_start, value=TIM._settings.startBotOnStart,  position={0,200}, size=25,
		on_callback = function(item)
			TIM._settings.startBotOnStart = item:Value()
			--TIM:save_settings()
		end })
	
	TIM._holder:Toggle({ name = "enableRewardChatMessage", text = TIM.loc.EnableRewardMessage, value=TIM._settings.enableRewardChatMessage,  position={0,250}, size=25,
		on_callback = function(item)
			TIM._settings.enableRewardChatMessage = item:Value()
			--TIM:save_settings()
		end })
	TIM._holder:Toggle({ name = "ActivateChat", text = TIM.loc.Twitch_Chat_in_game, value=TIM._settings.enableChat,  position={0,300}, size=25,
		on_callback = function(item)
			TIM._settings.enableChat = item:Value()
			--TIM:save_settings()
		end })
	TIM._holder:ComboBox({
			name = "GlobalEvents/Rewards",
			text = TIM.loc.GameMode,
			items = {TIM.loc.Channel_Points_Rewards, TIM.loc.Global_events, TIM.loc.ChatAI, TIM.loc.none },
			value = TIM._settings.gameMode,
			enabled = TIM.ModActive == false,
			free_typing = false,
			position={0,350}, size=25,
			on_callback = function(item)
				TIM._settings.gameMode=item:Value()
				TIM:ChangeGameModeSystem()
			end
		})
	--[[
	TIM._holder:Toggle({ name = "Rewards", text = TIM.loc.Channel_Points_Rewards, value = TIM._settings.enableChannelPoints,  position={0,300}, size=25,
		on_callback = function(item)
			TIM._settings.enableChannelPoints = item:Value()
			--TIM:save_settings()
		end })
		
	TIM._holder:Toggle({ name = "GlobalEvents", text = TIM.loc.Global_events, value = TIM._settings.enableGlobalEvents,  position={0,350}, size=25,
		on_callback = function(item)
			TIM._settings.enableGlobalEvents = item:Value()
			--TIM:save_settings()
		end })
		]]
end

function TIM:GlobalEventsContainer()
	TIM._holder:ClearItems()
	TIM._holder:Divider({ name = "Divider", text_align = "center", size=25, position={0,15} ,foreground=Color('b6b6b6'), text = TIM.loc.globalEvents })
	TIM._holder:ImageButton({
        name = "MyImageButton",
		w= 40,
		h=40,
        texture = "guis/textures/icons/arrow",
        on_callback = function(item)
			TIM:save_settings()
            TIM:MainMenuContainer()
        end
    })
	TIM._holder:Button({ name = "Global_events_settings", text = TIM.loc.Global_events_settings, text_align = "center", w=175, border_visible=false, background_color=Color('4c2065'), foreground=Color.white, size = 28, position={115,140}, help=TIM.loc.modSettingsHelp,
		on_callback = function(item)
			TIM:GlobalEventsSettingsContainer()
		end})
	TIM._holder:Button({ name = "events_list", text = TIM.loc.events_list, enabled= TIM.ModActive == false, text_align = "center", w=175, border_visible=false, background_color=Color('4c2065'), foreground=Color.white, size = 28, position={115,200}, help=TIM.loc.modSettingsHelp,
		on_callback = function(item)
			TIM:GlobalEventsListContainer()
		end})
	TIM._holder:Button({ name = "Upgrades_settings", text = TIM.loc.Upgrades_settings, text_align = "center", w=201, border_visible=false, background_color=Color('4c2065'), foreground=Color.white, size = 28, position={102,260}, help=TIM.loc.modSettingsHelp,
		on_callback = function(item)
			TIM:GlobalEventsUpgradesContainer()
		end})
end

function TIM:ChatAIRewardsContainer()
--TIM._settings.ChatAI.SpawnColor, TIM._settings.ChatAI.CharacterStatusColor, TIM._settings.ChatAI.DefaultUpgradeColor, TIM._settings.ChatAI.RestoreHealthColor, TIM._settings.ChatAI.IncreaseDamageColor, TIM._settings.ChatAI.DropAmmoColor
	--TIM._settings.ChatAI.SpawnPrice, 1, TIM._settings.ChatAI.DefaultUpgradePrice, TIM._settings.ChatAI.RestoreHealthPrice, TIM._settings.ChatAI.IncreaseDamagePrice, TIM._settings.ChatAI.DropAmmoPrice
	TIM._holder:ClearItems()
	TIM._holder:Divider({ name = "Divider", text_align = "center", size=25, position={0,15} ,foreground=Color('b6b6b6'), text = TIM.loc.CHATAI })
	TIM._holder:ImageButton({
        name = "MyImageButton",
		w= 40,
		h=40,
        texture = "guis/textures/icons/arrow",
        on_callback = function(item)
			TIM:save_settings()
            TIM:MainMenuContainer()
        end
    })
	local SpawnCharacter = TIM._holder:Group({ name = "SpawnCharacter", size = 18, text = TIM.loc.SpawnCharacter, closed = true})
	local CharacterStatus = TIM._holder:Group({ name = "CharacterStatus", size = 18, text = TIM.loc.CharacterStatus, closed = true})
	local DefaultUpgrade = TIM._holder:Group({ name = "DefaultUpgrade", size = 18, text = TIM.loc.DefaultUpgrade, closed = true})
	local IncreaseDamage = TIM._holder:Group({ name = "IncreaseDamage", size = 18, text = TIM.loc.IncreaseDamage, closed = true})
	local RestoreHealth = TIM._holder:Group({ name = "RestoreHealth", size = 18, text = TIM.loc.RestoreHealth, closed = true})
	local DropAmmo = TIM._holder:Group({ name = "DropAmmo", size = 18, text = TIM.loc.DropAmmo, closed = true})
	
	SpawnCharacter:ColorTextBox({name = "SpawnColor", text = TIM.loc.Color, value = TIM._settings.ChatAI.SpawnColor and Color(TIM._settings.ChatAI.SpawnColor) or Color(1,1,1), use_alpha=false, focus_mode=true, --position={0,100}, size=25, 
		on_callback = function(item)
			TIM._settings.ChatAI.SpawnColor=item:HexValue():upper()
		end})
	SpawnCharacter:NumberBox({name = "SpawnPrice", text = TIM.loc.Cost, floats=0, enabled=true, value=TIM._settings.ChatAI.SpawnPrice, focus_mode=true,
		on_callback = function(item)
			item:SetValue((item.value < 0) and 0 or item.value)
			TIM._settings.ChatAI.SpawnPrice=item.value
		end})	
	CharacterStatus:ColorTextBox({name = "CharacterStatusColor", text = TIM.loc.Color, value = TIM._settings.ChatAI.CharacterStatusColor and Color(TIM._settings.ChatAI.CharacterStatusColor) or Color(1,1,1), use_alpha=false, focus_mode=true,
		on_callback = function(item)
			TIM._settings.ChatAI.CharacterStatusColor=item:HexValue():upper()
		end})
	CharacterStatus:NumberBox({name = "CharacterStatusPrice", text = TIM.loc.Cost, floats=0, enabled=true, value=TIM._settings.ChatAI.CharacterStatusPrice, focus_mode=true,
		on_callback = function(item)
			item:SetValue((item.value < 0) and 0 or item.value)
			TIM._settings.ChatAI.CharacterStatusPrice=item.value
		end})
	DefaultUpgrade:ColorTextBox({name = "DefaultUpgradeColor", text = TIM.loc.Color, value =TIM._settings.ChatAI.DefaultUpgradeColor and Color(TIM._settings.ChatAI.DefaultUpgradeColor) or Color(1,1,1), use_alpha=false, focus_mode=true,
		on_callback = function(item)
			TIM._settings.ChatAI.DefaultUpgradeColor=item:HexValue():upper()
		end})	
	DefaultUpgrade:NumberBox({name = "DefaultUpgradePrice", text = TIM.loc.Cost, floats=0, enabled=true, value=TIM._settings.ChatAI.DefaultUpgradePrice, focus_mode=true,
		on_callback = function(item)
			item:SetValue((item.value < 0) and 0 or item.value)
			TIM._settings.ChatAI.DefaultUpgradePrice=item.value
		end})
	RestoreHealth:ColorTextBox({name = "RestoreHealthColor", text = TIM.loc.Color, value = TIM._settings.ChatAI.RestoreHealthColor and Color(TIM._settings.ChatAI.RestoreHealthColor) or Color(1,1,1), use_alpha=false, focus_mode=true,
		on_callback = function(item)
			TIM._settings.ChatAI.RestoreHealthColor=item:HexValue():upper()
		end})
	RestoreHealth:NumberBox({name = "RestoreHealthPrice", text = TIM.loc.Cost, floats=0, enabled=true, value=TIM._settings.ChatAI.RestoreHealthPrice, focus_mode=true,
		on_callback = function(item)
			item:SetValue((item.value < 0) and 0 or item.value)
			TIM._settings.ChatAI.RestoreHealthPrice=item.value
		end})
	IncreaseDamage:ColorTextBox({name = "IncreaseDamageColor", text = TIM.loc.Color, value = TIM._settings.ChatAI.IncreaseDamageColor and Color(TIM._settings.ChatAI.IncreaseDamageColor) or Color(1,1,1), use_alpha=false, focus_mode=true,
		on_callback = function(item)
			TIM._settings.ChatAI.IncreaseDamageColor=item:HexValue():upper()
		end})
	IncreaseDamage:NumberBox({name = "IncreaseDamagePrice", text = TIM.loc.Cost, floats=0, enabled=true, value=TIM._settings.ChatAI.IncreaseDamagePrice, focus_mode=true,
		on_callback = function(item)
			item:SetValue((item.value < 0) and 0 or item.value)
			TIM._settings.ChatAI.IncreaseDamagePrice=item.value
		end})	
	DropAmmo:ColorTextBox({name = "DropAmmoColor", text = TIM.loc.Color, value = TIM._settings.ChatAI.DropAmmoColor and Color(TIM._settings.ChatAI.DropAmmoColor) or Color(1,1,1), use_alpha=false, focus_mode=true,
		on_callback = function(item)
			TIM._settings.ChatAI.DropAmmoColor=item:HexValue():upper()
		end})
	DropAmmo:NumberBox({name = "DropAmmoPrice", text = TIM.loc.Cost, floats=0, enabled=true, value=TIM._settings.ChatAI.DropAmmoPrice, focus_mode=true,
		on_callback = function(item)
			item:SetValue((item.value < 0) and 0 or item.value)
			TIM._settings.ChatAI.DropAmmoPrice=item.value
		end})
	--:ColorTextBox({name = "background_color", text = TIM.loc.Color, value = Color(1,1,1), use_alpha=false})
end

function TIM:GlobalEventsSettingsContainer()
	TIM._holder:ClearItems()
	TIM._holder:Divider({ name = "Divider", text_align = "center", size=25, position={0,15} ,foreground=Color('b6b6b6'), text = TIM.loc.Global_events_settings })
	TIM._holder:ImageButton({
        name = "MyImageButton",
		w= 40,
		h=40,
        texture = "guis/textures/icons/arrow",
        on_callback = function(item)
			TIM:save_settings()
            TIM:GlobalEventsContainer()
        end
    })
	
	TIM._holder:Slider({ name = "start_delay", text = TIM.loc.PollsStartDelay, value = TIM._settings.PollsStartDelay, min = 0,
			max = 120, step = 1, floats=0, position={0,100},size=20,
			on_callback = function(item)
				local mod, f = math.modf(item.value)
				TIM._settings.PollsStartDelay= f>=0.5 and mod+1 or mod
				item:SetValue(f>=0.5 and mod+1 or mod)
				
			end
		})
	TIM._holder:Slider({ name = "PollsCooldown", text = TIM.loc.PollsCooldown, value = TIM._settings.PollsCooldown, min = 0,
			max = 120, step = 1, position={0,150}, floats=0,size=20,
			on_callback = function(item)
				local mod, f = math.modf(item.value)
				TIM._settings.PollsCooldown= f>=0.5 and mod+1 or mod
				item:SetValue(f>=0.5 and mod+1 or mod)
			end
		})
	TIM._holder:Slider({ name = "PollsDuration", text = TIM.loc.PollsDuration, value = TIM._settings.PollsDuration, min = 15,
			max = 120, step = 1, position={0,200}, floats=0,size=20,
			on_callback = function(item)
				local mod, f = math.modf(item.value)
				item:SetValue(f>=0.5 and mod+1 or mod)
				TIM._settings.PollsDuration= f>=0.5 and mod+1 or mod
			end
		})
	TIM._holder:Slider({ name = "PollsVariantsCount", text = TIM.loc.PollsVariantsCount, value = TIM._settings.PollsVariantsCount,
			min = 2, max = 5, step = 1, position={0,250}, floats=0,size=20,
			on_callback = function(item)
				local mod, f = math.modf(item.value)
				
				TIM._settings.PollsVariantsCount=f>=0.5 and mod+1 or mod
				item:SetValue(f>=0.5 and mod+1 or mod)
				--TIM._settings.PollsVariantsCount=item.value
			end
		})
	TIM._holder:Toggle({ name = "PollsBitsEnabled", text = TIM.loc.PollsBitsEnabled, value=TIM._settings.PollsBitsEnabled,  position={0,300}, size=20,
		on_callback = function(item)
			TIM._settings.PollsBitsEnabled = item:Value()
			TIM._holder:GetItem("PollsBitsPerVote"):SetEnabled(item:Value())
			TIM._holder:GetItem("PollsBitsPerVote"):SetValue(0)
			TIM._settings.PollsBitsPerVote = 0
			--TIM:save_settings()
		end })
		
	TIM._holder:NumberBox({ name = "PollsBitsPerVote", enabled=TIM._settings.PollsBitsEnabled, text = TIM.loc.PollsBitsPerVote, value = TIM._settings.PollsBitsPerVote,
		focus_mode = true, position={0,350}, size=20,floats=0,
		on_callback = function(item)
			if item:Value()<=0 then
				item:SetValue(0)
			end
			TIM._settings.PollsBitsPerVote = item:Value()
		end })
		
	TIM._holder:Toggle({ name = "PollsCPEnabled", text = TIM.loc.PollsCPEnabled, value=TIM._settings.PollsCPEnabled,  position={0,400}, size=20,
		on_callback = function(item)
			TIM._settings.PollsCPEnabled = item:Value()
			TIM._holder:GetItem("PollsCPPerVote"):SetEnabled(item:Value())
			TIM._holder:GetItem("PollsCPPerVote"):SetValue(0)
			TIM._settings.PollsCPPerVote = 0
			--TIM:save_settings()
		end })
	TIM._holder:NumberBox({ name = "PollsCPPerVote", enabled=TIM._settings.PollsCPEnabled,  text = TIM.loc.PollsCPPerVote, value = TIM._settings.PollsCPPerVote,
	focus_mode = true, position={0,450}, size=20,floats=0,
		on_callback = function(item)
			if item:Value()<=0 then
				item:SetValue(0)
			end
			TIM._settings.PollsCPPerVote = item:Value()
		end })

	
end

function TIM:GlobalEventsListContainer()
	TIM._holder:ClearItems()
	TIM._holder:Divider({ name = "Divider", text_align = "center", size=25, position={0,15} ,foreground=Color('b6b6b6'), text = TIM.loc.events_list })
	TIM._holder:ImageButton({
        name = "MyImageButton",
		w= 40,
		h=40,
        texture = "guis/textures/icons/arrow",
        on_callback = function(item)
			TIM:save_settings()
            TIM:GlobalEventsContainer()
        end
    })
	--TIM._listEvents = TIM._holder:Group({ name = "listEvents", size = 18, text = ""})
	
	
	for ID, value in pairs(TIM.PollEffectsForms or {}) do --подгрузка наград из файла config и добавление их в группу
		local value1 = true
		if TIM._settings.chosenPollsEffects[ID] ~= nil then
			value1 = TIM._settings.chosenPollsEffects[ID]
		end
		
		TIM._holder:Toggle({ name = ID, text = value.Name, value = value1 ,  help = value.Description, size=20,
		on_callback = function(item)
			local count=0
			for k, v in pairs(TIM._settings.chosenPollsEffects or {}) do
				if v == true then
					count = count + 1
				end
			end
			if TIM._settings.PollsVariantsCount < count then
				TIM._settings.chosenPollsEffects[item.name]=item.value
			else
				TIM._settings.chosenPollsEffects[item.name]=true
				item:SetValue(true)
			end
			--TIM:save_settings()
		end })
	end
end

function TIM:GlobalEventsUpgradesContainer()
	TIM._holder:ClearItems()
	TIM._holder:Divider({ name = "Divider", text_align = "center", size=25, position={0,15} ,foreground=Color('b6b6b6'), text = TIM.loc.Upgrades_settings })
	TIM._holder:ImageButton({
        name = "MyImageButton",
		w= 40,
		h=40,
        texture = "guis/textures/icons/arrow",
        on_callback = function(item)
			TIM:save_settings()
            TIM:GlobalEventsContainer()
        end
    })
	
	TIM._holder:NumberBox({ name = "Default_upgrade_price", text = TIM.loc.Default_upgrade_price, value = TIM._settings.Default_upgrade_price,
		focus_mode = true, position={0,100}, size=20,floats=0,
		on_callback = function(item)
			if item:Value()<=1 then
				item:SetValue(1)
			end
			TIM._settings.Default_upgrade_price = item:Value()
		end })
	
	TIM._holder:NumberBox({ name = "Upgrade_price_step_per_level", text = TIM.loc.Upgrade_price_step_per_level, value = TIM._settings.Upgrade_price_step_per_level,
		focus_mode = true, position={0,150}, size=20,floats=0,
		on_callback = function(item)
			if item:Value()<=1 then
				item:SetValue(1)
			end
			TIM._settings.Upgrade_price_step_per_level = item:Value()
		end })
		
	TIM._holder:Slider({ name = "Maximum_upgrade_level", text = TIM.loc.Maximum_upgrade_level, value = TIM._settings.Maximum_upgrade_level,
			min = 1, max = 15, step = 1, position={0,200}, floats=0,size=20,
			on_callback = function(item)
				local mod, f = math.modf(item.value)
				
				TIM._settings.Maximum_upgrade_level= f>=0.5 and mod+1 or mod
				item:SetValue(f>=0.5 and mod+1 or mod)
				--TIM._settings.PollsVariantsCount=item.value
			end
		})
end

function TIM:ChannelPointsRewardsContainer()
	TIM._holder:ClearItems()
	TIM._holder:Divider({ name = "Divider", text_align = "center", size=25, position={0,15} , text =TIM.loc.channelPoints --[[TIM.loc.CustomRewards]], foreground=Color('b6b6b6'), })
	TIM._holder:ImageButton({
        name = "MyImageButton",
		w= 40,
		h=40,
        texture = "guis/textures/icons/arrow",
        on_callback = function(item)
			TIM:save_settings()
			TIM:MainMenuContainer()
           -- TIM:ChannelPointsRewardsContainer()
        end
    })
	TIM._holder:Button({ name = "CreateRewards", text = TIM.loc.CREATE_NEW_REWARD, text_align = "center",  border_visible=false, background_color=Color('4c2065'), foreground=Color.white, size = 28, help=TIM.loc.CustomRewardsHelp,
		on_callback = function(item)
			MenuUI:new({
				name = "Reward",
				layer=1050,
				background_blur=true,
				create_items = callback(self, self, "newRewardFunction")
			})
		end})
	TIM._listChannelPointsRewards = TIM._holder:Group({ name = "Rewards", size = 18, text = TIM.loc.Channel_Points_Rewards})
	for RewardID, value in pairs((TIM._settings.TwitchRewards) or {}) do --подгрузка наград из файла config и добавление их в группу
		local but = TIM._listChannelPointsRewards:Button({ name = RewardID, text = value.title, text_align = "left", 
				on_callback = function(item)
						MenuUI:new({
							name = "Reward",
							layer=1050,
							background_blur=true,
							create_items = callback(self, self, "editRewardFunction", item.name)
						})
						
					--end
				end})
			but:ImageButton({
				name = but:Name(),
				--position=,
				w=20,
				h=20,
				offset = {0,0},
				texture = "guis/textures/icons/delete",
				on_callback = function(item)
					TIM.library.deleteRew(item.name)
					TIM._listChannelPointsRewards:GetItem(item.name):Destroy()
					TIM._settings.TwitchRewards[item.name]=nil
					TIM:save_settings()
				end
			})
			local textureStr = "guis/textures/icons/eyeClosed"
			if value.enabled == true then
				textureStr = "guis/textures/icons/eyeOpened"
			end
			but:ImageButton({name = but:Name(), w=20, h=20, offset = {0,0}, texture = textureStr, 
					on_callback = function(item)
						local enable = true
						if item.texture=="guis/textures/icons/eyeOpened" then
							item:SetImage("guis/textures/icons/eyeClosed")
							item:SetParam("texture", "guis/textures/icons/eyeClosed")
							enable=false
						else
							item:SetImage("guis/textures/icons/eyeOpened")
							item:SetParam("texture", "guis/textures/icons/eyeOpened")
							enable=true
						end
						--managers.mission._fading_debug_output:script().log(tostring(enable).." - "..item.texture,  Color.red)
						TIM.library.enableRew(but:Name(), enable)
						TIM._settings.TwitchRewards[but:Name()].enabled =enable
						--TIM.library.deleteRew(item.name)
						--TIM._listChannelPointsRewards:GetItem(item.name):Destroy()
						--TIM._settings.TwitchRewards[item.name]=nil
						TIM:save_settings()
					end})
		
	end

end

function TIM:DefaultRewardsContainer()
	TIM._holder:ClearItems()
	TIM._holder:Divider({ name = "Divider", text_align = "center", size=25, position={0,15} ,foreground=Color('b6b6b6'), text = TIM.loc.DefaultRewards })
	TIM._holder:ImageButton({
        name = "MyImageButton",
		w= 40,
		h=40,
        texture = "guis/textures/icons/arrow",
        on_callback = function(item)
			TIM:save_settings()
            TIM:ChannelPointsRewardsContainer()
        end
    })
	TIM._holder:Button({ name = "CreateRewards", text = TIM.loc.CREATE_NEW_REWARD, text_align = "center",  border_visible=false, background_color=Color('4c2065'), foreground=Color.white, size = 28, help=TIM.loc.CustomRewardsHelp,
		on_callback = function(item)
			MenuUI:new({
				name = "Reward",
				layer=1050,
				background_blur=true,
				create_items = callback(self, self, "newDefaultRewardFunction")
			})
		end})
		--параметр bool default
	TIM._listDefaultChannelPointsRewards = TIM._holder:Group({ name = "Rewards", size = 18, text = TIM.loc.Default_Channel_Points_Rewards})
	for RewardID, value in pairs((TIM._settings.TwitchRewards) or {}) do --подгрузка наград из файла config и добавление их в группу
		if value.default == true then 
			local but = TIM._listDefaultChannelPointsRewards:Button({ name = RewardID, text = value.title, text_align = "left", 
				on_callback = function(item)
						MenuUI:new({
							name = "Reward",
							layer=1050,
							background_blur=true,
							create_items = callback(self, self, "editDefaultRewardFunction", item.name)
						})
						
					--end
				end})
			but:ImageButton({
				name = but:Name(),
				--position=,
				w=20,
				h=20,
				offset = {0,0},
				texture = "guis/textures/icons/delete",
				on_callback = function(item)
					TIM.library.deleteRew(item.name)
					TIM._listDefaultChannelPointsRewards:GetItem(item.name):Destroy()
					TIM._settings.TwitchRewards[item.name]=nil
					TIM:save_settings()
				end
			})
		end
	end
end

function TIM:CustomRewardsContainer()
	--[[
	TIM._holder:ClearItems()
	TIM._holder:Divider({ name = "Divider", text_align = "center", size=25, position={0,15} , text = TIM.loc.CustomRewards, foreground=Color('b6b6b6'), })
	TIM._holder:ImageButton({
        name = "MyImageButton",
		w= 40,
		h=40,
        texture = "guis/textures/icons/arrow",
        on_callback = function(item)
			TIM:save_settings()
            TIM:ChannelPointsRewardsContainer()
        end
    })
	TIM._holder:Button({ name = "CreateRewards", text = TIM.loc.CREATE_NEW_REWARD, text_align = "center",  border_visible=false, background_color=Color('4c2065'), foreground=Color.white, size = 28, help=TIM.loc.CustomRewardsHelp,
		on_callback = function(item)
			MenuUI:new({
				name = "Reward",
				layer=1050,
				background_blur=true,
				create_items = callback(self, self, "newRewardFunction")
			})
		end})
	TIM._listChannelPointsRewards = TIM._holder:Group({ name = "Rewards", size = 18, text = TIM.loc.Channel_Points_Rewards})
	for RewardID, value in pairs((TIM._settings.TwitchRewards) or {}) do --подгрузка наград из файла config и добавление их в группу
		if value.default == false then 
			local but = TIM._listChannelPointsRewards:Button({ name = RewardID, text = value.title, text_align = "left", 
				on_callback = function(item)
						MenuUI:new({
							name = "Reward",
							layer=1050,
							background_blur=true,
							create_items = callback(self, self, "editRewardFunction", item.name)
						})
						
					--end
				end})
			but:ImageButton({
				name = but:Name(),
				--position=,
				w=20,
				h=20,
				offset = {0,0},
				texture = "guis/textures/icons/delete",
				on_callback = function(item)
					TIM.library.deleteRew(item.name)
					TIM._listChannelPointsRewards:GetItem(item.name):Destroy()
					TIM._settings.TwitchRewards[item.name]=nil
					TIM:save_settings()
				end
			})
			local textureStr = "guis/textures/icons/eyeClosed"
			if value.enabled == true then
				textureStr = "guis/textures/icons/eyeOpened"
			end
			but:ImageButton({name = but:Name(), w=20, h=20, offset = {0,0}, texture = textureStr, 
					on_callback = function(item)
						local enable = true
						if item.texture=="guis/textures/icons/eyeOpened" then
							item:SetImage("guis/textures/icons/eyeClosed")
							item:SetParam("texture", "guis/textures/icons/eyeClosed")
							enable=false
						else
							item:SetImage("guis/textures/icons/eyeOpened")
							item:SetParam("texture", "guis/textures/icons/eyeOpened")
							enable=true
						end
						--managers.mission._fading_debug_output:script().log(tostring(enable).." - "..item.texture,  Color.red)
						TIM.library.enableRew(but:Name(), enable)
						TIM._settings.TwitchRewards[but:Name()].enabled =enable
						--TIM.library.deleteRew(item.name)
						--TIM._listChannelPointsRewards:GetItem(item.name):Destroy()
						--TIM._settings.TwitchRewards[item.name]=nil
						TIM:save_settings()
					end})
		end
	end
	]]
end

function TIM:newRewardFunction(menu) -- создание новой награды
	
	TIM._rewardMenu=menu
	TIM.tempEffects={}
	TIM.tempEffects.effects={}
	local _dialog_reward = TIM._rewardMenu:Menu({name = "_dialog_reward", position = "Center", align_items = "grid", w = 470, visible = true,
		auto_height = true, auto_foreground = true, always_highlighting = true, reach_ignore_focus = false, scrollbar = true, max_height = 600,
		size = 20, offset = 8, accent_color = BeardLib.Options:GetValue("MenuColor"), background_color = Color('3d005e'), background_alpha = 0.99,
		align_method = "grid", border_color = Color('ffffff'), border_visible=true })
	_dialog_reward:Divider({name = "Rewards", size = 23, text_align = "center", text = TIM.loc.REWARD})
	_dialog_reward:TextBox({name = "title", text = TIM.loc.Title, focus_mode=true})
	_dialog_reward:TextBox({name = "prompt", text = TIM.loc.Description, focus_mode=true})
	_dialog_reward:NumberBox({name = "cost", text = TIM.loc.Cost, floats=0, value=1, focus_mode=true,
		on_callback = function(item)
			item:SetValue((item.value < 1) and 1 or item.value)
		end})
	--if TIM._settings.enableTacticMode==true then
		_dialog_reward:ComboBox({
			name = "stelfLoud",
			text = TIM.loc.Tactic_mode,
			items = {TIM.loc.Stealth, TIM.loc.Loud, TIM.loc.StealthLoud},
			value = 3,
			free_typing = false
		})
	--end
	_dialog_reward:Toggle({name = "is_enabled", text = TIM.loc.Enabled, value = true})
	_dialog_reward:ColorTextBox({name = "background_color", text = TIM.loc.Color, value = Color(1,1,1), use_alpha=false})			
	_dialog_reward:NumberBox({name = "max_per_stream", text = TIM.loc.Max_per_stream, floats=0, enabled=true, value=0, focus_mode=true,
		on_callback = function(item)
			item:SetValue((item.value < 0) and 0 or item.value)
		end})
	_dialog_reward:NumberBox({name = "max_per_user_per_stream", text = TIM.loc.Max_per_user_per_stream, floats=0, enabled=true, value=0, focus_mode=true,
		on_callback = function(item)
			item:SetValue((item.value < 0) and 0 or item.value)
		end})
	_dialog_reward:NumberBox({name = "global_cooldown_seconds", text = TIM.loc.Global_cooldown_minutes, floats=1, enabled=true, value=0, focus_mode=true,
		on_callback = function(item)
			item:SetValue((item.value < 0) and 0 or item.value)
		end})
	--_dialog_reward:Toggle({name = "should_redemptions_skip_request_queue", text = TIM.loc.Should_redemptions_skip_request_queue, value = false})
	_dialog_reward:Button({ name = "ADD NEW EFFECT", text = TIM.loc.ADD_NEW_EFFECT, text_align = "center",
		on_callback = function(item)
			TIM._listEffectsMenu:Enable()
		end})
	_dialog_reward:Group({ name = "EffectsGroup", size = 18, text = TIM.loc.Effects})
	_dialog_reward:Divider({ name="Response", text=TIM.loc.Response })
	_dialog_reward:Button({ name = "OK", text = TIM.loc.OK, w = 150,
		on_callback = function(item) --создание награды на твиче
			local boolTactic = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("is_enabled"):Value() --проверка на стелс доделать!
			
			--if TIM._settings.enableTacticMode==true then
				if TIM.BotChatActive == true or TIM.BotPointsActive==true then
					boolTactic=false
				end 
				--local boolTacticS = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("is_enabled"):Value() --проверка на стелс доделать!
				if Utils:IsInHeist() == true then 
					boolTactic=TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("is_enabled"):Value()
					if TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("stelfLoud"):Value()==1 then
						boolTactic=boolTactic and managers.groupai:state():whisper_mode()==true
					elseif TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("stelfLoud"):Value()==2 then
						boolTactic=boolTactic and managers.groupai:state():whisper_mode()==false
					end
				end
			--end
			local err, rewardIDtemp = TIM.library.createRew(TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("title"):Value(),
			TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("prompt"):Value(),
			TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("cost"):Value(),
			boolTactic,
			"#".. TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("background_color"):HexValue():upper(),
			TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("max_per_stream"):Value()>0,
			TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("max_per_stream"):Value(),
			TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("max_per_user_per_stream"):Value()>0,
			TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("max_per_user_per_stream"):Value(),
			TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("global_cooldown_seconds"):Value()>0,
			TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("global_cooldown_seconds"):Value()*60,
			false)	
			--managers.mission._fading_debug_output:script().log("1-  "..tostring(temp),  Color.green)
			if err==true then
				local responseMess = json.decode(rewardIDtemp)
				TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("Response"):SetText(TIM.loc.Response ..responseMess.message)
			else
				local but = TIM._listChannelPointsRewards:Button({ name = tostring(rewardIDtemp), text = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("title"):Value(), text_align = "left", 
				on_callback = function(item2) --создание подгрузки данных с твича 
					MenuUI:new({
						name = "Reward",
						layer=1050,
						background_blur=true, --(o, base_callback_class, base_callback_func_name, base_callback_param)
						create_items = callback(self, self, "editRewardFunction", item2.name)
					})
					--TIM._rewardMenu:Enable()
				end })
				local textureStr = "guis/textures/icons/eyeClosed"
				if TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("is_enabled"):Value() == true then 
					textureStr = "guis/textures/icons/eyeOpened"
				end
				
				but:ImageButton({name = but:Name(), w=20, h=20, offset = {0,0}, texture = "guis/textures/icons/delete",
					on_callback = function(item)
						TIM.library.deleteRew(item.name)
						TIM._listChannelPointsRewards:GetItem(item.name):Destroy()
						TIM._settings.TwitchRewards[item.name]=nil
						TIM:save_settings()
					end})
				but:ImageButton({name = but:Name(), w=20, h=20, offset = {0,0}, texture = textureStr, 
					on_callback = function(item)
						local enable = true
						if item.texture=="guis/textures/icons/eyeOpened" then
							item:SetImage("guis/textures/icons/eyeClosed")
							item:SetParam("texture", "guis/textures/icons/eyeClosed")
							enable=false
						else
							item:SetImage("guis/textures/icons/eyeOpened")
							item:SetParam("texture", "guis/textures/icons/eyeOpened")
							enable=true
						end
						--managers.mission._fading_debug_output:script().log(tostring(enable).." - "..item.texture,  Color.red)
						TIM.library.enableRew(but:Name(), enable)
						TIM._settings.TwitchRewards[but:Name()].enabled =enable
						--TIM.library.deleteRew(item.name)
						--TIM._listChannelPointsRewards:GetItem(item.name):Destroy()
						--TIM._settings.TwitchRewards[item.name]=nil
						TIM:save_settings()
					end})
				TIM._settings.TwitchRewards[rewardIDtemp] ={}
				TIM._settings.TwitchRewards[rewardIDtemp].title = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("title"):Value()
				TIM._settings.TwitchRewards[rewardIDtemp].prompt = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("prompt"):Value()
				TIM._settings.TwitchRewards[rewardIDtemp].cost = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("cost"):Value()
				TIM._settings.TwitchRewards[rewardIDtemp].background_color = "#".. TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("background_color"):HexValue():upper()
				TIM._settings.TwitchRewards[rewardIDtemp].is_max_per_stream = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("max_per_stream"):Value()>0
				TIM._settings.TwitchRewards[rewardIDtemp].max_per_stream = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("max_per_stream"):Value()
				TIM._settings.TwitchRewards[rewardIDtemp].is_max_per_user_per_stream = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("max_per_user_per_stream"):Value()>0
				TIM._settings.TwitchRewards[rewardIDtemp].max_per_user_per_stream = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("max_per_user_per_stream"):Value()
				TIM._settings.TwitchRewards[rewardIDtemp].is_global_cooldown_seconds = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("global_cooldown_seconds"):Value()>0
				TIM._settings.TwitchRewards[rewardIDtemp].global_cooldown_seconds = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("global_cooldown_seconds"):Value()
				TIM._settings.TwitchRewards[rewardIDtemp].effects=TIM.tempEffects.effects
				--TIM._settings.TwitchRewards[rewardIDtemp].default=false
				TIM._settings.TwitchRewards[rewardIDtemp].enabled = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("is_enabled"):Value()
				TIM._settings.TwitchRewards[rewardIDtemp].tactic= TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("stelfLoud") and TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("stelfLoud"):Value() or 3
				TIM._rewardMenu:Destroy()
			end
			
			TIM:save_settings()
		end
	})
	_dialog_reward:Button({name = "Cancel", text = TIM.loc.Cancel, w = 150,
		on_callback = function(item)
			TIM._rewardMenu:Destroy()
		end })
	TIM._rewardMenu:Enable()
	
end

function TIM:editRewardFunction(rewardID, menu) -- Редактирование существующей награды
	TIM.tempReward={}
	TIM.tempReward["rewardID"]=rewardID
	TIM.tempReward["tactic"] = TIM._settings.TwitchRewards[rewardID].tactic and TIM._settings.TwitchRewards[TIM.tempReward["rewardID"]].tactic or 3
	local err, title, prompt, cost, is_enabled, background_color, is_max_per_stream_enabled, max_per_stream, is_max_per_user_per_stream_enabled, max_per_user_per_stream, is_global_cooldown_enabled, global_cooldown_seconds = TIM.library.getRew(rewardID)
	
	--TIM.tempReward["should_redemptions_skip_request_queue"] = should_redemptions_skip_request_queue
	if err==true then
		if TIM._listChannelPointsRewards:GetItem(rewardID):Text():find(TIM.loc.ERROR_cant_load_reward) then 
		
		else
			TIM._listChannelPointsRewards:GetItem(rewardID):SetText( TIM._listChannelPointsRewards:GetItem(rewardID):Text().. TIM.loc.ERROR_cant_load_reward)
		end
	else
		TIM.tempReward["title"] = title
		TIM.tempReward["prompt"] = prompt
		TIM.tempReward["cost"] = cost
		if TIM._settings.TwitchRewards[rewardID].enabled == nil then
			TIM._settings.TwitchRewards[rewardID].enabled = true
		end
		TIM.tempReward["is_enabled_real"] = TIM._settings.TwitchRewards[rewardID].enabled-- and TIM._settings.TwitchRewards[TIM.tempReward["rewardID"]].enabled or true
		TIM.tempReward["is_enabled_fake"] = is_enabled
		TIM.tempReward["background_color"] = string.lower(string.sub(background_color,2))
		TIM.tempReward["is_max_per_stream_enabled"] = is_max_per_stream_enabled
		TIM.tempReward["max_per_stream"] = max_per_stream
		TIM.tempReward["is_max_per_user_per_stream_enabled"] = is_max_per_user_per_stream_enabled
		TIM.tempReward["max_per_user_per_stream"] = max_per_user_per_stream
		TIM.tempReward["is_global_cooldown_enabled"] = is_global_cooldown_enabled
		TIM.tempReward["global_cooldown_seconds"] = global_cooldown_seconds/60
		TIM._rewardMenu=menu
		local _dialog_reward = TIM._rewardMenu:Menu({name = "_dialog_reward", position = "Center", align_items = "grid", w = 470, visible = true,
			auto_height = true, auto_foreground = true, always_highlighting = true, reach_ignore_focus = false, scrollbar = true, max_height = 600,
			size = 20, offset = 8, accent_color = BeardLib.Options:GetValue("MenuColor"), background_color = Color('3d005e'), background_alpha = 0.99,
			align_method = "grid", border_color = Color('ffffff'), border_visible=true })
		_dialog_reward:Divider({name = "Rewards", size = 23, text_align = "center", text = TIM.loc.REWARD})
		_dialog_reward:TextBox({name = "title", text = TIM.loc.Title, value = TIM.tempReward["title"], focus_mode=true})
		_dialog_reward:TextBox({name = "prompt", text = TIM.loc.Description, value = TIM.tempReward["prompt"], focus_mode=true})
		_dialog_reward:NumberBox({name = "cost", text = TIM.loc.Cost, floats=0, value=TIM.tempReward["cost"], focus_mode=true,
			on_callback = function(item)
				item:SetValue((item.value < 1) and 1 or item.value)
			end})
		--if TIM._settings.enableTacticMode==true then
			_dialog_reward:ComboBox({
				name = "stelfLoud",
				text = TIM.loc.Tactic_mode,
				items = {TIM.loc.Stealth, TIM.loc.Loud, TIM.loc.StealthLoud},
				value = TIM.tempReward["tactic"],
				free_typing = false
			})
		--end
		_dialog_reward:Toggle({name = "is_enabled", text = TIM.loc.Enabled, value = TIM.tempReward["is_enabled_real"]})
		_dialog_reward:ColorTextBox({name = "background_color", text = TIM.loc.Color, value = Color(TIM.tempReward["background_color"]), use_alpha=false, focus_mode=true})			
		_dialog_reward:NumberBox({name = "max_per_stream", text = TIM.loc.Max_per_stream, floats=0, enabled=true, value=TIM.tempReward["max_per_stream"], focus_mode=true,
			on_callback = function(item)
				item:SetValue((item.value < 0) and 0 or item.value)
			end})
		_dialog_reward:NumberBox({name = "max_per_user_per_stream", text = TIM.loc.Max_per_user_per_stream, floats=0, enabled=true, value=TIM.tempReward["max_per_user_per_stream"], focus_mode=true,
			on_callback = function(item)
				item:SetValue((item.value < 0) and 0 or item.value)
			end})
		_dialog_reward:NumberBox({name = "global_cooldown_seconds", text = TIM.loc.Global_cooldown_minutes, floats=1, enabled=true, value=TIM.tempReward["global_cooldown_seconds"], focus_mode=true,
			on_callback = function(item)
				item:SetValue((item.value < 0) and 0 or item.value)
			end})
		--_dialog_reward:Toggle({name = "should_redemptions_skip_request_queue", text = TIM.loc.Should_redemptions_skip_request_queue, value = TIM.tempReward["should_redemptions_skip_request_queue"]})
		_dialog_reward:Button({ name = "ADD NEW EFFECT", text = TIM.loc.ADD_NEW_EFFECT, text_align = "center",
			on_callback = function(item)
				TIM._listEffectsMenu:Enable()
			end})
		_dialog_reward:Group({ name = "EffectsGroup", size = 18, text = TIM.loc.Effects})
		_dialog_reward:Button({ name = "OK", text = TIM.loc.OK, w = 150,
		on_callback = function(item) --редактирование награды на твиче
			local err, temp = false
			local boolTactic=TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("is_enabled"):Value()
			--if TIM._settings.enableTacticMode==true then
				if TIM.BotChatActive == true or TIM.BotPointsActive==true then
					boolTactic=TIM.tempReward["is_enabled_fake"]
				end 
				--local boolTacticS = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("is_enabled"):Value() --проверка на стелс доделать!
				if Utils:IsInHeist() == true then 
					boolTactic=TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("is_enabled"):Value()
					if TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("stelfLoud"):Value()==1 then
						boolTactic=boolTactic and managers.groupai:state():whisper_mode()==true
					elseif TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("stelfLoud"):Value()==2 then
						boolTactic=boolTactic and managers.groupai:state():whisper_mode()==false
					end
				end
			--end
			if TIM.tempReward["title"]~=TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("title"):Value() or TIM.tempReward["prompt"]~=TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("prompt"):Value() or TIM.tempReward["cost"]~=TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("cost"):Value() or TIM.tempReward["is_enabled_fake"]~=boolTactic or TIM.tempReward["background_color"]~=TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("background_color"):HexValue() or TIM.tempReward["max_per_stream"]~=TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("max_per_stream"):Value() or TIM.tempReward["max_per_user_per_stream"]~=TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("max_per_user_per_stream"):Value() or TIM.tempReward["global_cooldown_seconds"]~=TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("global_cooldown_seconds"):Value() then
				err, temp = TIM.library.editRew(TIM.tempReward["rewardID"], 
				TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("title"):Value(),
				TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("prompt"):Value(),
				TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("cost"):Value(),
				boolTactic,
				"#".. TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("background_color"):HexValue():upper(),
				TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("max_per_stream"):Value()>0,
				TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("max_per_stream"):Value(),
				TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("max_per_user_per_stream"):Value()>0,
				TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("max_per_user_per_stream"):Value(),
				TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("global_cooldown_seconds"):Value()>0,
				TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("global_cooldown_seconds"):Value()*60,
				false)
			end
			if err==true then
				local responseMess = json.decode(temp)
				TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("Response"):SetText(TIM.loc.Response ..responseMess.message)
				--TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("Response"):SetText("Response: "..temp)
			else
				TIM._settings.TwitchRewards[TIM.tempReward["rewardID"]].title = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("title"):Value()
				TIM._settings.TwitchRewards[TIM.tempReward["rewardID"]].effects=TIM.tempEffects.effects
				TIM._settings.TwitchRewards[TIM.tempReward["rewardID"]].tactic = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("stelfLoud") and TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("stelfLoud"):Value() or 3
				TIM._settings.TwitchRewards[TIM.tempReward["rewardID"]].enabled = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("is_enabled"):Value()
				TIM._settings.TwitchRewards[TIM.tempReward["rewardID"]].prompt = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("prompt"):Value()
				TIM._settings.TwitchRewards[TIM.tempReward["rewardID"]].cost = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("cost"):Value()
				TIM._settings.TwitchRewards[TIM.tempReward["rewardID"]].background_color = "#".. TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("background_color"):HexValue():upper()
				TIM._settings.TwitchRewards[TIM.tempReward["rewardID"]].is_max_per_stream = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("max_per_stream"):Value()>0
				TIM._settings.TwitchRewards[TIM.tempReward["rewardID"]].max_per_stream = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("max_per_stream"):Value()
				TIM._settings.TwitchRewards[TIM.tempReward["rewardID"]].is_max_per_user_per_stream = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("max_per_user_per_stream"):Value()>0
				TIM._settings.TwitchRewards[TIM.tempReward["rewardID"]].max_per_user_per_stream = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("max_per_user_per_stream"):Value()
				TIM._settings.TwitchRewards[TIM.tempReward["rewardID"]].is_global_cooldown_seconds = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("global_cooldown_seconds"):Value()>0
				TIM._settings.TwitchRewards[TIM.tempReward["rewardID"]].global_cooldown_seconds = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("global_cooldown_seconds"):Value()
				TIM._listChannelPointsRewards:GetItem(TIM.tempReward["rewardID"]):SetText(TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("title"):Value())
				TIM.tempReward={}
				TIM._rewardMenu:Destroy()
				
				TIM:save_settings()
			end
		end
		})
		_dialog_reward:Button({name = "Cancel", text = TIM.loc.Cancel, w = 150,
			on_callback = function(item)
				TIM._rewardMenu:Destroy()
			end })
		_dialog_reward:Divider({ name="Response", text=TIM.loc.Response })
		TIM.tempEffects = {}
		TIM.tempEffects.effects = TIM._settings.TwitchRewards[rewardID].effects
		for k1, v1 in pairs((TIM.tempEffects.effects) or {}) do
			local but_effect = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("EffectsGroup"):Button({ name = k1, text = TIM._effectsForms[k1].Name, text_align = "left", 
				on_callback = function(item1)								
					MenuUI:new({
						name = item1.name,
						background_blur=true,
						layer = 1100,
						create_items = callback(self, self, "CreateEffect"),
						effect_exists=true,
						rewardID=rewardID
					})
					TIM._effectFormMenu:Enable()
				end})
			but_effect:ImageButton({ name = but_effect:Name(), w=20, h=20, offset = {0,0}, texture = "guis/textures/icons/delete",
				on_callback = function(item)
					TIM.tempEffects.effects[item.name]=nil
					TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("EffectsGroup"):GetItem(item.name):Destroy()
				end
			})
		end		
		TIM._rewardMenu:Enable()
	end
	
	
end

function TIM:newDefaultRewardFunction(menu) -- создание новой награды
	
	TIM._rewardMenu=menu
	TIM.tempEffects={}
	TIM.tempEffects.effects={}
	local _dialog_reward = TIM._rewardMenu:Menu({name = "_dialog_reward", position = "Center", align_items = "grid", w = 470, visible = true,
		auto_height = true, auto_foreground = true, always_highlighting = true, reach_ignore_focus = false, scrollbar = true, max_height = 600,
		size = 20, offset = 8, accent_color = BeardLib.Options:GetValue("MenuColor"), background_color = Color('3d005e'), background_alpha = 0.99,
		align_method = "grid", border_color = Color('ffffff'), border_visible=true })
	_dialog_reward:Divider({name = "Rewards", size = 23, text_align = "center", text = TIM.loc.REWARD})
	_dialog_reward:TextBox({name = "title", text = TIM.loc.Title, focus_mode=true})
	_dialog_reward:TextBox({name = "prompt", text = TIM.loc.Description, focus_mode=true})
	_dialog_reward:NumberBox({name = "cost", text = TIM.loc.Cost, floats=0, value=1, focus_mode=true,
		on_callback = function(item)
			item:SetValue((item.value < 1) and 1 or item.value)
		end})
	--[[if TIM._settings.enableTacticMode==true then
		_dialog_reward:ComboBox({
			name = "stelfLoud",
			text = TIM.loc.Tactic_mode,
			items = {TIM.loc.Stealth, TIM.loc.Loud, TIM.loc.StealthLoud},
			value = 3,
			free_typing = false
		})
	--end]]
	_dialog_reward:Toggle({name = "is_enabled", text = TIM.loc.Enabled, value = true})
	_dialog_reward:ColorTextBox({name = "background_color", text = TIM.loc.Color, value = Color(1,1,1), use_alpha=false})			
	_dialog_reward:NumberBox({name = "max_per_stream", text = TIM.loc.Max_per_stream, floats=0, enabled=true, value=0, focus_mode=true,
		on_callback = function(item)
			item:SetValue((item.value < 0) and 0 or item.value)
		end})
	_dialog_reward:NumberBox({name = "max_per_user_per_stream", text = TIM.loc.Max_per_user_per_stream, floats=0, enabled=true, value=0, focus_mode=true,
		on_callback = function(item)
			item:SetValue((item.value < 0) and 0 or item.value)
		end})
	_dialog_reward:NumberBox({name = "global_cooldown_seconds", text = TIM.loc.Global_cooldown_minutes, floats=1, enabled=true, value=0, focus_mode=true,
		on_callback = function(item)
			item:SetValue((item.value < 0) and 0 or item.value)
		end})
	--_dialog_reward:Toggle({name = "should_redemptions_skip_request_queue", text = TIM.loc.Should_redemptions_skip_request_queue, value = false})
	--[[
	_dialog_reward:Button({ name = "ADD NEW EFFECT", text = TIM.loc.ADD_NEW_EFFECT, text_align = "center",
		on_callback = function(item)
			TIM._listEffectsMenu:Enable()
		end})
		]]
	--_dialog_reward:Group({ name = "EffectsGroup", size = 18, text = TIM.loc.Effects})
	_dialog_reward:Divider({ name="Response", text=TIM.loc.Response })
	_dialog_reward:Button({ name = "OK", text = TIM.loc.OK, w = 150,
		on_callback = function(item) --создание награды на твиче
			local boolTactic = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("is_enabled"):Value() --проверка на стелс доделать!
			
			--if TIM._settings.enableTacticMode==true then
				if TIM.BotChatActive == true or TIM.BotPointsActive==true then
					boolTactic=false
				end 
				--local boolTacticS = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("is_enabled"):Value() --проверка на стелс доделать!
				if Utils:IsInHeist() == true then 
					boolTactic=TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("is_enabled"):Value()
					if TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("stelfLoud"):Value()==1 then
						boolTactic=boolTactic and managers.groupai:state():whisper_mode()==true
					elseif TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("stelfLoud"):Value()==2 then
						boolTactic=boolTactic and managers.groupai:state():whisper_mode()==false
					end
				end
			--end
			local err, rewardIDtemp = TIM.library.createRew(TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("title"):Value(),
			TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("prompt"):Value(),
			TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("cost"):Value(),
			boolTactic,
			"#".. TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("background_color"):HexValue():upper(),
			TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("max_per_stream"):Value()>0,
			TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("max_per_stream"):Value(),
			TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("max_per_user_per_stream"):Value()>0,
			TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("max_per_user_per_stream"):Value(),
			TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("global_cooldown_seconds"):Value()>0,
			TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("global_cooldown_seconds"):Value()*60,
			false)	
			--managers.mission._fading_debug_output:script().log("1-  "..tostring(temp),  Color.green)
			if err==true then
				local responseMess = json.decode(rewardIDtemp)
				TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("Response"):SetText(TIM.loc.Response ..responseMess.message)
			else
				local but = TIM._listChannelPointsRewards:Button({ name = tostring(rewardIDtemp), text = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("title"):Value(), text_align = "left", 
				on_callback = function(item2) --создание подгрузки данных с твича 
					MenuUI:new({
						name = "Reward",
						layer=1050,
						background_blur=true, --(o, base_callback_class, base_callback_func_name, base_callback_param)
						create_items = callback(self, self, "editDefaultRewardFunction", item2.name)
					})
					--TIM._rewardMenu:Enable()
				end })
				but:ImageButton({name = but:Name(), w=20, h=20, offset = {0,0}, texture = "guis/textures/icons/delete",
					on_callback = function(item)
						TIM.library.deleteRew(item.name)
						TIM._listChannelPointsRewards:GetItem(item.name):Destroy()
						TIM._settings.TwitchRewards[item.name]=nil
						TIM:save_settings()
					end})
				
				TIM._settings.TwitchRewards[rewardIDtemp] ={}
				TIM._settings.TwitchRewards[rewardIDtemp].title = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("title"):Value()
				TIM._settings.TwitchRewards[rewardIDtemp].effects=TIM.tempEffects.effects
				TIM._settings.TwitchRewards[rewardIDtemp].default=true
				TIM._settings.TwitchRewards[rewardIDtemp].enabled = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("is_enabled"):Value()
				TIM._settings.TwitchRewards[rewardIDtemp].tactic= TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("stelfLoud") and TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("stelfLoud"):Value() or 3
				TIM._rewardMenu:Destroy()
			end
			
			TIM:save_settings()
		end
	})
	_dialog_reward:Button({name = "Cancel", text = TIM.loc.Cancel, w = 150,
		on_callback = function(item)
			TIM._rewardMenu:Destroy()
		end })
	TIM._rewardMenu:Enable()
	
end

function TIM:editDefaultRewardFunction(rewardID, menu) -- Редактирование существующей награды
	TIM.tempReward={}
	TIM.tempReward["rewardID"]=rewardID
	TIM.tempReward["tactic"] = TIM._settings.TwitchRewards[rewardID].tactic and TIM._settings.TwitchRewards[TIM.tempReward["rewardID"]].tactic or 3
	local err, title, prompt, cost, is_enabled, background_color, is_max_per_stream_enabled, max_per_stream, is_max_per_user_per_stream_enabled, max_per_user_per_stream, is_global_cooldown_enabled, global_cooldown_seconds = TIM.library.getRew(rewardID)
	TIM.tempReward["title"] = title
	TIM.tempReward["prompt"] = prompt
	TIM.tempReward["cost"] = cost
	if TIM._settings.TwitchRewards[rewardID].enabled == nil then
		TIM._settings.TwitchRewards[rewardID].enabled = true
	end
	TIM.tempReward["is_enabled_real"] = TIM._settings.TwitchRewards[rewardID].enabled-- and TIM._settings.TwitchRewards[TIM.tempReward["rewardID"]].enabled or true
	TIM.tempReward["is_enabled_fake"] = is_enabled
	TIM.tempReward["background_color"] = string.lower(string.sub(background_color,2))
	TIM.tempReward["is_max_per_stream_enabled"] = is_max_per_stream_enabled
	TIM.tempReward["max_per_stream"] = max_per_stream
	TIM.tempReward["is_max_per_user_per_stream_enabled"] = is_max_per_user_per_stream_enabled
	TIM.tempReward["max_per_user_per_stream"] = max_per_user_per_stream
	TIM.tempReward["is_global_cooldown_enabled"] = is_global_cooldown_enabled
	TIM.tempReward["global_cooldown_seconds"] = global_cooldown_seconds/60
	--TIM.tempReward["should_redemptions_skip_request_queue"] = should_redemptions_skip_request_queue
	if err==true then
		if TIM._listChannelPointsRewards:GetItem(rewardID):Text():find(TIM.loc.ERROR_cant_load_reward) then 
		
		else
			TIM._listChannelPointsRewards:GetItem(rewardID):SetText( TIM._listChannelPointsRewards:GetItem(rewardID):Text().. TIM.loc.ERROR_cant_load_reward)
		end
	else
		TIM._rewardMenu=menu
		local _dialog_reward = TIM._rewardMenu:Menu({name = "_dialog_reward", position = "Center", align_items = "grid", w = 470, visible = true,
			auto_height = true, auto_foreground = true, always_highlighting = true, reach_ignore_focus = false, scrollbar = true, max_height = 600,
			size = 20, offset = 8, accent_color = BeardLib.Options:GetValue("MenuColor"), background_color = Color('3d005e'), background_alpha = 0.99,
			align_method = "grid", border_color = Color('ffffff'), border_visible=true })
		_dialog_reward:Divider({name = "Rewards", size = 23, text_align = "center", text = TIM.loc.REWARD})
		_dialog_reward:TextBox({name = "title", text = TIM.loc.Title, value = TIM.tempReward["title"], focus_mode=true})
		_dialog_reward:TextBox({name = "prompt", text = TIM.loc.Description, value = TIM.tempReward["prompt"], focus_mode=true})
		_dialog_reward:NumberBox({name = "cost", text = TIM.loc.Cost, floats=0, value=TIM.tempReward["cost"], focus_mode=true,
			on_callback = function(item)
				item:SetValue((item.value < 1) and 1 or item.value)
			end})
		--if TIM._settings.enableTacticMode==true then
			_dialog_reward:ComboBox({
				name = "stelfLoud",
				text = TIM.loc.Tactic_mode,
				items = {TIM.loc.Stealth, TIM.loc.Loud, TIM.loc.StealthLoud},
				value = TIM.tempReward["tactic"],
				free_typing = false
			})
		--end
		_dialog_reward:Toggle({name = "is_enabled", text = TIM.loc.Enabled, value = TIM.tempReward["is_enabled_real"]})
		_dialog_reward:ColorTextBox({name = "background_color", text = TIM.loc.Color, value = Color(TIM.tempReward["background_color"]), use_alpha=false, focus_mode=true})			
		_dialog_reward:NumberBox({name = "max_per_stream", text = TIM.loc.Max_per_stream, floats=0, enabled=true, value=TIM.tempReward["max_per_stream"], focus_mode=true,
			on_callback = function(item)
				item:SetValue((item.value < 0) and 0 or item.value)
			end})
		_dialog_reward:NumberBox({name = "max_per_user_per_stream", text = TIM.loc.Max_per_user_per_stream, floats=0, enabled=true, value=TIM.tempReward["max_per_user_per_stream"], focus_mode=true,
			on_callback = function(item)
				item:SetValue((item.value < 0) and 0 or item.value)
			end})
		_dialog_reward:NumberBox({name = "global_cooldown_seconds", text = TIM.loc.Global_cooldown_minutes, floats=1, enabled=true, value=TIM.tempReward["global_cooldown_seconds"], focus_mode=true,
			on_callback = function(item)
				item:SetValue((item.value < 0) and 0 or item.value)
			end})
		--_dialog_reward:Toggle({name = "should_redemptions_skip_request_queue", text = TIM.loc.Should_redemptions_skip_request_queue, value = TIM.tempReward["should_redemptions_skip_request_queue"]})
		_dialog_reward:Button({ name = "ADD NEW EFFECT", text = TIM.loc.ADD_NEW_EFFECT, text_align = "center",
			on_callback = function(item)
				TIM._listEffectsMenu:Enable()
			end})
		_dialog_reward:Group({ name = "EffectsGroup", size = 18, text = TIM.loc.Effects})
		_dialog_reward:Button({ name = "OK", text = TIM.loc.OK, w = 150,
		on_callback = function(item) --редактирование награды на твиче
			local err, temp = false
			local boolTactic=TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("is_enabled"):Value()
			--if TIM._settings.enableTacticMode==true then
				if TIM.BotChatActive == true or TIM.BotPointsActive==true then
					boolTactic=TIM.tempReward["is_enabled_fake"]
				end 
				--local boolTacticS = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("is_enabled"):Value() --проверка на стелс доделать!
				if Utils:IsInHeist() == true then 
					boolTactic=TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("is_enabled"):Value()
					if TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("stelfLoud"):Value()==1 then
						boolTactic=boolTactic and managers.groupai:state():whisper_mode()==true
					elseif TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("stelfLoud"):Value()==2 then
						boolTactic=boolTactic and managers.groupai:state():whisper_mode()==false
					end
				end
			--end
			if TIM.tempReward["title"]~=TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("title"):Value() or TIM.tempReward["prompt"]~=TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("prompt"):Value() or TIM.tempReward["cost"]~=TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("cost"):Value() or TIM.tempReward["is_enabled_fake"]~=boolTactic or TIM.tempReward["background_color"]~=TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("background_color"):HexValue() or TIM.tempReward["max_per_stream"]~=TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("max_per_stream"):Value() or TIM.tempReward["max_per_user_per_stream"]~=TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("max_per_user_per_stream"):Value() or TIM.tempReward["global_cooldown_seconds"]~=TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("global_cooldown_seconds"):Value() then
				err, temp = TIM.library.editRew(TIM.tempReward["rewardID"], 
				TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("title"):Value(),
				TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("prompt"):Value(),
				TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("cost"):Value(),
				boolTactic,
				"#".. TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("background_color"):HexValue():upper(),
				TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("max_per_stream"):Value()>0,
				TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("max_per_stream"):Value(),
				TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("max_per_user_per_stream"):Value()>0,
				TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("max_per_user_per_stream"):Value(),
				TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("global_cooldown_seconds"):Value()>0,
				TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("global_cooldown_seconds"):Value()*60,
				false)
			end
			if err==true then
				local responseMess = json.decode(temp)
				TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("Response"):SetText(TIM.loc.Response ..responseMess.message)
				--TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("Response"):SetText("Response: "..temp)
			else
				TIM._settings.TwitchRewards[TIM.tempReward["rewardID"]].title = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("title"):Value()
				TIM._settings.TwitchRewards[TIM.tempReward["rewardID"]].effects=TIM.tempEffects.effects
				TIM._settings.TwitchRewards[TIM.tempReward["rewardID"]].tactic = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("stelfLoud") and TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("stelfLoud"):Value() or 3
				TIM._settings.TwitchRewards[TIM.tempReward["rewardID"]].enabled = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("is_enabled"):Value()
				TIM._listChannelPointsRewards:GetItem(TIM.tempReward["rewardID"]):SetText(TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("title"):Value())
				TIM.tempReward={}
				TIM._rewardMenu:Destroy()
				
				TIM:save_settings()
			end
		end
		})
		_dialog_reward:Button({name = "Cancel", text = TIM.loc.Cancel, w = 150,
			on_callback = function(item)
				TIM._rewardMenu:Destroy()
			end })
		_dialog_reward:Divider({ name="Response", text=TIM.loc.Response })
		TIM.tempEffects = {}
		TIM.tempEffects.effects = TIM._settings.TwitchRewards[rewardID].effects
		for k1, v1 in pairs((TIM.tempEffects.effects) or {}) do
			local but_effect = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("EffectsGroup"):Button({ name = k1, text = TIM._effectsForms[k1].Name, text_align = "left", 
				on_callback = function(item1)								
					MenuUI:new({
						name = item1.name,
						background_blur=true,
						layer = 1100,
						create_items = callback(self, self, "CreateEffect"),
						effect_exists=true,
						rewardID=rewardID
					})
					TIM._effectFormMenu:Enable()
				end})
			but_effect:ImageButton({ name = but_effect:Name(), w=20, h=20, offset = {0,0}, texture = "guis/textures/icons/delete",
				on_callback = function(item)
					TIM.tempEffects.effects[item.name]=nil
					TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("EffectsGroup"):GetItem(item.name):Destroy()
				end
			})
		end		
		TIM._rewardMenu:Enable()
	end
	
	
end

function TIM:CreateEffect(menu) --окошко редактирования эффекта
	TIM._effectFormMenu = menu
	local effectMenu = TIM._effectFormMenu:Menu({name = "effectMenu", position = "Center", align_items = "grid", w = 400, visible = true, auto_height = true, auto_foreground = true, always_highlighting = true,
		reach_ignore_focus = false,
		scrollbar = false,
		max_height = 500,
		size = 20,
		offset = 8,
		accent_color = BeardLib.Options:GetValue("MenuColor"),
		background_color = Color('58008f'),
		background_alpha = 0.99,
		align_method = "grid",
		border_color = Color('ffffff'),
		border_visible=true,
	})
	effectMenu:Divider({name = "Name", label="effect", size = 18, text_align = "center", text = TIM._effectsForms[TIM._effectFormMenu:Param("name")].Name})
	effectMenu:Divider({name = "Description",  label="effect", size = 18, text_align = "left", text = TIM._effectsForms[TIM._effectFormMenu:Param("name")].Description})
	--effectMenu
	if TIM._effectFormMenu:Param("effect_exists")==true then
		for k, v in pairs(TIM._effectsForms[TIM._effectFormMenu:Param("name")].TIM or {}) do
			local val = v.defaultValue
			if v.Type=="NumberBox" then
				local fun = function(item)
					if item.maxValue and item.value >item.maxValue then
						item:SetValue(item.maxValue)
					end
					if item.minValue and item.value <item.minValue then
						item:SetValue(item.minValue)
					end
				end
				--[[
				if v.LessThanZero==false then
					if v.maxValue ~= nil then
						fun = function(item)
							if item.value < 0 then
								item:SetValue(0)
							end
							if item.value> item.maxValue then
								item:SetValue(item.maxValue)
							end
						end
					else
						fun = function(item)
							if item.value < 0 then
								item:SetValue(0)
							end						
						end
					end
				else
					if v.maxValue ~= nil then
						fun = function(item)
							if math.abs(item.value)> math.abs(item.maxValue) then
								item:SetValue(item.maxValue*TIM:sign(item.value))
							end
						end
					else
						fun = function(item)
					
						end
					end
				end
				]]
				
				if TIM.tempEffects.effects[TIM._effectsForms[TIM._effectFormMenu:Param("name")].id][k] then
					val = TIM.tempEffects.effects[TIM._effectsForms[TIM._effectFormMenu:Param("name")].id][k].Value
				end
				effectMenu:NumberBox({name = k, text = v.Name, floats=v.floats and v.floats or 0, value=val,maxValue=v.maxValue, minValue=v.minValue, on_callback = fun, focus_mode=true})	------------------подгрузка значений			
			elseif v.Type=="ComboBox" then
				--local val = v.defaultValue
				if TIM.tempEffects.effects[TIM._effectsForms[TIM._effectFormMenu:Param("name")].id][k] then
					val = TIM.tempEffects.effects[TIM._effectsForms[TIM._effectFormMenu:Param("name")].id][k].Value
				end
				effectMenu:ComboBox({
					name = k,
					text = v.Name,
					items = v.Items,
					value = val,
					free_typing = false
				})
			elseif v.Type=="Toggle" then
				--local val = v.defaultValue
				if TIM.tempEffects.effects[TIM._effectsForms[TIM._effectFormMenu:Param("name")].id][k] then
					val = TIM.tempEffects.effects[TIM._effectsForms[TIM._effectFormMenu:Param("name")].id][k].Value
				end
				effectMenu:Toggle({
					name = k,
					text = v.Name,
					value = val,
					on_callback = function(item)
						item.value=item.value and item.value or false
					end
				})
			elseif v.Type == "Slider" then
				if TIM.tempEffects.effects[TIM._effectsForms[TIM._effectFormMenu:Param("name")].id][k] then
					val = TIM.tempEffects.effects[TIM._effectsForms[TIM._effectFormMenu:Param("name")].id][k].Value
				end
				effectMenu:Slider({
					name = k,
					text = v.Name,
					value = val,
					min = v.minValue,
					max = v.maxValue,
					step = v.step,
					floats=v.floats,
					on_callback=function(item)
						local mod, f = math.modf(item.value)
				
						item:SetValue(f>=0.5 and mod+1 or mod)
					end
				})
			elseif v.Type == "TextBox" then
				if TIM.tempEffects.effects[TIM._effectsForms[TIM._effectFormMenu:Param("name")].id][k] then
					val = TIM.tempEffects.effects[TIM._effectsForms[TIM._effectFormMenu:Param("name")].id][k].Value
				end
				
				effectMenu:TextBox({
					name = k,
					text = v.Name,
					value = val
				})
			end
			
		end
	else
		for k, v in pairs(TIM._effectsForms[TIM._effectFormMenu:Param("name")].TIM or {}) do
			if v.Type=="NumberBox" then
				local fun = function(item)
					if item.maxValue and item.value >item.maxValue then
						item:SetValue(item.maxValue)
					end
					if item.minValue and item.value <item.minValue then
						item:SetValue(item.minValue)
					end
				end
				--[[
				if v.LessThanZero==false then
					if v.maxValue ~= nil then
						fun = function(item)
							if item.value < 0 then
								item:SetValue(0)
							end
							if item.value> item.maxValue then
								item:SetValue(item.maxValue)
							end
						end
					else
						fun = function(item)
							if item.value < 0 then
								item:SetValue(0)
							end						
						end
					end
				else
					if v.maxValue ~= nil then
						fun = function(item)
							if math.abs(item.value)> math.abs(item.maxValue) then
								item:SetValue(item.maxValue*TIM:sign(item.value))
							end
						end
					else
						fun = function(item)
					
						end
					end
				end
				]]
				effectMenu:NumberBox({name = k, text = v.Name, floats=v.floats and v.floats or 0, value=v.defaultValue, maxValue=v.maxValue,minValue=v.minValue, on_callback = fun, focus_mode=true})								
			elseif v.Type=="ComboBox" then
				effectMenu:ComboBox({
					name = k,
					text = v.Name,
					items = v.Items,
					value = v.defaultValue,
					free_typing = false,
					on_callback = function(item)
						--item:SetValue(item:Value())
						--managers.mission._fading_debug_output:script().log(tostring(item:SelectedItem().name),  Color.green)
						--managers.mission._fading_debug_output:script().log(tostring(item:Value()),  Color.green)
						--log("Selected item", tostring(item:SelectedItem()))
						--log("Index", tostring(item:Value()))
					end
				})
			elseif v.Type=="Toggle" then
				effectMenu:Toggle({
					name = k,
					text = v.Name,
					value = v.defaultValue,
					on_callback = function(item)
						item.value=item.value and item.value or false
					end
				})
			elseif v.Type == "Slider" then
				
				effectMenu:Slider({
					name = k,
					text = v.Name,
					value = v.defaultValue,
					min = v.minValue,
					max = v.maxValue,
					step = v.step,
					floats=v.floats,
					on_callback=function(item)
						local mod, f = math.modf(item.value)
				
						item:SetValue(f>=0.5 and mod+1 or mod)
					end
				})
			elseif v.Type == "TextBox" then
				
				
				effectMenu:TextBox({
					name = k,
					text = v.Name,
					value = v.defaultValue
				})
			end
			
		end
	end
	
	effectMenu:Button({ name = "OK", text = "OK", w = 140,
		on_callback = function(item)
			TIM.tempEffects.effects[TIM._effectsForms[TIM._effectFormMenu:Param("name")].id]={}
			for k, v in pairs(TIM._effectFormMenu:GetMenu("effectMenu"):Items() or {}) do
				if v:Value() then
					TIM.tempEffects.effects[TIM._effectsForms[TIM._effectFormMenu:Param("name")].id][v:Name()]={}
					if TIM._effectFormMenu:GetMenu("effectMenu"):GetItemWithType(v:Name(), "ComboBox") then
						TIM.tempEffects.effects[TIM._effectsForms[TIM._effectFormMenu:Param("name")].id][v:Name()].SelectedItem=v:SelectedItem().name
					end
					TIM.tempEffects.effects[TIM._effectsForms[TIM._effectFormMenu:Param("name")].id][v:Name()].Value=v:Value()
				end
			end
			if TIM._effectFormMenu:Param("effect_exists")==false then
				local but = TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("EffectsGroup"):Button({name = TIM._effectsForms[TIM._effectFormMenu:Param("name")].id, size = 18, text_align = "left", text = TIM._effectsForms[TIM._effectFormMenu:Param("name")].Name,
					on_callback = function(item1)
						MenuUI:new({
							name = item1.name,
							background_blur=true,
							layer = 1100,
							create_items = callback(self, self, "CreateEffect"),
							effect_exists=true
						})
						TIM._effectFormMenu:Enable()
					end	})
				but:ImageButton({
					name = but:Name(),
					w=20,
					h=20,
					offset = {0,0},
					texture = "guis/textures/icons/delete",
					on_callback = function(item)
						TIM.tempEffects.effects[item.name]=nil
						TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("EffectsGroup"):GetItem(item.name):Destroy()
					end
				})
			end
			TIM._effectFormMenu:Destroy()
		end})
	effectMenu:Button({ name = "Cancel", text = "Cancel", w = 140,
		on_callback = function(item)		
			TIM._effectFormMenu:Destroy()
		end})
end

function TIM:CreateExtraSettings(menu) --окошко дополнительный настроек
	TIM._extraSettingsMenu = menu
	local _dialogExtraSettings = TIM._extraSettingsMenu:Menu({
		name = "_dialog_Extra_Settings",
		position = "Center",
		align_items = "grid",
		w = 400,
		h = 300,
		visible = true,
		auto_height = true,
		auto_foreground = true,
		always_highlighting = true,
		reach_ignore_focus = false,
		scrollbar = false,
		max_height = 500,
		size = 20,
		offset = 8,
		accent_color = BeardLib.Options:GetValue("MenuColor"),
		background_color = Color('3d005e'),
		background_alpha = 0.99,
		align_method = "grid",
		border_color = Color('ffffff'),
		border_visible=true,
	})
	--[[
	_dialogExtraSettings:ImageButton({
        name = "CloseButton",
		w=20,
		h=20,
		offset = {370,6},
        texture = "guis/textures/icons/close",
        on_callback = function(item)
            TIM._extraSettingsMenu:Disable()
        end
    })]]
	_dialogExtraSettings:Divider({name = "Name", size = 24,  text_align = "center", text = "EXTRA SETTINGS"})
	_dialogExtraSettings:NumberBox({
		name = "rewardCooldown",
		text = "Reward cooldown",
		floats=0,
		value = TIM._settings.rewardCooldown,
		focus_mode=true,
		on_callback = function(item)
			item:SetValue((item.value < 0) and 0 or item.value)
		end	
	})
	--_dialogExtraSettings:Toggle({name = "enableTacticMode", text = "Enable rewards only on heist", value = TIM._settings.enableTacticMode, on_callback=function(item)
	--	TIM._settings.enableTacticMode=item.value
	--end})
	_dialogExtraSettings:Button({ name = "enableAllRewards", text = "Enable all rewards", 
		on_callback = function(item)
			local rewStr=""
			for k, v in pairs(TIM._settings.TwitchRewards or {}) do
				rewStr=rewStr..k.."|"
				TIM._settings.TwitchRewards[k].enabled=true
			end
			TIM.library.enableListRewards(rewStr, true)
			TIM:save_settings()
			--TIM._extraSettingsMenu:Disable()
		end})
	_dialogExtraSettings:Button({ name = "disableAllRewards", text = "Disable all rewards", 
		on_callback = function(item)
			local rewStr=""
			for k, v in pairs(TIM._settings.TwitchRewards or {}) do
				rewStr=rewStr..k.."|"
				TIM._settings.TwitchRewards[k].enabled=false
			end
			TIM.library.enableListRewards(rewStr, false)
			TIM:save_settings()
			--TIM._extraSettingsMenu:Disable()
		end})
	_dialogExtraSettings:Button({ name = "OK", text = "OK", w = 140,
		on_callback = function(item)
			TIM._settings.rewardCooldown = TIM._extraSettingsMenu:GetItem("_dialog_Extra_Settings"):GetItem("rewardCooldown"):Value()
			TIM:save_settings()
			TIM._extraSettingsMenu:Disable()
		end})
	_dialogExtraSettings:Button({ name = "Cancel", text = "Cancel", w = 140,
		on_callback = function(item)		
			TIM._extraSettingsMenu:Disable()
		end})

end

function TIM:CreateListOfEffects(menu) --список всех эффектов
	TIM._listEffectsMenu=menu
	local _dialogListEffects = TIM._listEffectsMenu:Menu({
		name = "_dialog_List_Effects",
		position = "Center",
		align_items = "grid",
		w = 400,
		h = 500,
		visible = true,
		auto_height = false,
		auto_foreground = true,
		always_highlighting = true,
		reach_ignore_focus = false,
		scrollbar = false,
		max_height = 500,
		size = 20,
		offset = 8,
		accent_color = BeardLib.Options:GetValue("MenuColor"),
		background_color = Color('000000'),
		background_alpha = 0.99,
		align_method = "grid",
		border_color = Color('ffffff'),
		border_visible=true,
	})
	
	_dialogListEffects:ImageButton({
        name = "CloseButton",
		w=20,
		h=20,
		offset = {10,6},
        texture = "guis/textures/icons/close",
        on_callback = function(item)
            TIM._listEffectsMenu:Disable()
        end
    })
	local _dialogList = _dialogListEffects:NoteBook({
		text="List of effects",
		text_align = "center",
		name = "_dialog_List_Effects",
		position = "Center",
		align_items = "grid",
		w = 400,
		visible = true,
		auto_height = false,
		auto_foreground = true,
		always_highlighting = true,
		reach_ignore_focus = false,
		scrollbar = true,
		h = 500,
		size = 20,
		offset = 8,
		
		accent_color = BeardLib.Options:GetValue("MenuColor"),
		background_color = Color('000000'),
		background_alpha = 0.99,
		align_method = "grid",
		border_color = Color('ffffff'),
		border_visible=true,
	})
	--_dialogList:AddPage("test")
	--_dialogList:AddPage("test2")
	local pages = {}
	local numbers = 1
	--[[
	local _dialogList = _dialogListEffects:Menu({
		name = "_dialog_List_Effects",
		position = "Center",
		align_items = "grid",
		w = 300,
		visible = true,
		auto_height = false,
		auto_foreground = true,
		always_highlighting = true,
		reach_ignore_focus = false,
		scrollbar = true,
		h = 500,
		size = 20,
		offset = 8,
		
		accent_color = BeardLib.Options:GetValue("MenuColor"),
		background_color = Color('000000'),
		background_alpha = 0.99,
		align_method = "grid",
		border_color = Color('ffffff'),
		border_visible=true,
	})
	]]
	for k, v in pairs(TIM._effectsForms or {}) do
		if pages[TIM._effectsForms[k].Category] == nil then
			_dialogList:AddPage(TIM._effectsForms[k].Category)
			pages[TIM._effectsForms[k].Category]=numbers
			numbers=numbers+1
		end
		
		local item = _dialogList:Button({
			name = TIM._effectsForms[k].id,
			text = TIM._effectsForms[k].Name,
			on_callback = function(item)
				if TIM._rewardMenu:GetItem("_dialog_reward"):GetItem("EffectsGroup"):GetItem(item.name) == nil then
					TIM._listEffectsMenu:Disable()
					MenuUI:new({
						name = item.name,
						background_blur=true,
						layer = 1100,
						create_items = callback(self, self, "CreateEffect"),
						effect_exists=false
					})
					TIM._effectFormMenu:Enable()
				end
			end
		})
		_dialogList:AddToPage(item, pages[TIM._effectsForms[k].Category])
	end
end

function TIM:ShowMainMenu(menu, opened)
	if opened then
	
		
		if managers.player:player_unit() then
			game_state_machine:current_state():set_controller_enabled(false)
		end
		--[[
		local pann = TIM._holder:GetItem("2ndMenu")
		pann:GetItem("startBotOnStart"):SetValue(TIM._settings.startBotOnStart)
		pann:GetItem("twitch_nickname"):SetValue(TIM._settings.Nickname)
		TIM._holder:GetItem("ActivateChat"):SetValue(TIM._settings.enableChat)
		TIM._holder:GetItem("Rewards"):SetValue(TIM._settings.enableChannelPoints)
		]]
    else
		game_state_machine:current_state():set_controller_enabled(true)
        TIM._menu:disable()
    end
end
