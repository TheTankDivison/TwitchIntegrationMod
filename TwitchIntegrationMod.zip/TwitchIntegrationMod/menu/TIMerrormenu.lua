function TIM:MainMenuInit()
	
	MenuUI:new({
		offset = 6,
		layer = 1000,
		toggle_clbk = callback(self, self, "ShowMainMenu"),
		toggle_key = TIM.Options:GetValue("TWToggleKey"),
		create_items = callback(self, self, "CreateMainMenu"),
		use_default_close_key = true,
		background_blur=true		
	})	
		
end

function TIM:ShowMainMenu(menu, opened)
	if opened then
	
		
		if managers.player:player_unit() then
			game_state_machine:current_state():set_controller_enabled(false)
		end
		--[[
		local pann = TIM._holder:GetItem("2ndMenu")
		pann:GetItem("startBotOnStart"):SetValue(TIM._settings.startBotOnStart)
		pann:GetItem("twitch_nickname"):SetValue(TIM._settings.Nickname)
		TIM._holder:GetItem("ActivateChat"):SetValue(TIM._settings.enableChat)
		TIM._holder:GetItem("Rewards"):SetValue(TIM._settings.enableChannelPoints)
		]]
    else
		game_state_machine:current_state():set_controller_enabled(true)
        TIM._menu:disable()
    end
end

function TIM:CreateMainMenu(menu) --главное боковое меню
    TIM._menu = menu
    local accent = Color(1, 1, 1)
    TIM._holder = TIM._menu:DivGroup({
        name = "Twitch Integration Mod",
        w = 400,
        auto_height = false,
        size = 20,
		--position="Top",
        background_visible = true,
        border_bottom = true,
        border_center_as_title = true,
        border_position_below_title = true,
        private = {text_align = "center"},
        border_lock_height = true,
        accent_color = accent,
        border_width = 200,
        background_color = Color('3d005e'),
		background_alpha = 0.7,
		align_method = "grid"
    })
	
	TIM._dialog = TIM._menu:Menu({
        name = "dialog",
        position = "Center",
        align_items = "grid",
        w = 320,
        visible = false,
        auto_height = true,
        auto_foreground = true,
        always_highlighting = true,
        reach_ignore_focus = true,
        scrollbar = false,
        max_height = 700,
        size = 20,
        offset = 8,
        accent_color = BeardLib.Options:GetValue("MenuColor"),
        background_color = Color('3d005e'),
		background_alpha = 0.7,
		align_method = "grid"
    })
	
	TIM._dialog:Divider({ name = "Divider", text_align = "center", text = TIM.loc.Warning })
	TIM._dialog:Divider({ name = "Divider", text = TIM.loc.OAUTH_Warning_text })
	TIM._dialog:Button({ name = "Yes", text = TIM.loc.Yes, text_align = "center", w=150,
		on_callback = function(item)
			TIM._dialog:SetVisible(false)
			TIM._dialog_OAUTH:SetVisible(true)
		end })
	TIM._dialog:Button({ name = "NO", text = TIM.loc.No, text_align = "center", w=150,
		on_callback = function(item)
			TIM._dialog:SetVisible(false)
		end })
	
	TIM._dialog_OAUTH = TIM._menu:Menu({
        name = "dialog_OAUTH",
        position = "Center",
        align_items = "grid",
        w = 400,
        visible = false,
        auto_height = true,
        auto_foreground = true,
        always_highlighting = true,
        reach_ignore_focus = true,
        scrollbar = false,
        max_height = 700,
        size = 20,
        offset = 8,
        accent_color = BeardLib.Options:GetValue("MenuColor"),
        background_color = Color('3d005e'),
		background_alpha = 0.7,
		align_method = "grid"
    })
	
	TIM._dialog_OAUTH:Divider({ name = "Divider", text_align = "center", text = TIM.loc.OAUTH_code })
	TIM._dialog_OAUTH:TextBox({ name = "dialog_OAUTH_text",  text = TIM.loc.Your_OAUTH_code, w=400, value = TIM._settings.OAUTH, focus_mode=true })
	TIM._dialog_OAUTH:Button({ name = "Yes", text = TIM.loc.Enter, text_align = "center", w=190,
		on_callback = function(item)
			TIM._settings.OAUTH = TIM._dialog_OAUTH:GetItem("dialog_OAUTH_text"):Value()
			if TIM._settings.Nickname ~= "" then
				TIM._settings.UserID = TIM.library.prepareAPI(TIM._settings.Nickname, TIM._settings.OAUTH, TIM._settings.enableChat, TIM._settings.enableChannelPoints)
			end
			TIM._dialog_OAUTH:SetVisible(false)
		end })
	TIM._dialog_OAUTH:Button({ name = "NO", text = TIM.loc.Cancel, text_align = "center", w=190,
		on_callback = function(item)
			TIM._dialog_OAUTH:SetVisible(false)
		end })
		
	TIM:MainMenuContainer()
	
end

function TIM:MainMenuContainer()
	TIM._holder:ClearItems()
	TIM._holder:ImageButton({
        name = "CloseButton",
		w=20,
		h=20,
		offset = {370,5},
        texture = "guis/textures/icons/close",
        on_callback = function(item)
            TIM._menu:Disable()
        end
    })
	TIM._holder:Divider({ name = "Divider", text = TIM.loc.TwitchBotDLL_is_missing, size=25, background_color = Color('FF0000') })
end
