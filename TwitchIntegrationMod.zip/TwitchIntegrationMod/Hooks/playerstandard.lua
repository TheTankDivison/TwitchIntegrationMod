function PlayerStandard:ChangeWeaponNow(data)
	local t =  Application:time()
	if type(data) == "table" and type(data.wep_data) == "table" and (type(data.wep_data.blueprint) == "table" or tweak_data.weapon.factory[data.wep_data.factory_id].default_blueprint) then
		local _f_p = tweak_data.weapon.factory[data.wep_data.factory_id]
		if not managers.dyn_resource:is_resource_ready(Idstring("unit"), Idstring(_f_p.unit), managers.dyn_resource.DYN_RESOURCES_PACKAGE) then
			managers.dyn_resource:load(Idstring("unit"), Idstring(_f_p.unit), managers.dyn_resource.DYN_RESOURCES_PACKAGE, callback(self, self, "ChangeWeaponNow", data))
		else
			self._change_weapon_pressed_expire_t = t + 1.66
			self:_start_action_unequip_weapon(t, data)
			managers.player:send_message(Message.OnSwitchWeapon)
		end
	end
end

Hooks:PreHook(PlayerStandard, "_update_equip_weapon_timers", "F_"..Idstring("_update_equip_weapon_timers_TIM"):key(), function(self, t, input)
	if self._change_weapon_data and self._change_weapon_data.bool then
		self._change_weapon_data.bool=nil
		local wep_data = self._change_weapon_data.wep_data
		if wep_data and wep_data.factory_id and tweak_data.weapon.factory[wep_data.factory_id] then
			self._ext_inventory:add_unit_by_factory_name(wep_data.factory_id, true, false, wep_data.blueprint or tweak_data.weapon.factory[wep_data.factory_id].default_blueprint, wep_data.cosmetics, wep_data.texture_switches)
			if self._equipped_unit and alive(self._equipped_unit) then
				self:set_animation_weapon_hold(nil)
				local speed_multiplier = 1
				local tweak_data = self._equipped_unit:base():weapon_tweak_data()
				self._equip_weapon_expire_t = t + (tweak_data.timers.equip or 0.7) / speed_multiplier
				self._ext_camera:play_redirect(self:get_animation("equip"), speed_multiplier)
				managers.upgrades:setup_current_weapon()
			end
		end
		self._unequip_weapon_expire_t = nil
		self._equip_weapon_expire_t = nil
		return
	end
end)
Hooks:PostHook(PlayerStandard, "init", "F_"..Idstring("init_TIM"):key(), function(self)
	if managers.blackmarket and Global.blackmarket_manager and type(Global.blackmarket_manager.crafted_items) == "table" then
	--	self._gumgame_times = 1
		TIM._all_available_weps = {}
		for _selection_wanted, cat in pairs({"secondaries", "primaries"}) do
			for _, wep in pairs(managers.blackmarket:get_crafted_category(cat)) do
				wep.selection_wanted = _selection_wanted
				table.insert(TIM._all_available_weps, wep)
			end
		end
	end
end)