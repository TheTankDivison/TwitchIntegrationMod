function CoreEnvironmentControllerManager:get_downed_value()
	return self._downed_value
end