TIM:Post(GroupAIStateBesiege, "_upd_assault_task", function()
	--managers.mission._fading_debug_output:script().log(tostring(managers.groupai:state():whisper_mode() == false),  Color.green)
	if managers.groupai:state():whisper_mode() == false and TIM.policeCallOneTime == true then 

		TIM.policeCallOneTime=false
		if TIM._settings.gameMode==1 then 
			TIM:CheckTactic()
		elseif TIM._settings.gameMode==3 and TIM.chatAIrewardsCreated==nil then
			TIM:CheckTacticChatAI()
		end
		--managers.mission._fading_debug_output:script().log(tostring(false),  Color.green)
	end
end)