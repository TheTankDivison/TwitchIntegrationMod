if TIM._settings.enableOtherHUDs==true and _G.WolfHUD then
	TIM:Post(HUDChat, "init", function(self)
		local output_panel = self._panel:child("output_panel")
		local text = output_panel:text({
			halign = "left", name = "line_words", vertical = "top", hvertical = "top",
			wrap = true, visible = true, blend_mode = "normal", word_wrap = true, y =0,
			layer = 0, text = "\t", font = tweak_data.menu.pd2_small_font, font_size = HUDChat.LINE_HEIGHT * 0.95,
			x = 0, color = Color(0,1,1,1)
		})
		local _, _, w, h = text:text_rect()
		HUDChat.tabW = w
		HUDChat.tabH = h
		output_panel:remove(text)
		HUDChat.line_height=HUDChat.LINE_HEIGHT
	end)
	
	function HUDChat:receive_message_twitch(name, message, color, badges, emotes, isReward)
		local output_panel = self._panel:child("output_panel")
		local scroll_bar_bg = output_panel and output_panel:child("scroll_bar_bg")
		local x_offset = HUDChat.COLORED_BG and 2 or 0

				
		local len = utf8.len(name) + 1
		local x = 0
		local icon_bitmap = nil
		local line_panel = output_panel:panel({ name = "line_panel", layer = 0, alpha=1,
			w = output_panel:w() - scroll_bar_bg:w(), h = HUDChat.line_height, x =0, y =0
		})
		if HUDChat.SCROLLBAR_ALIGN == 1 then
			line_panel:set_left(scroll_bar_bg:w())
		end
		local msg_panel_bg
		if HUDChat.COLORED_BG then
			msg_panel_bg = line_panel:rect({
				name = "bg",
				alpha = 0.25,
				color = color,
				w = line_panel:w(),
				layer = -1
			})
		else
			msg_panel_bg = line_panel:bitmap({
				name = "bg",
				alpha = 1,
				color = Color.white / 3,
				texture = "guis/textures/pd2/hud_tabs",
				texture_rect = {84, 0, 44, 32},
				layer = -1
			})
		end
		local emote_bitmap=nil
		
		
		local icon_tw = line_panel:bitmap({ y = 0, name ="twitch_icon", texture = "guis/textures/icons/TwitchIcon",
			w = HUDChat.tabW*2, h = HUDChat.tabW*2, blend_mode = "add",
			x = x, color = Color(1,1,1)
		})
		x = icon_tw:right()
		icon_tw:set_center_y(HUDChat.line_height/2)
		local badges_count = 0
		x, badges_count = TIM:Check_badges(HUDChat, badges, line_panel, x)
		
		if emotes and emotes ~= "" then
			
			TIM:Check_emotes(emotes)
			local mess_arr = message:split(" ")
			local temp_x = x
			local temp_y = 0
			name = name..":"
			local name_arr = name:split(" ")
			
			for i = 1, #name_arr do
				local line_words = line_panel:text({
					halign = "left", name = "line_words"..i, vertical = "top", hvertical = "top",
					wrap = true, visible = true, align = "left", blend_mode = "normal", word_wrap = true, y = temp_y,
					layer = 0, text = name_arr[i].." ", font = tweak_data.menu.pd2_small_font,
					font_size = HUDChat.LINE_HEIGHT * 0.95,
					x = temp_x, color = color
				})
				local _, _, w, h = line_words:text_rect()
				line_words:set_w(w)
				line_words:set_h(h)
				local temp_x_t = line_words:right()
				if line_words:number_of_lines()>1 or temp_x_t > line_panel:w()-5 then
					local line_height = HUDChat.line_height
				
					line_panel:set_h(line_panel:h()+line_height)
					temp_x=0
					temp_y=temp_y+line_height
					line_panel:remove(line_panel:child("line_words"..i))	
					line_words = line_panel:text({ halign = "left",	 name = "line_words", vertical = "top",
						hvertical = "top", wrap = true, visible = true, align = "left", blend_mode = "normal",
						word_wrap = true, y = temp_y, layer = 0, text = name_arr[i].." ",
						font = tweak_data.menu.pd2_small_font,
						font_size = HUDChat.LINE_HEIGHT * 0.95,
						x = 0, color = color
					}) 
				end 
				_, _, w, h = line_words:text_rect()
				line_words:set_w(w)
				line_words:set_h(h)
				
				temp_x=line_words:right() 
			end 
			
			for i = 1, #mess_arr do
				if TIM.ChatEmotes[mess_arr[i]] then
					local name_of_emote = TIM.ChatEmotes[mess_arr[i]]
					
					emote_bitmap = line_panel:bitmap({ name = tostring(number_of_line), visible = true,
						texture = name_of_emote, layer = 0, alpha=1, color = Color(1, 1, 1), w = HUDChat.tabH,
		
						h = HUDChat.tabH, blend_mode = "add", x =temp_x, y =temp_y
					})
					temp_x = emote_bitmap:right()
					if temp_x > output_panel:w() - scroll_bar_bg:w()-5 - (tweak_data.menu.pd2_small_font_size) then
						local line_height = HUDChat.line_height
						temp_x=0
						temp_y=temp_y+line_height
						emote_bitmap:set_y(temp_y)
						emote_bitmap:set_x(temp_x)
						temp_x = emote_bitmap:right()
						line_panel:set_h(line_panel:h()+line_height)
					end
					emote_bitmap=nil
				else
					local line_words = line_panel:text({ halign = "left", name = "line_words2"..i, vertical = "top", hvertical = "top",
						wrap = true, visible = true, align = "left",blend_mode = "normal", word_wrap = true, y = temp_y,
						layer = 0, text = mess_arr[i].." ", font = tweak_data.menu.pd2_small_font,
						font_size = HUDChat.LINE_HEIGHT * 0.95, x = temp_x, color = Color.white
					})
					local _, _, w, h = line_words:text_rect()
					line_words:set_w(w)
					line_words:set_h(h)
					local temp_x_t = line_words:right()
					if line_words:number_of_lines()>1 or temp_x_t > output_panel:w() - scroll_bar_bg:w()-5 then
						local line_height = HUDChat.line_height
						temp_x=0
						line_panel:set_h(line_panel:h()+line_height)
						temp_y=temp_y+line_height
						line_panel:remove(line_panel:child("line_words2"..i))	
						line_words = line_panel:text({ halign = "left",	 name = "line_words", vertical = "top", hvertical = "top",
							wrap = true, visible = true, align = "left", blend_mode = "normal", word_wrap = true,
							y = temp_y, layer = 0, text = mess_arr[i].." ", font = tweak_data.menu.pd2_small_font,
							font_size = HUDChat.LINE_HEIGHT * 0.95, x = 0, color = Color.white
						})
						
					end
					line_words:set_w(line_panel:w() - line_words:left())
					_, _, w, h = line_words:text_rect()
					line_words:set_w(w)
					line_words:set_h(h)
					temp_x=line_words:right()
				end
			end
		
		else
			local text_mes =""
			local tab=""
			local line = line_panel:text({ halign = "left", vertical = "top", hvertical = "top", wrap = true,
				align = "left", blend_mode = "normal", word_wrap = true, y = 0, layer = 0, 
				font = tweak_data.menu.pd2_small_font,
				font_size = HUDChat.LINE_HEIGHT * 0.95, x = 0, color = color
			})
			for i=1, badges_count, 1 do
				tab=tab.."\t\t"
			end
			if isReward==true then
				text_mes="\t\t"..tab..name .. message
				line:set_text(text_mes)
				local total_len = utf8.len(line:text())
				local endTab= 2 + badges_count*2
				line:set_range_color(0, endTab, Color(0,1,1,1))
				line:set_range_color(endTab, total_len, color)
			else
				text_mes="\t\t"..tab..name .. ": " .. message
				line:set_text(text_mes)
				local total_len = utf8.len(line:text())
				local endTab= 2 + badges_count*2
				line:set_range_color(0, endTab, Color(0,1,1,1))
				line:set_range_color(endTab, len+endTab, color)
				line:set_range_color(len+endTab, total_len, Color.white)
			end
			
			
			
		
			local _, _, w, h = line:text_rect()
			
			line:set_h(h)
			line_panel:set_h(h)
				
		end
		local no_lines = line_panel:h()/HUDChat.line_height
		self._total_message_lines = self._total_message_lines + no_lines
		msg_panel_bg:set_h(HUDChat.LINE_HEIGHT * no_lines)
		if not HUDChat.COLORED_BG then
			
			msg_panel_bg:set_width(x_offset + line_panel:w() + 2)
		end
		table.insert(self._messages, { panel = line_panel, name = name, lines = no_lines })

		self:_layout_output_panel()
		if not self._focus then
			local output_panel = self._panel:child("output_panel")
			output_panel:stop()
			output_panel:animate(callback(self, self, "_animate_show_component"), output_panel:alpha())
			output_panel:animate(callback(self, self, "_animate_fade_output"))
		end
	end

elseif TIM._settings.enableOtherHUDs==true and VoidUI then
	TIM:Post(HUDChat, "init", function(self)
		local output_panel = self._panel:child("output_panel")
		local text = output_panel:text({
			halign = "left", name = "line_words", vertical = "top", hvertical = "top",
			wrap = true, visible = true, blend_mode = "normal", word_wrap = true, y =0,
			layer = 0, text = "\t", font = "fonts/font_medium_mf",
			font_size = tweak_data.menu.pd2_small_font_size * 0.85 * self._scale,
			x = 0, color = Color(0,1,1,1)
		})
		local _, _, w, h = text:text_rect()
		HUDChat.tabW = w
		HUDChat.tabH = h
		output_panel:remove(text)
	end)
	if VoidUI.options.enable_chat then
		function HUDChat:receive_message_twitch(name, message, color, badges, emotes, isReward)
			local output_panel = self._panel:child("output_panel")
			local scrollbar = self._panel:child("scrollbar_panel"):child("scrollbar")
			local full_message = name .. ": " .. message
			local line
			if VoidUI.options.chattime > 1 and managers.game_play_central then
				local time = VoidUI.options.chattime == 2 and "[".. os.date('!%X', managers.game_play_central:get_heist_timer()) .. "] " or "[".. os.date('%X') .. "] "
				full_message =  time .. full_message
				name = time .. name
			end
			local len = utf8.len(name) + 1
			local x = 0
			local icon_bitmap = nil
			local line_panel = output_panel:panel({ name = "line_panel", layer = 0, alpha=1,
				w = self._output_width, h = HUDChat.line_height* self._scale, x =0, y =0
			})
			local emote_bitmap=nil
			
			
			local icon_tw = line_panel:bitmap({ y = 0, name ="twitch_icon", texture = "guis/textures/icons/TwitchIcon",
				w = HUDChat.tabW*2, h = HUDChat.tabW*2, blend_mode = "add",
				x = x, color = Color(1,1,1)
			})
			x = icon_tw:right()
			icon_tw:set_center_y(HUDChat.line_height/2)
			local badges_count = 0
			x, badges_count = TIM:Check_badges(HUDChat, badges, line_panel, x)
			
			if emotes and emotes ~= "" then
				
				TIM:Check_emotes(emotes)
				local mess_arr = message:split(" ")
				local temp_x = x
				local temp_y = 0
				name = name..":"
				local name_arr = name:split(" ")
				
				for i = 1, #name_arr do
					local line_words = line_panel:text({
						halign = "left", name = "line_words"..i, vertical = "top", hvertical = "top",
						wrap = true, visible = true, align = "left", blend_mode = "normal", word_wrap = true, y = temp_y,
						layer = 0, text = name_arr[i].." ", font = "fonts/font_medium_mf",
						font_size = tweak_data.menu.pd2_small_font_size * 0.85 * self._scale,
						x = temp_x, color = color
					})
					local _, _, w, h = line_words:text_rect()
					line_words:set_w(w)
					line_words:set_h(h)
					local temp_x_t = line_words:right()
					if line_words:number_of_lines()>1 or temp_x_t > line_panel:w()-5 then
						local line_height = HUDChat.line_height* self._scale
					
						line_panel:set_h(line_panel:h()+line_height)
						temp_x=0
						temp_y=temp_y+line_height
						line_panel:remove(line_panel:child("line_words"..i))	
						line_words = line_panel:text({ halign = "left",	 name = "line_words", vertical = "top",
							hvertical = "top", wrap = true, visible = true, align = "left", blend_mode = "normal",
							word_wrap = true, y = temp_y, layer = 0, text = name_arr[i].." ",
							font = "fonts/font_medium_mf",
							font_size = tweak_data.menu.pd2_small_font_size * 0.85 * self._scale,
							x = 0, color = color
						}) 
					end 
					_, _, w, h = line_words:text_rect()
					line_words:set_w(w)
					line_words:set_h(h)
					
					temp_x=line_words:right() 
				end 
				
				for i = 1, #mess_arr do
					if TIM.ChatEmotes[mess_arr[i]] then
						local name_of_emote = TIM.ChatEmotes[mess_arr[i]]
						
						emote_bitmap = line_panel:bitmap({ name = tostring(number_of_line), visible = true,
							texture = name_of_emote, layer = 0, alpha=1, color = Color(1, 1, 1), w = HUDChat.line_height,
							h = HUDChat.line_height, blend_mode = "add", x =temp_x, y =temp_y
						})
						temp_x = emote_bitmap:right()
						if temp_x > self._output_width-5 - (tweak_data.menu.pd2_small_font_size) then
							local line_height = HUDChat.line_height* self._scale
							temp_x=0
							temp_y=temp_y+line_height
							emote_bitmap:set_y(temp_y)
							emote_bitmap:set_x(temp_x)
							temp_x = emote_bitmap:right()
							line_panel:set_h(line_panel:h()+line_height)
						end
						emote_bitmap=nil
					else
						local line_words = line_panel:text({ halign = "left", name = "line_words2"..i, vertical = "top", hvertical = "top",
							wrap = true, visible = true, align = "left",blend_mode = "normal", word_wrap = true, y = temp_y,
							layer = 0, text = mess_arr[i].." ", font = "fonts/font_medium_mf",
							font_size = tweak_data.menu.pd2_small_font_size * 0.85 * self._scale, x = temp_x, color = Color.white
						})
						local _, _, w, h = line_words:text_rect()
						line_words:set_w(w)
						line_words:set_h(h)
						local temp_x_t = line_words:right()
						if line_words:number_of_lines()>1 or temp_x_t > self._output_width-5 then
							local line_height = HUDChat.line_height* self._scale
							temp_x=0
							line_panel:set_h(line_panel:h()+line_height)
							temp_y=temp_y+line_height
							line_panel:remove(line_panel:child("line_words2"..i))	
							line_words = line_panel:text({ halign = "left",	 name = "line_words", vertical = "top", hvertical = "top",
								wrap = true, visible = true, align = "left", blend_mode = "normal", word_wrap = true,
								y = temp_y, layer = 0, text = mess_arr[i].." ", font = "fonts/font_medium_mf",
								font_size = tweak_data.menu.pd2_small_font_size * 0.85 * self._scale, x = 0, color = Color.white
							})
							
						end
						line_words:set_w(line_panel:w() - line_words:left())
						_, _, w, h = line_words:text_rect()
						line_words:set_w(w)
						line_words:set_h(h)
						temp_x=line_words:right()
					end
				end
			
			else
				local text_mes =""
				local tab=""
				line = line_panel:text({ halign = "left", vertical = "top", hvertical = "top", wrap = true,
					align = "left", blend_mode = "normal", word_wrap = true, y = 0, layer = 0, 
					font = "fonts/font_medium_mf",
					font_size = tweak_data.menu.pd2_small_font_size * 0.85 * self._scale, x = 0, color = color
				})
				for i=1, badges_count, 1 do
					tab=tab.."\t\t"
				end
				if isReward==true then
					text_mes="\t\t"..tab..name .. message
					line:set_text(text_mes)
					local total_len = utf8.len(line:text())
					local endTab= 2 + badges_count*2
					line:set_range_color(0, endTab, Color(0,1,1,1))
					line:set_range_color(endTab, total_len, color)
				else
					text_mes="\t\t"..tab..name .. ": " .. message
					line:set_text(text_mes)
					local total_len = utf8.len(line:text())
					local endTab= 2 + badges_count*2
					line:set_range_color(0, endTab, Color(0,1,1,1))
					line:set_range_color(endTab, len+endTab, color)
					line:set_range_color(len+endTab, total_len, Color.white)
				end
				
				
				
			
				local _, _, w, h = line:text_rect()
				
				line:set_h(h* self._scale)
				line_panel:set_h(h* self._scale)
					
			end
			self._lines_count = self._lines_count + line_panel:h()/HUDChat.line_height
			line_panel:set_bottom(self._input_panel:bottom())
			table.insert(self._lines, {
				panel = line_panel,
				message = message,
				name = name
			})
			--line:set_kern(line:kern())
			self:_layout_custom_output_panel()
			--line_panel:animate(callback(self, self, "_animate_message_received_twitch"))
			if not self._focus then
				local output_panel = self._panel:child("output_panel")
				output_panel:stop()
				output_panel:animate(callback(self, self, "_animate_show_component"), output_panel:alpha())
				output_panel:animate(callback(self, self, "_animate_fade_output"))
			end
		end

	end
elseif TIM._settings.enableOtherHUDs==true and MUIMenu then
	--go to hudmanagerpd2.lua hook file
elseif TIM._settings.enableOtherHUDs==true and _G.HMH then
	TIM:Post(HUDChat, "init", function(self)
		local output_panel = self._panel:child("output_panel")
		local text = output_panel:text({
			halign = "left", name = "line_words", vertical = "top", hvertical = "top",
			wrap = true, visible = true, blend_mode = "normal", word_wrap = true, y =0,
			layer = 0, text = "\t", font = tweak_data.menu.pd2_small_font, font_size = HUDChat.LINE_HEIGHT * 0.95,
			x = 0, color = Color(0,1,1,1)
		})
		local _, _, w, h = text:text_rect()
		HUDChat.tabW = w
		HUDChat.tabH = h
		output_panel:remove(text)
		HUDChat.line_height = HUDChat.LINE_HEIGHT
	end)
	function HUDChat:receive_message_twitch(name, message, color, badges, emotes, isReward)
		local output_panel = self._panel:child("output_panel")
		local scroll_bar_bg = output_panel and output_panel:child("scroll_bar_bg")
		local x_offset = HUDChat.COLORED_BG and 2 or 0

				
		local len = utf8.len(name) + 1
		local x = 0
		local icon_bitmap = nil
		local line_panel = output_panel:panel({ name = "line_panel", layer = 0, alpha=1,
			w = output_panel:w() - scroll_bar_bg:w(), h = HUDChat.line_height, x =0, y =0
		})
		if HUDChat.SCROLLBAR_ALIGN == 1 then
			line_panel:set_left(scroll_bar_bg:w())
		end
		local msg_panel_bg
		if HUDChat.COLORED_BG then
			msg_panel_bg = line_panel:rect({
				name = "bg",
				alpha = 0.25,
				color = color,
				w = line_panel:w(),
				layer = -1
			})
		else
			msg_panel_bg = line_panel:bitmap({
				name = "bg",
				alpha = 1,
				color = Color.white / 3,
				texture = "guis/textures/pd2/hud_tabs",
				texture_rect = {84, 0, 44, 32},
				layer = -1
			})
		end
		local emote_bitmap=nil
		
		
		local icon_tw = line_panel:bitmap({ y = 0, name ="twitch_icon", texture = "guis/textures/icons/TwitchIcon",
			w = HUDChat.tabW*2, h = HUDChat.tabW*2, blend_mode = "add",
			x = x, color = Color(1,1,1)
		})
		x = icon_tw:right()
		icon_tw:set_center_y(HUDChat.line_height/2)
		local badges_count = 0
		x, badges_count = TIM:Check_badges(HUDChat, badges, line_panel, x)
		
		if emotes and emotes ~= "" then
			
			TIM:Check_emotes(emotes)
			local mess_arr = message:split(" ")
			local temp_x = x
			local temp_y = 0
			name = name..":"
			local name_arr = name:split(" ")
			
			for i = 1, #name_arr do
				local line_words = line_panel:text({
					halign = "left", name = "line_words"..i, vertical = "top", hvertical = "top",
					wrap = true, visible = true, align = "left", blend_mode = "normal", word_wrap = true, y = temp_y,
					layer = 0, text = name_arr[i].." ", font = tweak_data.menu.pd2_small_font,
					font_size = HUDChat.LINE_HEIGHT * 0.95,
					x = temp_x, color = color
				})
				local _, _, w, h = line_words:text_rect()
				line_words:set_w(w)
				line_words:set_h(h)
				local temp_x_t = line_words:right()
				if line_words:number_of_lines()>1 or temp_x_t > line_panel:w()-5 then
					local line_height = HUDChat.line_height
				
					line_panel:set_h(line_panel:h()+line_height)
					temp_x=0
					temp_y=temp_y+line_height
					line_panel:remove(line_panel:child("line_words"..i))	
					line_words = line_panel:text({ halign = "left",	 name = "line_words", vertical = "top",
						hvertical = "top", wrap = true, visible = true, align = "left", blend_mode = "normal",
						word_wrap = true, y = temp_y, layer = 0, text = name_arr[i].." ",
						font = tweak_data.menu.pd2_small_font,
						font_size = HUDChat.LINE_HEIGHT * 0.95,
						x = 0, color = color
					}) 
				end 
				_, _, w, h = line_words:text_rect()
				line_words:set_w(w)
				line_words:set_h(h)
				
				temp_x=line_words:right() 
			end 
			
			for i = 1, #mess_arr do
				if TIM.ChatEmotes[mess_arr[i]] then
					local name_of_emote = TIM.ChatEmotes[mess_arr[i]]
					
					emote_bitmap = line_panel:bitmap({ name = tostring(number_of_line), visible = true,
						texture = name_of_emote, layer = 0, alpha=1, color = Color(1, 1, 1), w = HUDChat.tabH,
						h = HUDChat.tabH, blend_mode = "add", x =temp_x, y =temp_y
					})
					temp_x = emote_bitmap:right()
					if temp_x > output_panel:w() - scroll_bar_bg:w()-5 - (tweak_data.menu.pd2_small_font_size) then
						local line_height = HUDChat.line_height
						temp_x=0
						temp_y=temp_y+line_height
						emote_bitmap:set_y(temp_y)
						emote_bitmap:set_x(temp_x)
						temp_x = emote_bitmap:right()
						line_panel:set_h(line_panel:h()+line_height)
					end
					emote_bitmap=nil
				else
					local line_words = line_panel:text({ halign = "left", name = "line_words2"..i, vertical = "top", hvertical = "top",
						wrap = true, visible = true, align = "left",blend_mode = "normal", word_wrap = true, y = temp_y,
						layer = 0, text = mess_arr[i].." ", font = tweak_data.menu.pd2_small_font,
						font_size = HUDChat.LINE_HEIGHT * 0.95, x = temp_x, color = Color.white
					})
					local _, _, w, h = line_words:text_rect()
					line_words:set_w(w)
					line_words:set_h(h)
					local temp_x_t = line_words:right()
					if line_words:number_of_lines()>1 or temp_x_t > output_panel:w() - scroll_bar_bg:w()-5 then
						local line_height = HUDChat.line_height
						temp_x=0
						line_panel:set_h(line_panel:h()+line_height)
						temp_y=temp_y+line_height
						line_panel:remove(line_panel:child("line_words2"..i))	
						line_words = line_panel:text({ halign = "left",	 name = "line_words", vertical = "top", hvertical = "top",
							wrap = true, visible = true, align = "left", blend_mode = "normal", word_wrap = true,
							y = temp_y, layer = 0, text = mess_arr[i].." ", font = tweak_data.menu.pd2_small_font,
							font_size = HUDChat.LINE_HEIGHT * 0.95, x = 0, color = Color.white
						})
						
					end
					line_words:set_w(line_panel:w() - line_words:left())
					_, _, w, h = line_words:text_rect()
					line_words:set_w(w)
					line_words:set_h(h)
					temp_x=line_words:right()
				end
			end
		
		else
			local text_mes =""
			local tab=""
			local line = line_panel:text({ halign = "left", vertical = "top", hvertical = "top", wrap = true,
				align = "left", blend_mode = "normal", word_wrap = true, y = 0, layer = 0, 
				font = tweak_data.menu.pd2_small_font,
				font_size = HUDChat.LINE_HEIGHT * 0.95, x = 0, color = color
			})
			for i=1, badges_count, 1 do
				tab=tab.."\t\t"
			end
			if isReward==true then
				text_mes="\t\t"..tab..name .. message
				line:set_text(text_mes)
				local total_len = utf8.len(line:text())
				local endTab= 2 + badges_count*2
				line:set_range_color(0, endTab, Color(0,1,1,1))
				line:set_range_color(endTab, total_len, color)
			else
				text_mes="\t\t"..tab..name .. ": " .. message
				line:set_text(text_mes)
				local total_len = utf8.len(line:text())
				local endTab= 2 + badges_count*2
				line:set_range_color(0, endTab, Color(0,1,1,1))
				line:set_range_color(endTab, len+endTab, color)
				line:set_range_color(len+endTab, total_len, Color.white)
			end
			
			
			
		
			local _, _, w, h = line:text_rect()
			
			line:set_h(h)
			line_panel:set_h(h)
				
		end
		local no_lines = line_panel:h()/HUDChat.line_height
		self._total_message_lines = self._total_message_lines + no_lines
		msg_panel_bg:set_h(HUDChat.LINE_HEIGHT * no_lines)
		if not HUDChat.COLORED_BG then
			
			msg_panel_bg:set_width(x_offset + line_panel:w() + 2)
		end
		table.insert(self._messages, { panel = line_panel, name = name, lines = no_lines })

		self:_layout_output_panel()
		if not self._focus then
			local output_panel = self._panel:child("output_panel")
			output_panel:stop()
			output_panel:animate(callback(self, self, "_animate_show_component"), output_panel:alpha())
			output_panel:animate(callback(self, self, "_animate_fade_output"))
		end
	end

elseif TIM._settings.enableOtherHUDs==true and Holo then 

elseif TIM._settings.enableOtherHUDs==true and _G.VHUDPlus then

else
	TIM:Post(HUDChat, "init", function(self)
		local output_panel = self._panel:child("output_panel")
		local text = output_panel:text({
			halign = "left", name = "line_words", vertical = "top", hvertical = "top",
			wrap = true, visible = true, blend_mode = "normal", word_wrap = true, y =0,
			layer = 0, text = "\t", font = tweak_data.menu.pd2_small_font, font_size = tweak_data.menu.pd2_small_font_size,
			x = 0, color = Color(0,1,1,1)
		})
		local _, _, w, h = text:text_rect()
		HUDChat.tabW = w
		HUDChat.tabH = h
		output_panel:remove(text)
	end)
	
	function HUDChat:receive_message_twitch(name, message, color, badges, emotes, isReward)----------------------------------сообщение твич false
		local output_panel = self._panel:child("output_panel")
		local len = utf8.len(name) + 1
		local x = 0
		local icon_bitmap = nil
		local line_panel = output_panel:panel({ name = "line_panel", layer = 0, alpha=1,
			w = 300, h = HUDChat.line_height, x =0, y =0
		})
		local emote_bitmap=nil
		
		
		local icon_tw = line_panel:bitmap({ y = 0, name ="twitch_icon", texture = "guis/textures/icons/TwitchIcon",
			w = HUDChat.tabW*2, h = HUDChat.tabW*2, blend_mode = "add",
			x = x, color = Color(1,1,1)
		})
		x = icon_tw:right()
		icon_tw:set_center_y(HUDChat.line_height/2)
		local badges_count = 0
		x, badges_count = TIM:Check_badges(HUDChat, badges, line_panel, x)
		
		if emotes and emotes ~= "" then
			
			TIM:Check_emotes(emotes)
			local mess_arr = message:split(" ")
			local temp_x = x
			local temp_y = 0
			name = name..":"
			local name_arr = name:split(" ")
			
			for i = 1, #name_arr do
				local line_words = line_panel:text({
					halign = "left", name = "line_words"..i, vertical = "top", hvertical = "top",
					wrap = true, visible = true, align = "left", blend_mode = "normal", word_wrap = true, y = temp_y,
					layer = 0, text = name_arr[i].." ", font = tweak_data.menu.pd2_small_font, font_size = tweak_data.menu.pd2_small_font_size,
					x = temp_x, color = color
				})
				local _, _, w, h = line_words:text_rect()
				line_words:set_w(w)
				line_words:set_h(h)
				local temp_x_t = line_words:right()
				if line_words:number_of_lines()>1 or temp_x_t > line_panel:w()-5 then
					local line_height = HUDChat.line_height
				
					line_panel:set_h(line_panel:h()+line_height)
					temp_x=0
					temp_y=temp_y+line_height
					line_panel:remove(line_panel:child("line_words"..i))	
					line_words = line_panel:text({ halign = "left",	 name = "line_words", vertical = "top",
						hvertical = "top", wrap = true, visible = true, align = "left", blend_mode = "normal",
						word_wrap = true, y = temp_y, layer = 0, text = name_arr[i].." ",
						font = tweak_data.menu.pd2_small_font, font_size = tweak_data.menu.pd2_small_font_size,
						x = 0, color = color
					}) 
				end 
				_, _, w, h = line_words:text_rect()
				line_words:set_w(w)
				line_words:set_h(h)
				
				temp_x=line_words:right() 
			end 
			
			for i = 1, #mess_arr do
				if TIM.ChatEmotes[mess_arr[i]] then
					local name_of_emote = TIM.ChatEmotes[mess_arr[i]]
					
					emote_bitmap = line_panel:bitmap({ name = tostring(number_of_line), visible = true,
						texture = name_of_emote, layer = 0, alpha=1, color = Color(1, 1, 1), w = tweak_data.menu.pd2_small_font_size,
						h = tweak_data.menu.pd2_small_font_size, blend_mode = "add", x =temp_x, y =temp_y
					})
					temp_x = emote_bitmap:right()
					if temp_x > 295 - (tweak_data.menu.pd2_small_font_size) then
						local line_height = HUDChat.line_height
						temp_x=0
						temp_y=temp_y+line_height
						emote_bitmap:set_y(temp_y)
						emote_bitmap:set_x(temp_x)
						temp_x = emote_bitmap:right()
						line_panel:set_h(line_panel:h()+line_height)
					end
					emote_bitmap=nil
				else
					local line_words = line_panel:text({ halign = "left", name = "line_words2"..i, vertical = "top", hvertical = "top",
						wrap = true, visible = true, align = "left",blend_mode = "normal", word_wrap = true, y = temp_y,
						layer = 0, text = mess_arr[i].." ", font = tweak_data.menu.pd2_small_font,
						font_size = tweak_data.menu.pd2_small_font_size, x = temp_x, color = Color.white
					})
					local _, _, w, h = line_words:text_rect()
					line_words:set_w(w)
					line_words:set_h(h)
					local temp_x_t = line_words:right()
					if line_words:number_of_lines()>1 or temp_x_t > 295 then
						local line_height = HUDChat.line_height
						temp_x=0
						line_panel:set_h(line_panel:h()+line_height)
						temp_y=temp_y+line_height
						line_panel:remove(line_panel:child("line_words2"..i))	
						line_words = line_panel:text({ halign = "left",	 name = "line_words", vertical = "top", hvertical = "top",
							wrap = true, visible = true, align = "left", blend_mode = "normal", word_wrap = true,
							y = temp_y, layer = 0, text = mess_arr[i].." ", font = tweak_data.menu.pd2_small_font,
							font_size = tweak_data.menu.pd2_small_font_size, x = 0, color = Color.white
						})
						
					end
					line_words:set_w(line_panel:w() - line_words:left())
					_, _, w, h = line_words:text_rect()
					line_words:set_w(w)
					line_words:set_h(h)
					temp_x=line_words:right()
				end
			end
		
		else
			local text_mes =""
			local tab=""
			local line = line_panel:text({ halign = "left", vertical = "top", hvertical = "top", wrap = true,
				align = "left", blend_mode = "normal", word_wrap = true, y = 0, layer = 0, 
				font = tweak_data.menu.pd2_small_font, font_size = tweak_data.menu.pd2_small_font_size, x = 0, color = color
			})
			for i=1, badges_count, 1 do
				tab=tab.."\t\t"
			end
			if isReward==true then
				text_mes="\t\t"..tab..name .. message
				line:set_text(text_mes)
				local total_len = utf8.len(line:text())
				local endTab= 2 + badges_count*2
				line:set_range_color(0, endTab, Color(0,1,1,1))
				line:set_range_color(endTab, total_len, color)
			else
				text_mes="\t\t"..tab..name .. ": " .. message
				line:set_text(text_mes)
				local total_len = utf8.len(line:text())
				local endTab= 2 + badges_count*2
				line:set_range_color(0, endTab, Color(0,1,1,1))
				line:set_range_color(endTab, len+endTab, color)
				line:set_range_color(len+endTab, total_len, Color.white)
			end
			
			
			
		
			local _, _, w, h = line:text_rect()
			
			line:set_h(h)
			line_panel:set_h(h)
				
		end
		
		table.insert(self._lines, line_panel)
		self:_layout_output_panel()

		if not self._focus then
			local output_panel = self._panel:child("output_panel")

			output_panel:stop()
			output_panel:animate(callback(self, self, "_animate_show_component"), output_panel:alpha())
			output_panel:animate(callback(self, self, "_animate_fade_output"))
		end


	end
	
	function HUDChat:receive_message(name, message, color, icon)
		local output_panel = self._panel:child("output_panel")
		local len = utf8.len(name) + 1
		local x = 0
		local icon_bitmap = nil
		local line_panel = output_panel:panel({
			name = "line_panel",			
			layer = 0,
			alpha=1,
			w = 300,
			h = HUDChat.line_height,
			x =0,
			y =0
		})
		local step = 0
		if icon then
			local icon_texture, icon_texture_rect = tweak_data.hud_icons:get_icon_data(icon)
			icon_bitmap = line_panel:bitmap({
				y = 1,
				texture = icon_texture,
				texture_rect = icon_texture_rect,
				color = color
			})
			x = icon_bitmap:right()
			step = icon_bitmap:w()
		end
		--sdf sdf sdf sd fsds sd fsd fs
		local line = line_panel:text({
			halign = "left",
			vertical = "top",
			hvertical = "top",
			wrap = true,
			align = "left",
			blend_mode = "normal",
			word_wrap = true,
			y = 0,
			layer = 0,
			text = name .. ": " .. message,
			font = tweak_data.menu.pd2_small_font,
			font_size = tweak_data.menu.pd2_small_font_size,
			x = x,
			w = 300-step,
			color = color
		})
		local total_len = utf8.len(line:text())
		
		line:set_range_color(0, len, color)
		line:set_range_color(len, total_len, Color.white)

		local _, _, w, h = line:text_rect()

		line:set_h(h)
		table.insert(self._lines, line_panel)
		line_panel:set_h(h)
		line:set_kern(line:kern())
		self:_layout_output_panel()

		if not self._focus then
			local output_panel = self._panel:child("output_panel")

			output_panel:stop()
			output_panel:animate(callback(self, self, "_animate_show_component"), output_panel:alpha())
			output_panel:animate(callback(self, self, "_animate_fade_output"))
		end
	end
	
	
	function HUDChat:_layout_output_panel()
		local lines=0
		local output_panel = self._panel:child("output_panel")
		
		for i = #self._lines, 1, -1 do
			local line = self._lines[i]
			line:set_w(output_panel:w() - line:x())
			lines = lines + line:h()/HUDChat.line_height
		end
		
		output_panel:set_h(HUDChat.line_height * math.min(10, lines))
		
		output_panel:set_bottom(self._input_panel:top())
		local y = 0
		for i = #self._lines, 1, -1 do
			local msg = self._lines[i]
			msg:set_bottom(output_panel:h() - y)
			y = y + msg:h()
		end
		if #self._lines>15 then
		
			local line = self._lines[1]
			output_panel:remove(output_panel:child(line:name()))	
			table.remove(self._lines, 1)
			
		end
	end
end
