function NPCRaycastWeaponBase:get_damage()
	return self._damage
end