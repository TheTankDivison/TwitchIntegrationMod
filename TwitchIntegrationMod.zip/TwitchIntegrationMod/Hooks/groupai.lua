TIM:Post(GroupAIStateBase, "on_police_called", function(called_reason) --ElementAiGlobalEvent:on_executed(instigator)
	if TIM.policeCallOneTime == true and TIM._settings.gameMode==1 then then
		TIM.policeCallOneTime=false
		TIM:CheckTactic()
		--managers.mission._fading_debug_output:script().log(tostring(false),  Color.green)
	elseif TIM.policeCallOneTime == true and TIM._settings.gameMode==3 and TIM.chatAIrewardsCreated==nil then
		TIM.policeCallOneTime=false
		TIM:CheckTacticChatAI()
	end
end)
