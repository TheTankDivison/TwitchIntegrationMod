
TIM:Post(BaseNetworkSession, "spawn_players", function(is_drop_in) --HUDBlackScreen:init(hud) lib\network\base function BaseNetworkSession:spawn_players(is_drop_in)
	--TIM:Reward_co_create()
	--managers.mission._fading_debug_output:script().log(tostring("whisper_mode"),  Color.green)
	if TIM._settings.gameMode==1 then 
		TIM:CheckTactic()
	elseif TIM._settings.gameMode==2 then
		TIM:StartDelayPolls()
	elseif TIM._settings.gameMode==3 then
		TIM:CheckTacticChatAI()
	end
	--TIM:Take_word_from_file()
	BeardLib:AddUpdater("CheckGameState", TIM.CheckGameState, false)
end)
