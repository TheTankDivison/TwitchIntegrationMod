--function GamePlayCentralManager:stop_the_game() function StatisticsManager:stop_session(data)
TIM:Post(StatisticsManager, "stop_session", function(data) --ElementAiGlobalEvent:on_executed(instigator)
	if TIM.ModActive==true then
		if TIM._settings.gameMode == 1 then
			TIM:EnableTacticReward(false, 3)
			TIM:EnableTacticReward(false, 2)
			TIM:EnableTacticReward(false, 1)
		elseif TIM._settings.gameMode==2 then 
			TIM:EndPoll()
		elseif TIM._settings.gameMode==3 then 
			TIM:DisableChatAI()
		end
		
		
	end
end)

TIM:Post(JobManager, "set_stage_success", function(success) --ElementAiGlobalEvent:on_executed(instigator)
	if TIM.ModActive==true then
		if TIM._settings.gameMode == 1 then
			TIM:EnableTacticReward(false, 3)
			TIM:EnableTacticReward(false, 2)
			TIM:EnableTacticReward(false, 1)
		elseif TIM._settings.gameMode==2 then 
			TIM:EndPoll()
		elseif TIM._settings.gameMode==3 then 
			TIM:DisableChatAI()
		end
		
		
	end
end)

TIM:Post(HUDManager, "show_endscreen_hud", function() --ElementAiGlobalEvent:on_executed(instigator)
	if TIM.ModActive==true then
		if TIM._settings.gameMode == 1 then
			TIM:EnableTacticReward(false, 3)
			TIM:EnableTacticReward(false, 2)
			TIM:EnableTacticReward(false, 1)
		elseif TIM._settings.gameMode==2 then 
			
			TIM:EndPoll()
		elseif TIM._settings.gameMode==3 then 
			TIM:DisableChatAI()
		end
		
		
	end
end)