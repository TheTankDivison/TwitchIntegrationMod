function CopDamage:set_health(gg)
	self._health = gg
end

function CopDamage:get_health()
	return self._health 
end