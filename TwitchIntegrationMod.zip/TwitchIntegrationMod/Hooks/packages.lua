if Global.load_level then
	if not PackageManager:loaded("levels/narratives/e_election_day/stage_3/world/world") then
		PackageManager:load("levels/narratives/e_election_day/stage_3/world/world")
	end
end

