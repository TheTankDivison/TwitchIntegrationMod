
TIM:Post(HUDManager, "show_endscreen_hud", function() --ElementAiGlobalEvent:on_executed(instigator)
	if TIM.ModActive==true then
		if TIM._settings.gameMode == 1 then
			TIM:EnableTacticReward(false, 3)
			TIM:EnableTacticReward(false, 2)
			TIM:EnableTacticReward(false, 1)
		elseif TIM._settings.gameMode==2 then 
			
			TIM:EndPoll()
		elseif TIM._settings.gameMode==3 then 
			TIM:DisableChatAI()
		end
	end
end)
local insert, remove = table.insert, table.remove;
local function pdoclass(class, path)
	if not MUIMenu:ClassEnabled(class) then
		return false;
	end
	return true
end
if TIM._settings.enableOtherHUDs==true and pdoclass("MUIChat", "lua/mui_chat.lua") then
	TIM:Post(MUIChat, "init", function(self)
		local output_panel = self._panel:child("output_panel")
		local text = output_panel:text({
			halign = "left", name = "line_words", vertical = "top", hvertical = "top",
			wrap = true, visible = true, blend_mode = "normal", word_wrap = true, y =0,
			layer = 0, text = "\t", font = self._font, font_size=self._muiSize / 10,
			x = 0, color = Color(0,1,1,1)
		})
		local _, _, w, h = text:text_rect()
		HUDChat.tabW = w
		HUDChat.tabH = h
		output_panel:remove(text)
	end)
	function MUIChat:receive_message_twitch(name, message, color, badges, emotes, isReward)
		local output_panel = self._panel:child("output_panel");
		local len = utf8.len(name) + 1
		local x = 0
		local icon_bitmap = nil
		local line_panel = output_panel:panel({ name = "line_panel", layer = 0, alpha=1,
			w = output_panel:w(), h = HUDChat.tabH, x =0, y =0
		})
		local emote_bitmap=nil
		
		
		local icon_tw = line_panel:bitmap({ y = 0, name ="twitch_icon", texture = "guis/textures/icons/TwitchIcon",
			w = HUDChat.tabW*2, h = HUDChat.tabW*2, blend_mode = "add",
			x = x, color = Color(1,1,1)
		})
		x = icon_tw:right()
		icon_tw:set_center_y(HUDChat.tabH/2)
		local badges_count = 0
		x, badges_count = TIM:Check_badges(HUDChat, badges, line_panel, x)
		
		if emotes and emotes ~= "" then
			
			TIM:Check_emotes(emotes)
			local mess_arr = message:split(" ")
			local temp_x = x
			local temp_y = 0
			name = name..":"
			local name_arr = name:split(" ")
			
			for i = 1, #name_arr do
				local line_words = line_panel:text({
					halign = "left", name = "line_words"..i, vertical = "top", hvertical = "top",
					wrap = true, visible = true, align = "left", blend_mode = "normal", word_wrap = true, y = temp_y,
					layer = 0, text = name_arr[i].." ", font = self._font, font_size=self._muiSize / 10,
					x = temp_x, color = color
				})
				local _, _, w, h = line_words:text_rect()
				line_words:set_w(w)
				line_words:set_h(h)
				local temp_x_t = line_words:right()
				if line_words:number_of_lines()>1 or temp_x_t > line_panel:w()-5 then
					local line_height = HUDChat.tabH
				
					line_panel:set_h(line_panel:h()+line_height)
					temp_x=0
					temp_y=temp_y+line_height
					line_panel:remove(line_panel:child("line_words"..i))	
					line_words = line_panel:text({ halign = "left",	 name = "line_words", vertical = "top",
						hvertical = "top", wrap = true, visible = true, align = "left", blend_mode = "normal",
						word_wrap = true, y = temp_y, layer = 0, text = name_arr[i].." ",
						font = self._font, font_size=self._muiSize / 10,
						x = 0, color = color
					}) 
				end 
				_, _, w, h = line_words:text_rect()
				line_words:set_w(w)
				line_words:set_h(h)
				
				temp_x=line_words:right() 
			end 
			
			for i = 1, #mess_arr do
				if TIM.ChatEmotes[mess_arr[i]] then
					local name_of_emote = TIM.ChatEmotes[mess_arr[i]]
					
					emote_bitmap = line_panel:bitmap({ name = tostring(number_of_line), visible = true,
						texture = name_of_emote, layer = 0, alpha=1, color = Color(1, 1, 1), w = HUDChat.tabH,
						h = HUDChat.tabH, blend_mode = "add", x =temp_x, y =temp_y
					})
					temp_x = emote_bitmap:right()
					if temp_x > self._output_panel:w()-5 - (tweak_data.menu.pd2_small_font_size) then
						local line_height = HUDChat.tabH
						temp_x=0
						temp_y=temp_y+line_height
						emote_bitmap:set_y(temp_y)
						emote_bitmap:set_x(temp_x)
						temp_x = emote_bitmap:right()
						line_panel:set_h(line_panel:h()+line_height)
					end
					emote_bitmap=nil
				else
					local line_words = line_panel:text({ halign = "left", name = "line_words2"..i, vertical = "top", hvertical = "top",
						wrap = true, visible = true, align = "left",blend_mode = "normal", word_wrap = true, y = temp_y,
						layer = 0, text = mess_arr[i].." ", font = tweak_data.menu.pd2_small_font,
						font_size = tweak_data.menu.pd2_small_font_size, x = temp_x, color = Color.white
					})
					local _, _, w, h = line_words:text_rect()
					line_words:set_w(w)
					line_words:set_h(h)
					local temp_x_t = line_words:right() 
					if line_words:number_of_lines()>1 or temp_x_t > self._output_panel:w()-5 then
						local line_height = HUDChat.tabH
						temp_x=0
						line_panel:set_h(line_panel:h()+line_height)
						temp_y=temp_y+line_height
						line_panel:remove(line_panel:child("line_words2"..i))	
						line_words = line_panel:text({ halign = "left",	 name = "line_words", vertical = "top", hvertical = "top",
							wrap = true, visible = true, align = "left", blend_mode = "normal", word_wrap = true,
							y = temp_y, layer = 0, text = mess_arr[i].." ", font = tweak_data.menu.pd2_small_font,
							font_size = tweak_data.menu.pd2_small_font_size, x = 0, color = Color.white
						})
						
					end
					line_words:set_w(line_panel:w() - line_words:left())
					_, _, w, h = line_words:text_rect()
					line_words:set_w(w)
					line_words:set_h(h)
					temp_x=line_words:right()
				end
			end
		
		else
			local text_mes =""
			local tab=""
			local line = line_panel:text({ halign = "left", vertical = "top", hvertical = "top", wrap = true,
				align = "left", blend_mode = "normal", word_wrap = true, y = 0, layer = 0, 
				font = self._font, font_size=self._muiSize / 10, x = 0, color = color
			})
			for i=1, badges_count, 1 do
				tab=tab.."\t\t"
			end
			if isReward==true then
				text_mes="\t\t"..tab..name .. message
				line:set_text(text_mes)
				local total_len = utf8.len(line:text())
				local endTab= 2 + badges_count*2
				line:set_range_color(0, endTab, Color(0,1,1,1))
				line:set_range_color(endTab, total_len, color)
			else
				text_mes="\t\t"..tab..name .. ": " .. message
				line:set_text(text_mes)
				local total_len = utf8.len(line:text())
				local endTab= 2 + badges_count*2
				line:set_range_color(0, endTab, Color(0,1,1,1))
				line:set_range_color(endTab, len+endTab, color)
				line:set_range_color(len+endTab, total_len, Color.white)
			end
			
			
			
		
			local _, _, w, h = line:text_rect()
			
			line:set_h(h)
			line_panel:set_h(h)
				
		end
		insert(self._lines, {line=line_panel, twitch=true});
		self:resize_lines();
		if not self._focus then
			output_panel:stop();
			output_panel:animate(callback(self, self, "_animate_show_component"), output_panel:alpha());
			output_panel:animate(callback(self, self, "_animate_fade_output"));
		end
	end
	
	function MUIChat:receive_message(name, message, color, icon)
		local output_panel = self._panel:child("output_panel");
		local line = output_panel:text({
			text = name .. ": " .. message,
			font = self._font,
			wrap = true,
			word_wrap = true,
			layer = 0
		});
		local len = utf8.len(name) + 1;
		local total_len = utf8.len(line:text());
		line:set_range_color(0, len, color);
		line:set_range_color(len, total_len, Color.white);
		insert(self._lines, {line=line, twitch=false});
		self:resize_lines();
		if not self._focus then
			output_panel:stop();
			output_panel:animate(callback(self, self, "_animate_show_component"), output_panel:alpha());
			output_panel:animate(callback(self, self, "_animate_fade_output"));
		end
	end
	
	function MUIChat:resize_lines()
		local s10 = self._muiSize / 10;
		local rows = self._muiRows;
		local space = self._muiLSpacing;
		
		local lines = self._lines;
		local len = #lines;
		local out = self._output_panel;
		local width = out:w();
		
		local overflow = len - rows;
		local sibling = self._input_panel;
		
		for i = len, 1, -1 do
			local line = lines[i].line;
			if i < overflow then
				out:remove(line);
				remove(lines, i);
			else
				if lines[i].twitch==true then
					
					Figure2(line):rect_twitch(width):attach(sibling, 1, space);
				else
					Figure2(line):rect(s10, width):attach(sibling, 1, space);
				end
				sibling = line;
			end
		end
	end
	local Figure, Figures = {}, {};
	local object, host, objects = false, false, false;
	local relative, recursion = false, 0;

	local align = {
		function(od, pd, m) return 0 + m; end, -- 1: Top/Left
		function(od, pd, m) return (pd - od) / 2; end, -- 2: Center
		function(od, pd, m) return pd - od - m; end -- 3: Bottom/Right
	};

	--------
	-- Initiate a Figure call.
	-- @param obj The target object or array of objects.
	function _G.Figure2(obj)
		Figure:reset();
		if obj[1] then
			objects = obj;
			return Figures;
		end
		Figure:object(obj);
		return Figure;
	end

	--------
	-- Align object within container.
	-- @tparam number xp The X position.
	-- @tparam number yp The Y position, defaults to X position.
	-- @tparam number xm The X margin.
	-- @tparam number ym The Y margin, defaults to X margin.
	function Figure:align(xp, yp, xm, ym)
		yp = yp or xp;
		ym = ym or xm;
		
		local parent = host or object:parent();
		
		local x = align[xp](object:w(), parent:w(), xm or 0);
		local y = align[yp](object:h(), parent:h(), ym or 0);
		
		return self:move(x, y);
	end
	function Figure:rect_twitch(w, h)
		if w then object:set_w(w); end
		if h then object:set_h(h); end
		
		
		
		object:set_size(w, object:h());
		
		return self;
	end
	local attach = {
		function(o, a, m, j) return
			a:x() + align[j](o:w(), a:w(), 0),
			a:y() - o:h() - m;
		end,
		function(o, a, m, j) return
			a:right() + m,
			a:y() + align[j](o:h(), a:h(), 0);
		end,
		function(o, a, m, j) return
			a:x() + align[j](o:w(), a:w(), 0),
			a:bottom() + m;
		end,
		function(o, a, m, j) return
			a:x() - o:w() - m,
			a:y() + align[j](o:h(), a:h(), 0);
		end
	};

	--------
	-- Align object relative to sibling anchor.
	-- @param anchor The mounting point for repositioning.
	-- @tparam number p The position around the anchor, clockwise from top, defaults to 1.
	-- @tparam number m The margin between object and anchor, defaults to 0.
	-- @tparam number j The justification along the secondary axis, defaults to 1.
	function Figure:attach(anchor, p, m, j)
		if not anchor then return self:move(0, 0); end
		p = p or 1;
		m = m or 0;
		j = j or 1;
		
		local x, y = attach[p](object, anchor, m, j);
		
		return self:move(x, y);
	end

	--------
	-- Adapt object to fit children or specific child.
	-- @param apogee The child at the furthest distance from origin requiring adaptation, optional.
	function Figure:adapt(apogee)
		local w, h = -1, -1;
		if apogee then
			w = apogee:right();
			h = apogee:bottom();
		else
			local children = object:children();
			
			for i=1, #children do
				local ch = children[i];
				if ch:layer() ~= 51 then
					local r, b = ch:right(), ch:bottom();
					w = w > r and w or r;
					h = h > b and h or b;
				end
			end
		end
		
		return self:shape(w, h);
	end

	--------
	-- Place object as a faux-child of anchor or child of anchor and make all positioning relative to new position.
	-- Useful in cases where you either cannot alter the child structure or within an anchor that is not actually capable of children.
	-- @param anchor The anchor object, should be a sibling to figure object.
	-- @param ... Child names under anchor.
	function Figure:leech(anchor, ...)
		local names = {...};
		self:move(anchor:x(), anchor:y());
		
		for i=1, #names do
			anchor = anchor:child(names[i]);
			self:shift(anchor:x(), anchor:y());
		end
		
		host = anchor;
		relative = true;
		
		return self;
	end

	--------
	-- Toggle whether positioning is relative to current position.
	-- @tparam boolean b Defaults to true.
	function Figure:relate(b)
		relative = b ~= false;
		return self;
	end

	--------
	-- Set the recursion depth of loops.
	-- @tparam boolean|number r The recursion depth, defaults to 250.
	function Figure:recur(r)
		recursion = r or 250;
		return self;
	end

	--------
	-- Run user-defined function on all children.
	-- @tparam function func The function executed on all children, taking Figure, Parent and Sibling as parameters.
	-- @param ... Additional parameters for the child function.
	function Figure:progeny(func, ...)
		local parent = object;
		local sibling = nil;
		local children = parent:children();
		
		for i=1, #children do
			object = children[i];
			
			if object:layer() ~= 51 then
				func(self, parent, sibling, ...);
				sibling = object;
				if recursion > 0 and object.children then
					recursion = recursion - 1;
					self:progeny(func, ...);
					recursion = recursion + 1;
				end
			end
		end
		
		object = parent;
		return self;
	end

	--------
	-- Shape all children.
	-- @tparam number w The width, or recursion if boolean, defaults to parent width.
	-- @tparam number h The height, defaults to width or parent height.
	-- @tparam number f The font size, defaults to height.
	function Figure:spank(w, h, f)
		h = h or w or object:h();
		w = w or object:w();
		local function smack(fgr, p) fgr:shape(w, h, f); end
		return self:progeny(smack);
	end

	--------
	-- Move object to specific coordinates.
	-- @tparam number x X-axis, optional.
	-- @tparam number y Y-axis, optional.
	function Figure:move(x, y)
		if relative then return self:shift(x, y); end
		if x then object:set_x(x); end
		if y then object:set_y(y); end
		
		return self;
	end	

	--------
	-- Shift object from its current position by specified amount.
	-- Precede with absolute positioning.
	-- @tparam number x Amount shifted on X-axis, optional.
	-- @tparam number y Amount shifted on Y-axis, optional.
	function Figure:shift(x, y)
		if x then object:set_x(object:x() + x); end
		if y then object:set_y(object:y() + y); end
		
		return self;
	end

	--------
	-- Set the abscissa.
	-- @tparam number x X-axis.
	function Figure:abs(x)
		object:set_x(x);
		return self;
	end

	--------
	-- Set the ordinate.
	-- @tparam number y Y-axis.
	function Figure:ord(y)
		object:set_y(y);
		return self;
	end


	--------
	-- Set the basic shape of the object.
	-- @tparam number w The width.
	-- @tparam number h The height, defaults to width.
	-- @tparam number f The font size, defaults to height.
	function Figure:shape(w, h, f)
		h = h or w;
		if w then object:set_w(w); end
		if h then object:set_h(h); end
		
		if object.set_font_size then
			object:set_font_size(f or h or object:h());
		end
		
		return self;
	end

	--------
	-- Rectangulate size of the text object based on font size.
	-- @tparam number f The font size.
	-- @tparam number w The width override, defaults to text rectangle.
	-- @tparam number h The height override, defaults to text rectangle.
	function Figure:rect(f, w, h)
		if f then object:set_font_size(f); end
		if w then object:set_w(w); end
		if h then object:set_h(h); end

		
		local _, _, w_rect, h_rect = object:text_rect();
		object:set_size(w or w_rect, h or h_rect);
		
		return self;
	end

	--------
	-- Fill rest of space in axis of parent.
	-- Typically used for text elements of variable length.  
	-- @tparam number axis The axis to fill (1:x, 2:y).
	-- @see [MUIStats.resize](https://gitlab.com/Armithaig/pd2-mui/blob/master/MUI/lua/mui_stats.lua)
	function Figure:fill(axis)
		axis = axis or 1;

		local parent = host or object:parent();

		if axis == 1 then
			object:set_w(parent:world_x() + parent:w() - object:world_x());
		elseif axis == 2 then
			object:set_h(parent:world_y() + parent:h() - object:world_y());
		end
	end

	--------
	-- Restrict the object to an upper size limit.
	-- @tparam number w The max width the object may occupy.
	-- @tparam number h The max height the object may occupy.
	function Figure:cusp(w, h)
		if w and object:w() > w then object:set_w(w); end
		if h and object:h() > h then object:set_h(h); end

		return self;
	end

	--------
	-- Restrict the object to a lower size limit.
	-- @tparam number w The min width the object may occupy.
	-- @tparam number h The min height the object may occupy.
	function Figure:base(w, h)
		if w and object:w() < w then object:set_w(w); end
		if h and object:h() < h then object:set_h(h); end

		return self;
	end


	--------
	-- Shrink away to make space for the target if necessary.
	-- @param sibling The target panel to elude.
	-- @todo
	function Figure:elude(target)
		local x, y = object:world_x(), object:world_y();
		local sx, sy = sibling:world_x(), sibling:world_y();
		local w, h, sw, sh = object:size(), sibling:size();
	end

	--------
	-- Correct bitmap aspect ratio based on texture dimensions.
	-- @tparam number tw The texture width.
	-- @tparam number th The texture height.
	-- @tparam boolean force Force adjustment along a certain dimension.
	function Figure:aspect(tw, th, force)
		tw = tw or object:texture_width();
		th = th or object:texture_height();
		if force == 1 or tw > th then
			object:set_h(th / tw * object:w());
		elseif force == 2 or th > tw then
			object:set_w(tw / th * object:h());
		end
		
		return self;
	end

	--------
	-- Set the object colour.
	-- @param c The colour.
	function Figure:stain(c)
		object:set_color(c);
		return self;
	end

	--------
	-- Set the object rotation.
	-- @tparam number r The rotation.
	function Figure:cycle(r)
		object:set_rotation(r);
		return self;
	end

	local font_jump = {
		[Idstring("fonts/font_small_mf"):key()] = 0.01,
		[Idstring("fonts/font_medium_mf"):key()] = 0.05,
		[Idstring("fonts/font_medium_shadow_mf"):key()] = -0.04,
		[Idstring("fonts/font_large_mf"):key()] = 0.06
	};

	--------
	-- Lead the text object so it aligns with other block elements based on font.
	-- Do not adjust other elements based on the ordinate of a leaded text.
	function Figure:lead()
		if object.font then
			local font = object:font():key();
			local correct = font_jump[font];
			if correct then
				object:set_y(object:font_size() * correct);
			end
		end
		return self;
	end

	--------
	-- Set the visibility and/or alpha value of the object.
	-- @tparam boolean|number v The visibility, or alpha value if a number.
	-- @tparam number a The alpha value.
	function Figure:view(v, a)
		if type(v) == "number" then a = v;
		else object:set_visible(v); end
			
		if a then object:set_alpha(a); end
		return self;
	end

	--------
	-- Set and/or get the target object.
	-- You shouldn't need to use this except in very rare situations.
	-- @param obj The target object, optional.
	function Figure:object(obj)
		if obj then
			object = obj;
		end
		return object;
	end

	--------
	-- Restore chunk variables to their defaults.
	function Figure:reset()
		host = false;
		relative = false;
		recursion = 0;
		return self;
	end

	function Figure:get(p)
		return object[p];
	end

	-- Handle arrays of objects with identical adjustments.
	for k in pairs(Figure) do
		Figures[k] = function(self, ...)
			for i=1, #objects do
				Figure:object(objects[i]);
				Figure[k](Figure, ...);
			end
			return self;
		end
	end
end
