if Holo or _G.VHUDPlus then
	function ChatManager:_receive_message_twitch(channel_id, name, message, color, badges, emotes, isReward)
		if not self._receivers[channel_id] then
			return
		end

		for i, receiver in ipairs(self._receivers[channel_id]) do
			receiver:receive_message(name, message, color)
		end
	end
elseif TIM._settings.enableOtherHUDs==false then
	function ChatManager:_receive_message_twitch(channel_id, name, message, color, badges, emotes, isReward)
		if not self._receivers[channel_id] then
			return
		end

		for i, receiver in ipairs(self._receivers[channel_id]) do
			receiver:receive_message(name, message, color)
		end
	end
else
function ChatGui:receive_message_twitch(name, message, color, badges, emotes, isReward)
	local output_panel = self._panel:child("output_panel")
	local len = utf8.len(name) + 1
	local x = 0
	local icon_bitmap = nil
	local bool = false
	
	local mess_arr = message:split(" ")
	local line_panel = output_panel:panel({ name = "line_panel", layer = 0, alpha=1,
		w = self._input_panel:w(), h = ChatGui.line_height, x =0, y =0
	})
	local emote_bitmap=nil
	local mas = {1}
	
	local icon_tw = line_panel:bitmap({ y = 0, name ="twitch_icon", texture = "guis/textures/icons/TwitchIcon",
		w = ChatGui.line_height-5, h = ChatGui.line_height-5, blend_mode = "add",
		x = x, color = Color(1,1,1)
	})
	x = icon_tw:right()
	icon_tw:set_center_y(ChatGui.line_height/2)
	mas[#mas+1] = icon_tw
	
	x = TIM:Check_badges(ChatGui, badges, line_panel, x)
	
	local temp_x = x
	local temp_y = 0
	name = name..":"
	local name_arr = name:split(" ")
	
	for i = 1, #name_arr do
		local line_words = line_panel:text({
			halign = "left", name = "line_words"..i, vertical = "top", hvertical = "top",
			wrap = true, visible = true, align = "left", blend_mode = "normal", word_wrap = true, y = temp_y,
			layer = 0, text = name_arr[i].." ", font = tweak_data.menu.pd2_small_font, font_size = tweak_data.menu.pd2_small_font_size,
			x = temp_x, color = color
		})
		local _, _, w, h = line_words:text_rect()
		line_words:set_w(w)
		line_words:set_h(h)
		local temp_x_t = line_words:right()
		if line_words:number_of_lines()>1 or temp_x_t > self._input_panel:w() then
			local line_height = ChatGui.line_height
		
			line_panel:set_h(line_panel:h()+line_height)
			temp_x=0
			temp_y=temp_y+line_height
			line_panel:remove(line_panel:child("line_words"..i))	
			line_words = line_panel:text({ halign = "left",	 name = "line_words", vertical = "top",
				hvertical = "top", wrap = true, visible = true, align = "left", blend_mode = "normal",
				word_wrap = true, y = temp_y, layer = 0, text = name_arr[i].." ",
				font = tweak_data.menu.pd2_small_font, font_size = tweak_data.menu.pd2_small_font_size,
				x = 0, color = color
			}) 
		end 
		_, _, w, h = line_words:text_rect()
		line_words:set_w(w)
		line_words:set_h(h)
		
		temp_x=line_words:right() 
	end 
	if emotes then
		TIM:Check_emotes(emotes)
	end
	for i = 1, #mess_arr do
		if TIM.ChatEmotes[mess_arr[i]] then
			local name_of_emote = TIM.ChatEmotes[mess_arr[i]]
			
			emote_bitmap = line_panel:bitmap({ name = tostring(number_of_line), visible = true,
				texture = name_of_emote, layer = 0, alpha=1, color = Color(1, 1, 1), w = tweak_data.menu.pd2_small_font_size,
				h = tweak_data.menu.pd2_small_font_size, blend_mode = "add", x =temp_x, y =temp_y
			})
			temp_x = emote_bitmap:right()
			if temp_x > self._input_panel:w() - (tweak_data.menu.pd2_small_font_size) then
				local line_height = ChatGui.line_height
				temp_x=0
				temp_y=temp_y+line_height
				emote_bitmap:set_y(temp_y)
				emote_bitmap:set_x(temp_x)
				temp_x = emote_bitmap:right()
				line_panel:set_h(line_panel:h()+line_height)
			end
			emote_bitmap=nil
		else
			local line_words = line_panel:text({ halign = "left", name = "line_words2"..i, vertical = "top", hvertical = "top",
				wrap = true, visible = true, align = "left",blend_mode = "normal", word_wrap = true, y = temp_y,
				layer = 0, text = mess_arr[i].." ", font = tweak_data.menu.pd2_small_font,
				font_size = tweak_data.menu.pd2_small_font_size, x = temp_x, color = Color.white
			})
			local _, _, w, h = line_words:text_rect()
			line_words:set_w(w)
			line_words:set_h(h)
			local temp_x_t = line_words:right()
			if line_words:number_of_lines()>1 or temp_x_t > self._input_panel:w() then
				local line_height = ChatGui.line_height
				temp_x=0
				line_panel:set_h(line_panel:h()+line_height)
				temp_y=temp_y+line_height
				line_panel:remove(line_panel:child("line_words2"..i))	
				line_words = line_panel:text({ halign = "left",	 name = "line_words", vertical = "top", hvertical = "top",
					wrap = true, visible = true, align = "left", blend_mode = "normal", word_wrap = true,
					y = temp_y, layer = 0, text = mess_arr[i].." ", font = tweak_data.menu.pd2_small_font,
					font_size = tweak_data.menu.pd2_small_font_size, x = 0, color = Color.white
				})
				
			end
			line_words:set_w(line_panel:w() - line_words:left())
			_, _, w, h = line_words:text_rect()
			line_words:set_w(w)
			line_words:set_h(h)
			temp_x=line_words:right()
		end
	end
	local line_bg = line_panel:rect({
		hvertical = "top",
		halign = "left",
		layer = -1,
		color = Color.black:with_alpha(0.5)
	})
	line_bg:set_w(line_panel:w())
	line_bg:set_h(line_panel:h())
	table.insert(self._lines, line_panel)
	self:_layout_output_panel()
	
	if not self._focus then
		local output_panel = self._panel:child("output_panel")
	
		output_panel:stop()
		output_panel:animate(callback(self, self, "_animate_show_component"), output_panel:alpha())
		output_panel:animate(callback(self, self, "_animate_fade_output"))
	end
	
	
end

function ChatGui:_layout_output_panel(force_update_scroll_indicators)
	local lines=0
	local max_lines = self._max_lines
	local output_panel = self._panel:child("output_panel")
	local scroll_panel = output_panel:child("scroll_panel")
	local line_height = ChatGui.line_height
	
	for i = #self._lines, 1, -1 do
		local line = self._lines[i]
		line:set_w(output_panel:w() - line:x())
		lines = lines + line:h()/line_height
	end
	
	
	output_panel:set_h(line_height * math.min(10, lines))
	scroll_panel:set_h(line_height * math.min(10, lines))
	
	output_panel:set_bottom(self._input_panel:top())
	local scroll_at_bottom = scroll_panel:bottom() == output_panel:h()
	
	local y = 0
	for i = #self._lines, 1, -1 do
		local msg = self._lines[i]
		msg:set_bottom(output_panel:h() - y)
		y = y + msg:h()
	end
	
	output_panel:set_bottom(math.round(self._input_panel:top()))

	if lines <= max_lines or scroll_at_bottom then
		scroll_panel:set_bottom(output_panel:h())
	end

	self:set_scroll_indicators(force_update_scroll_indicators)
	
end

function ChatGui:receive_message(name, message, color, icon)
	local output_panel = self._panel:child("output_panel")
	local len = utf8.len(name) + 1
	local x = 0
	local icon_bitmap = nil
	local bool = false
	
	local mess_arr = message:split(" ")
	local line_panel = output_panel:panel({
		name = "line_panel",			
		layer = 0,
		alpha=1,
		w = self._input_panel:w(),
		h = ChatGui.line_height,
		x =0,
		y =0
	})
	if icon then
		local icon_texture, icon_texture_rect = tweak_data.hud_icons:get_icon_data(icon)
		icon_bitmap = line_panel:bitmap({
			y = 1,
			texture = icon_texture,
			texture_rect = icon_texture_rect,
			color = color
		})
		x = icon_bitmap:right()
	end
	
	local temp_x = x
	local temp_y = 0
	name = name..":"
	local name_arr = name:split(" ")
	
	for i = 1, #name_arr do
		local line_words = line_panel:text({
			halign = "left",	
			name = "line_words"..i,
			vertical = "top",
			hvertical = "top",
			wrap = true,
			visible = true,
			align = "left",
			blend_mode = "normal",
			word_wrap = true,
			y = temp_y,
			layer = 0,
			text = name_arr[i].." ",
			font = tweak_data.menu.pd2_small_font,
			font_size = tweak_data.menu.pd2_small_font_size,
			x = temp_x,
			color = color
		})
		local _, _, w, h = line_words:text_rect()
		line_words:set_w(w)
		line_words:set_h(h)
		local temp_x_t = line_words:right()
		if line_words:number_of_lines()>1 or temp_x_t > self._input_panel:w() then
			local line_height = ChatGui.line_height
		
			line_panel:set_h(line_panel:h()+line_height)
			temp_x=0
			temp_y=temp_y+line_height
			line_panel:remove(line_panel:child("line_words"..i))	
			line_words = line_panel:text({
				halign = "left",	
				name = "line_words",
				vertical = "top",
				hvertical = "top",
				wrap = true,
				visible = true,
				align = "left",
				blend_mode = "normal",
				word_wrap = true,
				y = temp_y,
				layer = 0,
				text = name_arr[i].." ",
				font = tweak_data.menu.pd2_small_font,
				font_size = tweak_data.menu.pd2_small_font_size,
				x = 0,
				color = color
			})
			
		end
		
		_, _, w, h = line_words:text_rect()
		line_words:set_w(w)
		line_words:set_h(h)
		
		temp_x=line_words:right()
		
	end
	
	for i = 1, #mess_arr do
		local line_words = line_panel:text({ halign = "left", name = "line_words2"..i, vertical = "top", hvertical = "top",
			wrap = true, visible = true, align = "left", blend_mode = "normal", word_wrap = true, y = temp_y, layer = 0,
			text = mess_arr[i].." ", font = tweak_data.menu.pd2_small_font, font_size = tweak_data.menu.pd2_small_font_size,
			x = temp_x, color = Color.white
		})
		local _, _, w, h = line_words:text_rect()
		line_words:set_w(w)
		line_words:set_h(h)
		local temp_x_t = line_words:right()
		if line_words:number_of_lines()>1 or temp_x_t > self._input_panel:w() then
			local line_height = ChatGui.line_height
			temp_x=0
			line_panel:set_h(line_panel:h()+line_height)
			temp_y=temp_y+line_height
			line_panel:remove(line_panel:child("line_words2"..i))
			line_words = line_panel:text({ halign = "left", name = "line_words", vertical = "top", hvertical = "top", wrap = true,
				visible = true, align = "left", blend_mode = "normal", word_wrap = true, y = temp_y, layer = 0, text = mess_arr[i].." ",
				font = tweak_data.menu.pd2_small_font, font_size = tweak_data.menu.pd2_small_font_size, x = 0, color = Color.white
			})
		end
		line_words:set_w(line_panel:w() - line_words:left())
		_, _, w, h = line_words:text_rect()
		line_words:set_w(w)
		line_words:set_h(h)
		temp_x=line_words:right()
		
		
	end
	local line_bg = line_panel:rect({
			hvertical = "top",
			halign = "left",
			layer = -1,
			color = Color.black:with_alpha(0.5)
		})
		line_bg:set_w(line_panel:w())
		line_bg:set_h(line_panel:h())
	table.insert(self._lines, line_panel)
	
	self:_layout_output_panel()
	
	if not self._focus then
		local output_panel = self._panel:child("output_panel")
	
		output_panel:stop()
		output_panel:animate(callback(self, self, "_animate_show_component"), output_panel:alpha())
		output_panel:animate(callback(self, self, "_animate_fade_output"))
	end
end
--[[
function ChatGui:_layout_output_panel(force_update_scroll_indicators)
	local output_panel = self._panel:child("output_panel")
	local scroll_panel = output_panel:child("scroll_panel")

	scroll_panel:set_w(self._output_width)
	output_panel:set_w(self._output_width)

	local line_height = ChatGui.line_height
	local max_lines = self._max_lines
	local lines = 0

	for i = #self._lines, 1, -1 do
		local line = self._lines[i][1]
		local line_bg = self._lines[i][2]
		local icon = self._lines[i][3]

		line:set_w(scroll_panel:w() - line:left())

		local _, _, w, h = line:text_rect()

		line:set_h(h)
		line_bg:set_w(w + line:left() + 2)
		line_bg:set_h(line_height * line:number_of_lines())

		lines = lines + line:number_of_lines()
	end

	local scroll_at_bottom = scroll_panel:bottom() == output_panel:h()

	output_panel:set_h(math.round(line_height * math.min(max_lines, lines)))
	scroll_panel:set_h(math.round(line_height * lines))

	local y = 0

	for i = #self._lines, 1, -1 do
		local line = self._lines[i][1]
		local line_bg = self._lines[i][2]
		local icon = self._lines[i][3]
		local _, _, w, h = line:text_rect()

		line:set_bottom(scroll_panel:h() - y)
		line_bg:set_bottom(line:bottom())
		
		if icon and icon ~= 1 then
			icon:set_left(icon:left())
			icon:set_top(line:top() + 1)
			line:set_left(icon:right())
		else
			line:set_left(line:left())
		end
		if #self._lines[i]>3 then
			for j=4, #self._lines[i], 1 do
				local Emote = self._lines[i][j]
				if Emote and Emote ~=1 then
					if tostring(Emote:name())=="twitch_icon" then
						Emote:set_top(line:top() + 2.5)
					else
				
						local n = tonumber(Emote:name())
						Emote:set_top(line:top() + (ChatGui.line_height-1)*(n-1))
					end
				end
			end
		end
		y = y + line_height * line:number_of_lines()
	end

	output_panel:set_bottom(math.round(self._input_panel:top()))

	if lines <= max_lines or scroll_at_bottom then
		scroll_panel:set_bottom(output_panel:h())
	end

	self:set_scroll_indicators(force_update_scroll_indicators)
end
]]
	function ChatManager:_receive_message_twitch(channel_id, name, message, color, badges, emotes, isReward)
		if not self._receivers[channel_id] then
			return
		end

		for i, receiver in ipairs(self._receivers[channel_id]) do
			receiver:receive_message_twitch(name, message, color, badges, emotes, isReward)
		end
	end

end
