﻿
TIM:Post(IngameWaitingForPlayersState, "start_game_intro", function(self)
	TIM:Game_setup()
	--TIM:Chat()
end)
--TIM:Post(ChatGui, "init", function(self)
	--TIM.LoadComplete=true
	--TIM:Chat()
--end)
--TIM:Post(HUDChat, "init", function(self)
	--TIM.LoadComplete=true
	--TIM:Chat()
--end)PlayerManager:on_enter_custody(_player, already_dead) IngameWaitingForRespawnState:at_exit()

TIM:Post(PlayerManager, "on_enter_custody", function(self)
	if TIM._settings.gameMode==1 then 
		TIM:EnableTacticReward(false, 3)
		TIM:EnableTacticReward(false, 2)
		TIM:EnableTacticReward(false, 1)
	elseif TIM._settings.gameMode==2 then 
		TIM:EndPoll()
	elseif TIM._settings.gameMode==3 then 
		TIM:deleteChatAIRewards()
	end
	--TIM:Take_word_from_file()
end)
TIM:Post(IngameWaitingForRespawnState, "at_exit", function(self)
	if TIM._settings.gameMode==1 then 
		TIM:CheckTactic()
	elseif TIM._settings.gameMode==2 then 
		TIM:StartPoll()
	elseif TIM._settings.gameMode==3 then 
		TIM:CheckTacticChatAI()
	end
	--TIM.library.endPoll()
	--TIM:Take_word_from_file()
end)
Hooks:Add("NetworkManagerOnPeerAdded", "NetworkManagerOnPeerAdded_TW", function(peer, peer_id)
	if TIM.BotChatActive == true or TIM.BotPointsActive == true then
		if Network:is_server() then
			
			DelayedCalls:Add("DelayedTWAnnounce" .. tostring(peer_id), 2, function()

				local message = "Hello! I have 'Twitch Integration Mod'. In this lobby my viewers can actually break my game. So be careful ;)"
				
				local peer2 = managers.network:session() and managers.network:session():peer(peer_id)
				if peer2 then
					peer2:send("send_chat_message", ChatManager.GAME, message)
				end
			end)
		end
	end
end)



