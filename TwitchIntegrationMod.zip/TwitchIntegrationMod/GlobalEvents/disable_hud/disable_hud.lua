
function TIM.PollFunctions.disable_hud()
	local startUpgrade=10
	local maximumUpgrade=60
	local nameOfFucn = "disable_hud"
	local funcBefore = function() 
		managers.hud:set_disabled()
	end
	local funcAfter = function()
		managers.hud:set_enabled()
	end
	
	TIM:BaseTimerEvent(nameOfFucn, funcBefore, funcAfter, startUpgrade, maximumUpgrade)	
end