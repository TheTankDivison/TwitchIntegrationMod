
function TIM.PollFunctions.invisible_enemies()
	local maximumUpgrade = 60
	local startUpgrade = 10
	local toAdd =(maximumUpgrade/TIM._settings.Maximum_upgrade_level) * (TIM.PollEffectsForms.invisible_enemies.Upgrade.Level-1)
	
	if TIM.PollFunctionsActiveTime.invisible_enemies and TIM.PollFunctionsActiveTime.invisible_enemies>0 then
		TIM.PollFunctionsActiveTime.invisible_enemies = TIM.PollFunctionsActiveTime.invisible_enemies + startUpgrade + toAdd
	else

		local lin1 = TIM:fon_function()
		lin1:animate(function(o)
			TIM.PollFunctionsActiveTime.invisible_enemies = startUpgrade + toAdd--TIM._settings.PollsDuration + TIM._settings.PollsCooldown
			while TIM.PollFunctionsActiveTime.invisible_enemies >0 do
				TIM.PollFunctionsActiveTime.invisible_enemies=TIM.PollFunctionsActiveTime.invisible_enemies-0.1
			
				if managers.enemy then
					for _, data in pairs(managers.enemy:all_enemies()) do
						if data.unit then
							data.unit:set_visible(false)
						end
					end
				end
				wait(0.1)
			end
			
			if managers.enemy then
				for _, data in pairs(managers.enemy:all_enemies()) do
					if data.unit then
						data.unit:set_visible(true)
					end
				end
			end
			
			
			
			lin1:parent():remove(lin1)
		end)
	end
end