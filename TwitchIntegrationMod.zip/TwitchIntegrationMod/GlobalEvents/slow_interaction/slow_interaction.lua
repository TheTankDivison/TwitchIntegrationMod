
function TIM.PollFunctions.slow_interaction()
	local maximumUpgrade = 10
	local startUpgrade = 2
	local toAdd = math.modf((maximumUpgrade/TIM._settings.Maximum_upgrade_level) * (TIM.PollEffectsForms.slow_interaction.Upgrade.Level-1))
	function BaseInteractionExt:_timer_value()
		return self._tweak_data.timer * (startUpgrade + toAdd)
	end
	local lin1 = TIM:fon_function()
	lin1:animate(function(o)
		
		wait(TIM._settings.PollsDuration + TIM._settings.PollsCooldown)
			
		function BaseInteractionExt:_timer_value()
			return self._tweak_data.timer
		end
		lin1:parent():remove(lin1)
	end)
end