
function TIM.PollFunctions.flashbang_rain()
	local maximumUpgrade = 50
	local startUpgrade = 5
	local toAdd = math.modf((maximumUpgrade/TIM._settings.Maximum_upgrade_level) * (TIM.PollEffectsForms.flashbang_rain.Upgrade.Level-1))
	managers.player:local_player():sound():say("l2n_d02",true,true)
	local duration =tweak_data.group_ai.flash_grenade_lifetime
	local lin1 = TIM:fon_function()
	lin1:animate(function(o)
		for i=1, toAdd+startUpgrade, 1 do
			local pos, rot = TIM:Spawn_position(true)
			local x = math.random(-1000, 1000)
			local y = math.random(-1000, 1000)
			local vec = Vector3(x,y,0)
			managers.groupai:state():detonate_smoke_grenade(pos+vec, pos+vec, duration, true)
			wait(0.1)
		end
		lin1:parent():remove(lin1)
	end)
end