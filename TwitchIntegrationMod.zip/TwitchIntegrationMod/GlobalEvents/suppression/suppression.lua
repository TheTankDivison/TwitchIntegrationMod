
function TIM.PollFunctions.suppression()
	local startUpgrade=10
	local maximumUpgrade=40
	local nameOfFucn = "suppression"
	
	local black_screen = TIM.hud.panel:bitmap({
		name = "sssss",			
		visible = true,
		texture = "guis/textures/black",
		layer = -3,
		alpha=0,
		color = Color(1, 1, 1),
		w = TIM.hud.panel:w()*5,
		h = TIM.hud.panel:h()*5,
		x =0,
		y =0
	})  
	local funcBefore = function(black_screen) 
		local function over1(seconds, bool, f,  fixed_dt)
			local t = 0
			while true do
				local dt = coroutine.yield()
				t = t + (fixed_dt and 0.03333333333333333 or dt)
				if seconds <= t then
					break
				end
				--
				f(t / seconds, t)
				if bool ==true then
					if math.abs(black_screen:w()-TIM.hud.panel:w())<0.1 then
						break
					end
				else
					if math.abs(black_screen:w()-TIM.hud.panel:w()*5)<0.1 then
						break
					end
				end
			end
			f(1, seconds)
		end
		over1(200, true, function(p)
			black_screen:set_center_x(TIM.hud.panel:center_x())
			black_screen:set_center_y(TIM.hud.panel:center_y())
			black_screen:set_w(math.lerp(black_screen:w(),TIM.hud.panel:w(),p))
			black_screen:set_h(math.lerp(black_screen:h(),TIM.hud.panel:h(),p))
			black_screen:set_alpha(math.lerp(black_screen:alpha(), 1, p))
		end)
		managers.environment_controller:set_downed_value(50)
		SoundDevice:set_rtpc("downed_state_progression", 50)
	end
	local funcAfter = function(black_screen)
		local function over1(seconds, bool, f,  fixed_dt)
			local t = 0
			while true do
				local dt = coroutine.yield()
				t = t + (fixed_dt and 0.03333333333333333 or dt)
				if seconds <= t then
					break
				end
				--
				f(t / seconds, t)
				if bool ==true then
					if math.abs(black_screen:w()-TIM.hud.panel:w())<0.1 then
						break
					end
				else
					if math.abs(black_screen:w()-TIM.hud.panel:w()*5)<0.1 then
						break
					end
				end
			end
			f(1, seconds)
		end
		managers.environment_controller:set_downed_value(0)
		SoundDevice:set_rtpc("downed_state_progression", 0)
		over1(200, false, function(p)
			black_screen:set_center_x(TIM.hud.panel:center_x())
			black_screen:set_center_y(TIM.hud.panel:center_y())
			black_screen:set_w(math.lerp(black_screen:w(),TIM.hud.panel:w()*5,p))
			black_screen:set_h(math.lerp(black_screen:h(),TIM.hud.panel:h()*5,p))
			black_screen:set_alpha(math.lerp(black_screen:alpha(), 0, p))
		end)	
		black_screen:parent():remove(black_screen)
	end
	
	TIM:BaseTimerEvent(nameOfFucn, funcBefore, funcAfter, startUpgrade, maximumUpgrade, black_screen, black_screen)	
end