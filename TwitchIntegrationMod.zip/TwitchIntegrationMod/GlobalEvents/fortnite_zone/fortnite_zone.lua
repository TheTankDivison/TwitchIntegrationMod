
function TIM.PollFunctions.fortnite_zone()
	local startTimerUpgrade=10
	local maximumTimerUpgrade=60
	local startUpgrade = 15
	local maxUpgrade = 5
	local toAdd = ((startUpgrade-maxUpgrade)/TIM._settings.Maximum_upgrade_level) * (TIM.PollEffectsForms.fortnite_zone.Upgrade.Level-1)
	local nameOfFucn = "fortnite_zone"
	TIM.fortnite_zoneTabl = {startUpgrade = startUpgrade, toAdd = toAdd, pos = managers.player:local_player():position(), times = managers.player:player_timer():time()}
	local funcBefore = function() 
		local sound = "sounds/radio"
		local p1 = managers.menu_component._main_panel
		local name = "sound"..sound
		if alive(p1:child(name)) then
			managers.menu_component._main_panel:remove(p1:child(name))
		end
		local volume = managers.user:get_setting("sfx_volume")
		local percentage = (volume - tweak_data.menu.MIN_SFX_VOLUME) / (tweak_data.menu.MAX_SFX_VOLUME - tweak_data.menu.MIN_SFX_VOLUME)
		managers.menu_component._main_panel:video({
			name = name,
			video = sound,
			visible = false,
			loop = false,
		}):set_volume_gain(percentage+0.10)	
		--local pos = managers.player:local_player():position()
		local color = Color(150 ,206, 113, 241)/ 255
		local size = 100000
		over(3, function(p)
			if managers.player:local_player() then
				local dr = Draw:brush(color)
				dr:set_color(color)
				size = math.lerp(size, (TIM.fortnite_zoneTabl.startUpgrade-TIM.fortnite_zoneTabl.toAdd)*100, p)
				dr:sphere(TIM.fortnite_zoneTabl.pos, size, 4)
			end
		end)
		
		Hooks:PostHook(PlayerDamage, "update", "FortniteZone",
			function(self)
				if managers.player:local_player() then
					local color = Color(150 ,206, 113, 241)/ 255
					local cooldown = 0.1
					local dr = Draw:brush(color)
					dr:set_color(color)
					dr:sphere(TIM.fortnite_zoneTabl.pos, (TIM.fortnite_zoneTabl.startUpgrade-TIM.fortnite_zoneTabl.toAdd)*100, 4)
					local players = World:find_units("sphere", TIM.fortnite_zoneTabl.pos, (TIM.fortnite_zoneTabl.startUpgrade-TIM.fortnite_zoneTabl.toAdd)*100, managers.slot:get_mask("players"))
					local bool = true
					for _, player in pairs(players) do
						if player == managers.player:local_player() then
							bool = false
						end
					end
					local tim = managers.player:player_timer():time()
					if bool == true and (tim - TIM.fortnite_zoneTabl.times) >=cooldown then
						TIM.fortnite_zoneTabl.times = tim
						managers.player:player_unit():character_damage():damage_killzone({
							variant = "killzone",
							damage = 0.2,
							col_ray = {
								ray = math.UP
							}
						})
					end
				end
			end
		)
	end
	local funcAfter = function()
		local sound = "sounds/radio"
		local p = managers.menu_component._main_panel
		local name = "sound"..sound
		if alive(p:child(name)) then
			managers.menu_component._main_panel:remove(p:child(name))
		end
		local volume = managers.user:get_setting("sfx_volume")
		local percentage = (volume - tweak_data.menu.MIN_SFX_VOLUME) / (tweak_data.menu.MAX_SFX_VOLUME - tweak_data.menu.MIN_SFX_VOLUME)
		managers.menu_component._main_panel:video({
			name = name,
			video = sound,
			visible = false,
			loop = false,
		}):set_volume_gain(percentage+0.10)	
		Hooks:RemovePostHook("FortniteZone")
	end
	--managers.slot:get_mask("players")
	TIM:BaseTimerEvent(nameOfFucn, funcBefore, funcAfter, startTimerUpgrade, maximumTimerUpgrade )	
end
