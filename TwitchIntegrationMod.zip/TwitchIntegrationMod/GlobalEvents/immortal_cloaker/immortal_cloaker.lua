
function TIM.PollFunctions.immortal_cloaker()
	local maximumUpgrade = 40
	local startUpgrade = 10
	local toAdd = math.modf((maximumUpgrade/TIM._settings.Maximum_upgrade_level) * (TIM.PollEffectsForms.immortal_cloaker.Upgrade.Level-1))
	managers.player:local_player():sound():say("Play_ban_s04",true,true)	
	local unit_name = Idstring("units/payday2/characters/ene_spook_1/ene_spook_1")
	
	local pos, rot = TIM:Spawn_position(false)
	local act = { type = "act", body_part = 1, variant = "e_sp_uno_ground", align_sync = true }
	local unit_done = TIM:Spawn_unit(true, unit_name, pos, rot)
	unit_done:brain():action_request(act)
		
	local lin1 = TIM:fon_function()
	lin1:animate(function(o)
		unit_done:character_damage():set_invulnerable(true)
		managers.network:session():send_to_peers_synched("set_unit_invulnerable",unit_done, true)
		
		wait(startUpgrade+toAdd)
		
		unit_done:character_damage():set_invulnerable(false)
		managers.network:session():send_to_peers_synched("set_unit_invulnerable",unit_done, false)
		
		lin1:parent():remove(lin1)
	end)
	
end