--stoled idea from Dr.Newbie's mod :P (sorry)
function TIM.PollFunctions.social_distance()
	local maximumUpgrade = 60
	local startUpgrade = 10
	local toAdd =(maximumUpgrade/TIM._settings.Maximum_upgrade_level) * (TIM.PollEffectsForms.social_distance.Upgrade.Level-1)
	
	if TIM.PollFunctionsActiveTime.social_distance and TIM.PollFunctionsActiveTime.social_distance>0 then
		TIM.PollFunctionsActiveTime.social_distance = TIM.PollFunctionsActiveTime.social_distance + startUpgrade + toAdd
	else
		local cooldown = 0.5
		local cooldown2 = 8
		local prev = 0
		local prev2=0
		local sec = managers.player:player_timer():time()
		local ends = sec + TIM._settings.PollsDuration + TIM._settings.PollsCooldown
		local lin1 = TIM:fon_function()
		lin1:animate(function(o)
			TIM.PollFunctionsActiveTime.social_distance = startUpgrade + toAdd--TIM._settings.PollsDuration + TIM._settings.PollsCooldown
			while TIM.PollFunctionsActiveTime.social_distance >0 do
			
				TIM.PollFunctionsActiveTime.social_distance=TIM.PollFunctionsActiveTime.social_distance-0.1
			
				local __units = World:find_units("sphere", managers.player:player_unit():position(), 500, managers.slot:get_mask("persons"))
				for _, _unit in pairs(__units) do 
					if _unit and alive(_unit) and _unit ~= managers.player:player_unit() then
						 managers.player:player_unit():character_damage():damage_killzone({
							variant = "killzone",
							damage = 0.2,
							col_ray = {
								ray = math.UP
							}
						})
						if sec>= prev then 
							prev = sec + cooldown
							local corona = TIM.hud.panel:bitmap({
								name = "corona",			
								visible = true,
								texture = "guis/textures/icons/corona",
								layer = 0,
								alpha=1,
								color = Color(1, 1, 1),
								w = 0,
								h = 0,
								blend_mode = "add",
								x =0,
								y =0--line_temp:world_y() --HUDChat.line_height-line_temp:h()
							})
							corona:animate(function(o)
								local x =math.random(0, TIM.hud.panel:w())
								local y =math.random(0, TIM.hud.panel:h())--line_temp:world_y() --HUDChat.line_height-line_temp:h()
								over(1, function(p)
									corona:set_w(math.lerp(0, 100, p))
									corona:set_h(math.lerp(0, 100, p))
									corona:set_center_x(x)
									corona:set_center_y(y)
								end)
								over(1, function(p)
									corona:set_w(math.lerp(100, 0, p))
									corona:set_h(math.lerp(100, 0, p))
									corona:set_center_x(x)
									corona:set_center_y(y)
								end)
								corona:parent():remove(corona)
							end)
						end
						
						if sec>= prev2 then 
							local sound= "sounds/cough_sound"
							prev2 = sec + cooldown2
							local p = managers.menu_component._main_panel
							local name = "sound"..sound
							if alive(p:child(name)) then
								managers.menu_component._main_panel:remove(p:child(name))
							end
							local volume = managers.user:get_setting("sfx_volume")
							local percentage = (volume - tweak_data.menu.MIN_SFX_VOLUME) / (tweak_data.menu.MAX_SFX_VOLUME - tweak_data.menu.MIN_SFX_VOLUME)
							managers.menu_component._main_panel:video({
								name = name,
								video = sound,
								visible = false,
								loop = false,
							}):set_volume_gain(percentage+0.10)
						end
						break
					end
				end
				sec = managers.player:player_timer():time()
				wait(0.1)
			end
			
			lin1:parent():remove(lin1)
		end)
	end
end