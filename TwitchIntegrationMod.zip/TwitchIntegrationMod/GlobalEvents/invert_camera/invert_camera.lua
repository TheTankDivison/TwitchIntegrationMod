
function TIM.PollFunctions.invert_camera()
	--[[
	local startUpgrade=10
	local maximumUpgrade=60
	local nameOfFucn = "invert_camera"
	local tab={}
	tab.set_x = managers.user:get_setting("invert_camera_x")
	tab.set_y = managers.user:get_setting("invert_camera_y")
	local funcBefore = function(tab) 
		managers.user:set_setting("invert_camera_x", not tab.set_x)
		managers.user:set_setting("invert_camera_y", not tab.set_y)
	end
	local funcAfter = function(tab)
		managers.user:set_setting("invert_camera_x", tab.set_x)
		managers.user:set_setting("invert_camera_y", tab.set_y)
	end
	
	TIM:BaseTimerEvent(nameOfFucn, funcBefore, funcAfter, startUpgrade, maximumUpgrade, tab, tab)	
	]]
end