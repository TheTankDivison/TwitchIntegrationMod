
function TIM.PollFunctions.keep_walking()
	local startUpgrade=10
	local maximumUpgrade=60
	local nameOfFucn = "keep_walking"
	TIM.keep_walkingPos=managers.player:local_player():position()
	TIM.keep_walkingTimer = managers.player:player_timer():time()
	TIM.keep_walkingMaxTimer = 0.1
	TIM.keep_walkingCooldown = managers.player:player_timer():time()
	local funcBefore = function() 
		Hooks:PostHook(PlayerDamage, "update", "keep_walking",
			function(self)
				if managers.player:local_player() then
					local pos = managers.player:local_player():position()
					local road =math.sqrt(pos.x * pos.x + pos.y * pos.y)
					local road2 =math.sqrt(TIM.keep_walkingPos.x * TIM.keep_walkingPos.x + TIM.keep_walkingPos.y * TIM.keep_walkingPos.y)

					if math.abs(road - road2)>0 then
						TIM.keep_walkingPos=pos
						TIM.keep_walkingTimer = managers.player:player_timer():time()
					end
					
					if managers.player:player_timer():time()- TIM.keep_walkingTimer > TIM.keep_walkingMaxTimer and managers.player:player_timer():time() - TIM.keep_walkingCooldown >1 and managers.player:current_state() == "standard" then
						local range = 500
						local damage = 30
						local ply_damage = damage * 0.5
						local normal = math.UP
						local slot_mask = managers.slot:get_mask("explosion_targets")
						local curve_pow = 4

						local damage_params = {
							no_raycast_check_characters = false,
							hit_pos = pos,
							range = range,
							collision_slotmask = slot_mask,
							curve_pow = curve_pow,
							damage = damage,
							player_damage = ply_damage,
							user = managers.player:local_player()
						}
						local effect_params = {
							sound_event = "grenade_explode",
							effect = "effects/payday2/particles/explosions/grenade_explosion",
							camera_shake_max_mul = 4,
							sound_muffle_effect = true,
							feedback_range = range * 2
						}
						TIM.keep_walkingCooldown = managers.player:player_timer():time()
						managers.explosion:give_local_player_dmg(pos, range, ply_damage)
						managers.explosion:play_sound_and_effects(pos, normal, range, effect_params)
						managers.explosion:detect_and_give_dmg(damage_params)
						managers.network:session():send_to_peers_synched("sync_explosion_to_client", managers.player:local_player(), pos, normal, ply_damage, range, curve_pow)
					end
					
				end
			end
		)
	end
	local funcAfter = function()
		Hooks:RemovePostHook("keep_walking")
	end
	
	TIM:BaseTimerEvent(nameOfFucn, funcBefore, funcAfter, startUpgrade, maximumUpgrade)	
end