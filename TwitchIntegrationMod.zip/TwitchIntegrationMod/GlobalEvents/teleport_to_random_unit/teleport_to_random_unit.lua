 
function TIM.PollFunctions.teleport_to_random_unit()
	local maximumUpgrade = 50
	local startUpgrade = 10
	local toAdd =(maximumUpgrade/TIM._settings.Maximum_upgrade_level) * (TIM.PollEffectsForms.teleport_to_random_unit.Upgrade.Level-1)
	
	local enemies_table = {}
	
	local __units = World:find_units("sphere", managers.player:player_unit():position(), 100000, managers.slot:get_mask("enemies"))
	for _, _unit in pairs(__units) do 
		enemies_table[#enemies_table+1] = _unit
	end
	if #enemies_table>0 then 
		local rnd = math.random(#enemies_table)
		local pos = enemies_table[rnd]:position()
		local rot = enemies_table[rnd]:rotation()
		enemies_table[rnd]:character_damage():set_health(enemies_table[rnd]:character_damage():get_health()*((startUpgrade+toAdd)/100))
		managers.player:warp_to(pos, rot)
	end
end