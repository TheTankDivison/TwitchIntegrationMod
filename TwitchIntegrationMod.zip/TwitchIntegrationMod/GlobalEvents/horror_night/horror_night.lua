
function TIM.PollFunctions.horror_night()
	local maximumUpgrade = 0.5
	local startUpgrade = 6
	local toAdd = ((startUpgrade-maximumUpgrade)/TIM._settings.Maximum_upgrade_level) * (TIM.PollEffectsForms.horror_night.Upgrade.Level-1)
	local unit_name = Idstring("units/payday2/characters/ene_spook_1/ene_spook_1")
	local act = { type = "act", body_part = 1, variant = "e_sp_uno_ground", align_sync = true }
	
	managers.viewport:set_override_environment("environments/pd2_env_foggy_bright/pd2_env_foggy_bright", 2)
	local sec = 0
	local delay = startUpgrade-toAdd
	local lin1 = TIM:fon_function()
	lin1:animate(function(o)
		while sec <= TIM._settings.PollsDuration + TIM._settings.PollsCooldown-3 do
			local x = math.random(-1000, 1000)
			local y = math.random(-1000, 1000)
			local vec = Vector3(x,y,0)
			local pos, rot = TIM:Spawn_position(true)
			local unit_done = TIM:Spawn_unit(true, unit_name, pos+vec, rot)
			unit_done:brain():action_request(act)
		
			
			managers.network:session():send_to_peers_synched("sync_run_sequence_char", unit_done, "dismember_head")
			
			--managers.groupai:state():detonate_smoke_grenade(pos+vec, pos+vec, duration, true)
			wait(delay)
			sec=sec+delay
		end
		
		managers.viewport:set_override_environment(nil, 2)
		lin1:parent():remove(lin1)
	end)
	
end
