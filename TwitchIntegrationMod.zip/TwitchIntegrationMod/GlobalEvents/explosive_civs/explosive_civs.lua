
function TIM.PollFunctions.explosive_civs()
	local startUpgrade=10
	local maximumUpgrade=60
	local nameOfFucn = "explosive_civs"
	local old_func = CivilianDamage.die
	local funcBefore = function() 
		function CivilianDamage:die(variant)
			self._unit:base():set_slot(self._unit, 17)
			self:drop_pickup()
			local pos = self._unit:position()
			local range = 500
			local damage = 20
			local ply_damage = damage * 0.5
			local normal = math.UP
			local slot_mask = managers.slot:get_mask("explosion_targets")
			local curve_pow = 4

			local damage_params = {
				no_raycast_check_characters = false,
				hit_pos = pos,
				range = range,
				collision_slotmask = slot_mask,
				curve_pow = curve_pow,
				damage = damage,
				player_damage = ply_damage,
				user = managers.player:player_unit()
			}
			local effect_params = {
				sound_event = "grenade_explode",
				effect = "effects/payday2/particles/explosions/grenade_explosion",
				camera_shake_max_mul = 4,
				sound_muffle_effect = true,
				feedback_range = range * 2
			}

			managers.explosion:give_local_player_dmg(pos, range, ply_damage)
			managers.explosion:play_sound_and_effects(pos, normal, range, effect_params)
			managers.explosion:detect_and_give_dmg(damage_params)
			managers.network:session():send_to_peers_synched("sync_explosion_to_client", managers.player:player_unit(), pos, normal, ply_damage, range, curve_pow)
			
			
			if self._unit:unit_data().mission_element then
				self._unit:unit_data().mission_element:event("death", self._unit)

				if not self._unit:unit_data().alerted_event_called then
					self._unit:unit_data().alerted_event_called = true

					self._unit:unit_data().mission_element:event("alerted", self._unit)
				end
			end

			managers.modifiers:run_func("OnCivilianKilled", self._unit)

			if alive(managers.interaction:active_unit()) then
				managers.interaction:active_unit():interaction():selected()
			end

			variant = variant or "bullet"
			self._health = 0
			self._health_ratio = 0
			self._dead = true

			self:set_mover_collision_state(false)
		end

	end
	local funcAfter = function(old_func)
		CivilianDamage.die=old_func
	end
	
	TIM:BaseTimerEvent(nameOfFucn, funcBefore, funcAfter, startUpgrade, maximumUpgrade, nil, old_func)	
end