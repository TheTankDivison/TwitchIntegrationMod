
function TIM.PollFunctions.one_bullet()
	local startUpgrade=10
	local maximumUpgrade=60
	local nameOfFucn = "disable_hud"
	local tab={}
	tab[1] = managers.player:local_player():inventory()._available_selections[1].unit:base():get_ammo_max_per_clip()
	tab[2]= managers.player:local_player():inventory()._available_selections[2].unit:base():get_ammo_max_per_clip()
	local funcBefore = function() 
		
		managers.player:local_player():inventory()._available_selections[1].unit:base():set_ammo_max_per_clip(1)
		managers.player:local_player():inventory()._available_selections[2].unit:base():set_ammo_max_per_clip(1)
		managers.player:local_player():inventory()._available_selections[1].unit:base():set_ammo_remaining_in_clip(1)
		managers.player:local_player():inventory()._available_selections[2].unit:base():set_ammo_remaining_in_clip(1)
		
		for id, weapon in pairs(managers.player:local_player():inventory():available_selections()) do
			local ammo_max_per_clip, ammo_remaining_in_clip, ammo_total, ammo_max = weapon.unit:base():ammo_info()
			managers.hud:set_ammo_amount(id, 1, 1, ammo_total, ammo_max)
		end
	end
	local funcAfter = function(tab1)
		managers.player:local_player():inventory()._available_selections[1].unit:base():set_ammo_max_per_clip(tab1[1])
		managers.player:local_player():inventory()._available_selections[2].unit:base():set_ammo_max_per_clip(tab1[2])	
	end
	
	TIM:BaseTimerEvent(nameOfFucn, funcBefore, funcAfter, startUpgrade, maximumUpgrade, nil, tab)	
end