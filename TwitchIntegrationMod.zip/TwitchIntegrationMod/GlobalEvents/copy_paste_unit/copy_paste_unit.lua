
function TIM.PollFunctions.copy_paste_unit()
	local maximumUpgrade = 100
	local maxTimer = 60
	TIM.copy_paste_unitStartUpgrade = 20
	local startTimer=20
	TIM.copy_paste_unitToAdd = (maximumUpgrade/TIM._settings.Maximum_upgrade_level) * (TIM.PollEffectsForms.copy_paste_unit.Upgrade.Level-1)
	local old_func = CopDamage.die
	local funcBefore = function()
		function CopDamage:die(attack_data)
			local x = math.random(-100, 100)
			local y = math.random(-100, 100)
			local chance = TIM.copy_paste_unitStartUpgrade+TIM.copy_paste_unitToAdd
			local sp = math.random(0,100)
			local pos = self._unit:position()+Vector3(x, y, 0)
			local rot = self._unit:rotation()
			if sp <= chance then
				TIM:Spawn_unit(true, self._unit:name(), pos, rot)
				World:effect_manager():spawn({
					effect = Idstring("effects/payday2/particles/explosions/smoke_puff_alt"),
					position = pos,
					rotation = rot
				})
				local sound_device = SoundDevice:create_source("MutatorHydra_" .. tostring(MutatorHydra._sound_devices))

				if sound_device then
					sound_device:stop()
					sound_device:set_position(pos)
					sound_device:set_orientation(rot)
					sound_device:post_event("mutators_hydra_01")
				else
					Application:error("[Mutators] No sound device for hydra to use!")
				end
			end
			if self._immortal then
				debug_pause("Immortal character died!")
			end

			local variant = attack_data.variant

			self:_check_friend_4(attack_data)
			CopDamage.MAD_3_ACHIEVEMENT(attack_data)
			self:_remove_debug_gui()
			self._unit:base():set_slot(self._unit, 17)

			if alive(managers.interaction:active_unit()) then
				managers.interaction:active_unit():interaction():selected()
			end

			self:drop_pickup()
			self._unit:inventory():drop_shield()

			if self._unit:unit_data().mission_element then
				self._unit:unit_data().mission_element:event("death", self._unit)

				if not self._unit:unit_data().alerted_event_called then
					self._unit:unit_data().alerted_event_called = true

					self._unit:unit_data().mission_element:event("alerted", self._unit)
				end
			end

			if self._unit:movement() then
				self._unit:movement():remove_giveaway()
			end

			variant = variant or "bullet"
			self._health = 0
			self._health_ratio = 0
			self._dead = true

			self:set_mover_collision_state(false)

			if self._death_sequence then
				if self._unit:damage() and self._unit:damage():has_sequence(self._death_sequence) then
					self._unit:damage():run_sequence_simple(self._death_sequence)
				else
					debug_pause_unit(self._unit, "[CopDamage:die] does not have death sequence", self._death_sequence, self._unit)
				end
			end

			if self._unit:base():char_tweak().die_sound_event then
				self._unit:sound():play(self._unit:base():char_tweak().die_sound_event, nil, nil)
			end

			self:_on_death()
			managers.mutators:notify(Message.OnCopDamageDeath, self, attack_data)
		end	
	end
	
	local funcAfter = function(old_func)
		CopDamage.die = old_func
	end
	TIM:BaseTimerEvent("copy_paste_unit", funcBefore, funcAfter, startTimer, maxTimer, nil, old_func)
end