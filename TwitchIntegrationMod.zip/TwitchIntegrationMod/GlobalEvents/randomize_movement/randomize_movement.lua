
function TIM.PollFunctions.randomize_movement()
	local startUpgrade=10
	local maximumUpgrade=60
	local nameOfFucn = "randomize_movement"
	local old_funct = PlayerStandard._determine_move_direction
	local funcBefore = function() 
		function PlayerStandard:_determine_move_direction()
				local vec = self._controller:get_input_axis("move")
				
				self._stick_move = Vector3(vec.y*-1, vec.x*-1, vec.z)
				--self._stick_move.x = -1* self._stick_move.x
				--self._stick_move.y = -1* self._stick_move.y
				--TIM:debug(self._stick_move)
				if self._state_data.on_zipline then
					return
				end

				if mvector3.length(self._stick_move) < PlayerStandard.MOVEMENT_DEADZONE or self:_interacting() or self:_does_deploying_limit_movement() then
					self._move_dir = nil
					self._normal_move_dir = nil
				else
					local ladder_unit = self._unit:movement():ladder_unit()

					if alive(ladder_unit) then
						local ladder_ext = ladder_unit:ladder()
						self._move_dir = mvector3.copy(self._stick_move)
						self._normal_move_dir = mvector3.copy(self._move_dir)
						local cam_flat_rot = Rotation(self._cam_fwd_flat, math.UP)

						mvector3.rotate_with(self._normal_move_dir, cam_flat_rot)

						local cam_rot = Rotation(self._cam_fwd, self._ext_camera:rotation():z())

						mvector3.rotate_with(self._move_dir, cam_rot)

						local up_dot = math.dot(self._move_dir, ladder_ext:up())
						local w_dir_dot = math.dot(self._move_dir, ladder_ext:w_dir())
						local normal_dot = math.dot(self._move_dir, ladder_ext:normal()) * -1
						local normal_offset = ladder_ext:get_normal_move_offset(self._unit:movement():m_pos())

						mvector3.set(self._move_dir, ladder_ext:up() * (up_dot + normal_dot))
						mvector3.add(self._move_dir, ladder_ext:w_dir() * w_dir_dot)
						mvector3.add(self._move_dir, ladder_ext:normal() * normal_offset)
					else
						self._move_dir = mvector3.copy(self._stick_move)
						local cam_flat_rot = Rotation(self._cam_fwd_flat, math.UP)

						mvector3.rotate_with(self._move_dir, cam_flat_rot)

						self._normal_move_dir = mvector3.copy(self._move_dir)
					end
				end
			end
			
	end
	local funcAfter = function(old_func)
		PlayerStandard._determine_move_direction = old_func
	end
	
	TIM:BaseTimerEvent(nameOfFucn, funcBefore, funcAfter, startUpgrade, maximumUpgrade, nil, old_funct)	
end

