
function TIM.PollFunctions.grenades_rain()
	local maximumUpgrade = 50
	local startUpgrade = 5
	local toAdd = math.modf((maximumUpgrade/TIM._settings.Maximum_upgrade_level) * (TIM.PollEffectsForms.grenades_rain.Upgrade.Level-1))
	local lin1 = TIM:fon_function()
	lin1:animate(function(o)
		for i=1, toAdd+startUpgrade, 1 do
			local pos, rot = TIM:Spawn_position(true)
			local x = math.random(-1000, 1000)
			local y = math.random(-1000, 1000)
			local vec = Vector3(x,y,0)
			World:spawn_unit(Idstring("units/payday2/weapons/wpn_frag_grenade/wpn_frag_grenade"), pos+vec, rot)
			--managers.groupai:state():detonate_smoke_grenade(pos+vec, pos+vec, duration, true)
			wait(0.1)
		end
		lin1:parent():remove(lin1)
	end)
end