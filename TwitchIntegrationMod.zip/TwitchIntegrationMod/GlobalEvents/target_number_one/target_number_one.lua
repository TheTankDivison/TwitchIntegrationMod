
function TIM.PollFunctions.target_number_one()
	local startUpgrade=10
	local maximumUpgrade=60
	local nameOfFucn = "target_number_one"
	
	local upgrade={}
	upgrade.upgrade="chico_preferred_target"
	upgrade.category="player"
	local not_disable = managers.player:local_player():upgrade_value("player", "chico_preferred_target", false) 
	local tab={}
	tab[1]=upgrade
	tab[2]=not_disable
	local funcBefore = function(upgrade1) 	
		managers.player:local_player():aquire_upgrade(upgrade1)
		managers.player:local_player():activate_temporary_upgrade("temporary", "chico_injector")
	end
	local funcAfter = function(tab1)
		if tab1[2] == false then 
			managers.player:local_player():unaquire_upgrade(tab[1])
			managers.player:local_player():deactivate_temporary_upgrade("temporary", "chico_injector")	
		end
	end
	
	TIM:BaseTimerEvent(nameOfFucn, funcBefore, funcAfter, startUpgrade, maximumUpgrade, upgrade, tab)	
end