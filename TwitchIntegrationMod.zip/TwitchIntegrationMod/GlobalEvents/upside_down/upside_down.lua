
function TIM.PollFunctions.upside_down()
	local startUpgrade=10
	local maximumUpgrade=60
	local nameOfFucn = "upside_down"
	local funcBefore = function() 
		function FPCameraPlayerBase:set_target_tilt(tilt)
			self._camera_properties.target_tilt = 180
		end
		managers.player:player_unit():camera():camera_unit():base():set_target_tilt(0)
		managers.user:set_setting("invert_camera_x", true)
	end
	local funcAfter = function()
		function FPCameraPlayerBase:set_target_tilt(tilt)
			self._camera_properties.target_tilt = tilt
		end
		managers.player:player_unit():camera():camera_unit():base():set_target_tilt(0)
		managers.user:set_setting("invert_camera_x", false)
	end
	
	TIM:BaseTimerEvent(nameOfFucn, funcBefore, funcAfter, startUpgrade, maximumUpgrade)	
end