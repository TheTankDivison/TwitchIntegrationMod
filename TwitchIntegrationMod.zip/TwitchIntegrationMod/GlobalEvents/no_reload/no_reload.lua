
function TIM.PollFunctions.no_reload()
	local startUpgrade=10
	local maximumUpgrade=60
	local nameOfFucn = "no_reload"
	local old_func = PlayerStandard._check_action_reload
	local funcBefore = function() 
		function PlayerStandard:_check_action_reload(t, input)
			local new_action = nil
			local action_wanted = nil

			if action_wanted then
				local action_forbidden = self:_is_reloading() or self:_changing_weapon() or self:_is_meleeing() or self._use_item_expire_t or self:_interacting() or self:_is_throwing_projectile()

				if not action_forbidden and self._equipped_unit and not self._equipped_unit:base():clip_full() then
					self:_start_action_reload_enter(t)

					new_action = true
				end
			end

			return new_action
		end
	end
	local funcAfter = function(old_func)
		PlayerStandard._check_action_reload = old_func 
	end
	
	TIM:BaseTimerEvent(nameOfFucn, funcBefore, funcAfter, startUpgrade, maximumUpgrade, nil, old_func)	
end