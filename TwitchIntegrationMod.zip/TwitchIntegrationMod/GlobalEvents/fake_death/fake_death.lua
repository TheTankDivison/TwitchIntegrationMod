
function TIM.PollFunctions.fake_death()
	local startUpgrade=2
	local maximumUpgrade=6
	local nameOfFucn = "fake_death"
	local current_state = managers.player:current_state()
	local funcBefore = function() 
		managers.player:player_unit():sound():play("player_armor_gone_stinger")
		managers.player:player_unit():sound():play("player_hit_permadamage")
		if current_state =="standard" or current_state == "tased" or current_state == "mask_off" or current_state == "civilian" or current_state =="carry" then
			managers.player:set_player_state("bleed_out")
		end
	end
	local funcAfter = function(current_stat)
		managers.player:set_player_state(current_stat=="tased" and "standard" or current_stat)	
	end
	
	TIM:BaseTimerEvent(nameOfFucn, funcBefore, funcAfter, startUpgrade, maximumUpgrade, nil, current_state)	
end