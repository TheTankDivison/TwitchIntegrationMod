
function TIM.PollFunctions.heal_all_units()
	local function heal_unit(unit, override_cooldown)
		if unit:brain() and unit:brain()._logic_data then
			local team = unit:brain()._logic_data.team

			if team and team.id ~= "law1" and (not team.friends or not team.friends.law1) then
				return false
			end
		end

		if unit:brain() and unit:brain()._logic_data and unit:brain()._logic_data.is_converted then
			return false
		end

		local cop_dmg = unit:character_damage()
		cop_dmg._health = cop_dmg._HEALTH_INIT
		cop_dmg._health_ratio = 1

		cop_dmg:_update_debug_ws()
		managers.network:session():send_to_peers("sync_medic_heal", unit)
		return true
	end

	local enemies = World:find_units("sphere", managers.player:player_unit():position(), 1000*TIM.PollEffectsForms.heal_all_units.Upgrade.Level, managers.slot:get_mask("enemies"))
	for _, enemy in pairs(enemies) do
		if enemy and enemy:movement() and heal_unit(enemy, true) then
			enemy:movement():action_request({
				body_part = 3,
				type = "healed",
				client_interrupt = false
			})
		end
	end
end