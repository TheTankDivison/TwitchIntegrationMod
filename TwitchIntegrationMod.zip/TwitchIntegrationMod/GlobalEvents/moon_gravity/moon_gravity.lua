
function TIM.PollFunctions.moon_gravity()
	local maximumUpgrade = 60
	local startUpgrade = 10
	local toAdd =(maximumUpgrade/TIM._settings.Maximum_upgrade_level) * (TIM.PollEffectsForms.moon_gravity.Upgrade.Level-1)
	
	if TIM.PollFunctionsActiveTime.moon_gravity and TIM.PollFunctionsActiveTime.moon_gravity>0 then
		TIM.PollFunctionsActiveTime.moon_gravity = TIM.PollFunctionsActiveTime.moon_gravity + startUpgrade + toAdd
	else
		local grav = managers.player:player_unit():mover():gravity()
			
			
		local lin1 = TIM:fon_function()
		lin1:animate(function(o)
			TIM.PollFunctionsActiveTime.moon_gravity = startUpgrade + toAdd--TIM._settings.PollsDuration + TIM._settings.PollsCooldown
			while TIM.PollFunctionsActiveTime.moon_gravity >0 do
				wait(0.1)
				TIM.PollFunctionsActiveTime.moon_gravity=TIM.PollFunctionsActiveTime.moon_gravity-0.1
			
				managers.player:player_unit():mover():set_gravity(Vector3(grav.x, grav.y, grav.z * 0.1))
				
				
			end
			managers.player:player_unit():mover():set_gravity(Vector3(grav.x, grav.y, grav.z))				
			lin1:parent():remove(lin1)
		end)
	end
end