BotPathTW = BotPathTW or {}

BotPathTW.mod_path = ModPath